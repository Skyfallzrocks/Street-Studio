Street Studio interface preview. Open index.html in a browser.
This uses fixture data; no game simulation is running and no game files are changed.
Preview controls test UI interactions only. Install the real mod to design streets in Cities: Skylines II.
