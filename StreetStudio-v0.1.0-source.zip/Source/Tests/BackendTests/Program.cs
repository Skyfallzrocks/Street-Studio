using System;
using System.Collections;
using System.IO;
using System.Reflection;

class Program {
 static object Get(object target,string name)=>target.GetType().GetProperty(name).GetValue(target);
 static void Set(object target,string name,object value)=>target.GetType().GetProperty(name).SetValue(target,value);
 static void Assert(bool value,string message){if(!value)throw new Exception(message);}
 static void Main(string[] args){
  string game=Environment.GetEnvironmentVariable("CSII_MANAGEDPATH");
  string mod=Path.GetFullPath(args[0]);
  AppDomain.CurrentDomain.AssemblyResolve+=(s,e)=>{
   var filename=new AssemblyName(e.Name).Name+".dll";
   foreach(var folder in new[]{Path.GetDirectoryName(mod),game}) {var f=Path.Combine(folder,filename);if(File.Exists(f))return Assembly.LoadFrom(f);}
   return null;
  };
  var assembly=Assembly.LoadFrom(mod);
  var roadType=assembly.GetType("StreetStudio.Domain.Configurations.RoadConfig",true);
  var laneType=assembly.GetType("StreetStudio.Domain.Configurations.LaneConfig",true);
  var ui=assembly.GetType("StreetStudio.Systems.UI.StreetStudioUISystem",true);
  var original=Activator.CreateInstance(roadType);
  Set(original,"ID","current-id"); Set(original,"OriginalID","original-id");Set(original,"Name","Test Avenue");Set(original,"SpeedLimit",80f);
  var lane=Activator.CreateInstance(laneType);Set(lane,"GroupPrefabName","StreetStudio.LaneGroups.CarGroupPrefab");Set(lane,"Invert",true);
  ((IDictionary)Get(lane,"GroupOptions")).Add("Decoration","GT");((IList)Get(original,"Lanes")).Add(lane);
  var clone=ui.GetMethod("CloneStudio",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,new[]{original});
  Assert(!ReferenceEquals(original,clone),"Clone aliases original");
  Assert(Get(original,"Type")==null,"Clone mutated source Type");
  Assert((string)Get(clone,"Name")=="Test Avenue","Name was not preserved");
  Assert((float)Get(clone,"SpeedLimit")==80f,"Speed was not preserved");
  var clonedLane=((IList)Get(clone,"Lanes"))[0];
  Assert((bool)Get(clonedLane,"Invert"),"Lane direction was not preserved");
  ((IDictionary)Get(clonedLane,"GroupOptions"))["Decoration"]="G";
  Assert((string)((IDictionary)Get(lane,"GroupOptions"))["Decoration"]=="GT","History shares mutable option dictionary");
  Set(clone,"ID","snapshot-id"); Set(clone,"Name","Restored Avenue");Set(clone,"SpeedLimit",60f);
  ui.GetMethod("CopyStudio",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,new[]{original,clone});
  Assert((string)Get(original,"ID")=="current-id","Undo changed prefab identity");
  Assert((string)Get(original,"OriginalID")=="original-id","Undo changed saved identity");
  Assert((string)Get(original,"Name")=="Restored Avenue"&&(float)Get(original,"SpeedLimit")==60f,"Undo failed to restore design");
  var parse=ui.GetMethod("ParseStudioRecipe",BindingFlags.NonPublic|BindingFlags.Static);
  var recipe=parse.Invoke(null,new object[]{"{\"Lanes\":1,\"Sidewalk\":4,\"Median\":5,\"Speed\":30,\"Bikes\":true,\"Trees\":true,\"Grass\":true}"});
  Assert((int)Get(recipe,"Lanes")==1&&(bool)Get(recipe,"Bikes"),"UI recipe JSON did not bind to backend settings");
  foreach(var bad in new[]{"{\"Lanes\":0}","{\"Lanes\":7}","{\"Median\":3}","{\"Sidewalk\":0}","{\"Speed\":999}"}){
   bool rejected=false;try{parse.Invoke(null,new object[]{bad});}catch(TargetInvocationException e){rejected=e.InnerException is ArgumentException;}
   Assert(rejected,"Invalid recipe accepted: "+bad);
  }
  var addons=assembly.GetType("StreetStudio.Domain.Enums.RoadAddons",true);
  var decorate=ui.GetMethod("StudioDecorations",BindingFlags.NonPublic|BindingFlags.Static);
  ulong flags=Convert.ToUInt64(decorate.Invoke(null,new[]{Enum.ToObject(addons,(ulong)17),recipe}));
  Assert((flags&17)==17,"Decorations removed pipes or zoning");
  Assert((flags&128)!=0&&(flags&1024)!=0&&(flags&256)!=0&&(flags&512)!=0,"Greenery was not applied through game edge-state flags");
  Assert((flags&96)==0,"Unsupported bike sidewalk grass was enabled");
  var plain=parse.Invoke(null,new object[]{"{}"});
  flags=Convert.ToUInt64(decorate.Invoke(null,new[]{Enum.ToObject(addons,(ulong)2047),plain}));
  Assert((flags&2016)==0,"Reset recipe left old greenery active");
  Console.WriteLine("PASS: snapshots, nested option isolation, directions/speed, identity-safe undo, UI-to-backend recipe parsing, invalid design rejection, actual greenery flags and reset.");
 }
}
