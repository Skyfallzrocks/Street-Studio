# Backend checks

Requires .NET 10 SDK and the installed game assemblies. These are serialization and state tests; they do not run a city.

From Source, after building the mod:

```powershell
dotnet run --project Tests/BackendTests -- ../Package/StreetStudio/StreetStudio.dll
```

Browser interaction checks and visual inspection were also performed on the separate fixture-based Preview. In-game generation, placement, save/load and mod interoperability remain untested.
