﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class PoleGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Lane Width";
		private const string OptionName2 = "Ground Type";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "Tram",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "Tram", ThumbnailUrl = "coui://streetstudioicons/RB_TramWhite.svg" },
						new() { Value = "Train", ThumbnailUrl = "coui://streetstudioicons/RB_TrainWhite.svg" },
					}
				},
				new()
				{
					DefaultValue = "1m",
					Type = LaneOptionType.LaneWidth,
					Name = OptionName1,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "1m" },
						new() { Value = "2m" },
					}
				},
			};

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_TramShoulder.svg";

			SetUp(Sections!["SS Train Pole Section 2"], "2m", "Train").WithThumbnail("coui://streetstudioicons/RB_TrainShoulder.svg").WithGroundTexture(LaneGroundType.Train).WithColor(82, 62, 51).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
			SetUp(Sections["SS Train Pole Section 1"], "1m", "Train").WithThumbnail("coui://streetstudioicons/RB_TrainShoulder.svg").WithGroundTexture(LaneGroundType.Train).WithColor(82, 62, 51).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
			SetUp(Sections["SS Tram Pole Section 2"], "2m", "Tram").WithThumbnail("coui://streetstudioicons/RB_TramShoulder.svg").WithGroundTexture(LaneGroundType.Asphalt).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
			SetUp(Sections["SS Tram Pole Section 1"], "1m", "Tram").WithThumbnail("coui://streetstudioicons/RB_TramShoulder.svg").WithGroundTexture(LaneGroundType.Asphalt).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");

			return true;
		}

		private StreetStudioLaneInfo SetUp(NetSectionPrefab prefab, string value1, string value2)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
			};

			return prefab.AddOrGetComponent<StreetStudioLaneInfo>();
		}
	}
}
