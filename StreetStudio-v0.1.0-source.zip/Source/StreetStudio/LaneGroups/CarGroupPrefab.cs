﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class CarGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Lane Width";
		private const string OptionName2 = "Transport Option";
		private const string OptionName3 = "Markings";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "3m",
					Type = LaneOptionType.LaneWidth,
					Name = OptionName1,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "3m" },
						new() { Value = "4m" },
					}
				},
				new()
				{
					DefaultValue = "",
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_CarWhite.svg"
						},
						new()
						{
							Value = "Transport" ,
							ThumbnailUrl = "coui://streetstudioicons/RB_BusWhite.svg"
						},
						new()
						{
							Value = "Tram",
							ThumbnailUrl = "coui://streetstudioicons/RB_TramWhite.svg"
						},
					}
				},
				new()
				{
					DefaultValue = "",
					Name = OptionName3,
					Type = LaneOptionType.Toggle,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_MarkingsWhite.svg"
						},
						new()
						{
							Value = "1",
							ThumbnailUrl = "coui://streetstudioicons/RB_NoMarkingsWhite.svg"
						}
					}
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.NonAsphalt & ~RoadCategory.Gravel & ~RoadCategory.Tiled)
				.WithFrontThumbnail("coui://streetstudioicons/RB_CarFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_CarRear.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Car_Centered.svg";

			SetUp(Sections!["Gravel Drive Section 3"], "3m", "").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireAll(RoadCategory.Gravel).AddLaneThumbnail("coui://streetstudioicons/Thumb_GravelLane.svg");
			SetUp(Sections["SS Tiled Drive Section 3 - Car"], "3m", "").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireAll(RoadCategory.Tiled).AddLaneThumbnail("coui://streetstudioicons/Thumb_TiledWide.svg");
			SetUp(Sections["Tiled Drive Section 3"], "3m", "Tram").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireAll(RoadCategory.Tiled).AddLaneThumbnail("coui://streetstudioicons/Thumb_TiledWide.svg").WithFrontThumbnail("coui://streetstudioicons/RB_CarTramFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarTramRear.svg");
			SetUp(Sections["Alley Drive Section 3"], "3m", "", true).AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled).WithFrontThumbnail("coui://streetstudioicons/RB_AlleyCarFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_AlleyCarRear.svg");
			SetUp(Sections["Car Drive Section 3"], "3m", "").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled);
			SetUp(Sections["Car Drive Section 3 - Transport Option"], "3m", "Transport").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled).WithFrontThumbnail("coui://streetstudioicons/RB_CarBusFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarBusRear.svg");
			SetUp(Sections["Car Drive Section 3 - Transport Tram Option"], "3m", "Tram").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled).WithFrontThumbnail("coui://streetstudioicons/RB_CarTramFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarTramRear.svg");
			SetUp(Sections["Highway Drive Section 4"], "4m", "").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled);
			SetUp(Sections["Highway Drive Section 4 - Transport Option"], "4m", "Transport").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled).WithFrontThumbnail("coui://streetstudioicons/RB_CarBusFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarBusRear.svg");
			SetUp(Sections["Car Drive Section 4 - Transport Tram Option"], "4m", "Tram").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled).WithFrontThumbnail("coui://streetstudioicons/RB_CarTramFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarTramRear.svg");

			return true;
		}

		private NetSectionPrefab SetUp(NetSectionPrefab prefab, string value1, string value2, bool noMarkings = false)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
				new()
				{
					OptionName = OptionName3,
					Value = noMarkings ? "1" : ""
				}
			};

			return prefab;
		}
	}
}
