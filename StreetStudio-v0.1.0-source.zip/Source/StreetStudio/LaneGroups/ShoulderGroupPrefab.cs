﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class ShoulderGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Lane Width";
		private const string OptionName2 = "Ground Type";
		private const string OptionName3 = "Parking Angle";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "Asphalt",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "Asphalt", ThumbnailUrl = "coui://streetstudioicons/RB_CarWhite.svg" },
						new() { Value = "Bus", ThumbnailUrl = "coui://streetstudioicons/RB_BusWhite.svg" },
						new() { Value = "Tram", ThumbnailUrl = "coui://streetstudioicons/RB_TramWhite.svg" },
						new() { Value = "Train", ThumbnailUrl = "coui://streetstudioicons/RB_TrainWhite.svg" },
						new() { Value = "Subway", ThumbnailUrl = "coui://streetstudioicons/RB_SubwayWhite.svg" },
						new() { Value = "Gravel", ThumbnailUrl = "coui://streetstudioicons/RB_GravelWhite.svg" },
						new() { Value = "Tiled", ThumbnailUrl = "coui://streetstudioicons/RB_TiledWhite.svg" },
						new() { Value = "Parking", ThumbnailUrl = "coui://streetstudioicons/RB_YesParking.svg" },
						new() { Value = "Harbor", ThumbnailUrl = "coui://streetstudioicons/RB_Harbor.svg" },
					}
				},
				new()
				{
					DefaultValue = "1m",
					Type = LaneOptionType.LaneWidth,
					Name = OptionName1,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "1m" },
						new() { Value = "2m" },
						new() { Value = "6.5m" },
						new() { Value = "9m" },
					}
				},
				new()
				{
					DefaultValue = "",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName3,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "Angled",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle60.svg"
						},
						new()
						{
							Value = "Perpendicular",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle90.svg"
						},
					}
				},
			};

			Prefab.AddOrGetComponent<StreetStudioEdgeLaneInfo>();

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithGroundTexture(LaneGroundType.Asphalt)
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_Shoulder.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Shoulder.svg";

			SetUp(Sections!["Alley Shoulder 1"], Sections["Alley Side 0"], "1m", "Asphalt").WithThumbnail("coui://streetstudioicons/RB_ShoulderLight.svg");
			SetUp(Sections["Highway Shoulder 2"], Sections["Highway Side 0"], "2m", "Asphalt").WithThumbnail("coui://streetstudioicons/RB_ShoulderLight.svg");
			SetUp(Sections["Public Transport Shoulder 1"], Sections["Alley Side 0"], "1m", "Bus").WithThumbnail("coui://streetstudioicons/RB_ShoulderLight.svg");
			SetUp(Sections["Gravel Shoulder 1"], Sections["Gravel Side 0"], "1m", "Gravel").WithThumbnail("coui://streetstudioicons/RB_Empty.svg").WithGroundTexture(LaneGroundType.Gravel).WithColor(143, 131, 97).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderGravel.svg");
			SetUp(Sections["Tiled Shoulder 1"], Sections["Tiled Side 0"], "1m", "Tiled").WithThumbnail("coui://streetstudioicons/RB_Empty.svg").WithGroundTexture(LaneGroundType.Tiled).WithColor(76, 78, 83).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderPedestrian.svg");
			SetUp(Sections["Subway Shoulder 2"], Sections["Subway Side 0"], "2m", "Subway").WithThumbnail("coui://streetstudioicons/RB_Empty.svg").WithGroundTexture(LaneGroundType.Train).WithColor(82, 62, 51).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
			SetUp(Sections["Train Shoulder 2"], Sections["Train Side 0"], "2m", "Train").WithThumbnail("coui://streetstudioicons/RB_TrainShoulder.svg").WithGroundTexture(LaneGroundType.Train).WithColor(82, 62, 51).AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
			SetUp(Sections["Tram Shoulder 1"], Sections["Alley Side 0"], "1m", "Tram").WithThumbnail("coui://streetstudioicons/RB_TramShoulder.svg").AddLaneThumbnail("coui://streetstudioicons/Thumb_ShoulderTrack.svg");
		
			if (Sections!.ContainsKey("Harbor Gate Shoulder 2"))
			SetUp(Sections["Harbor Gate Shoulder 2"], Sections["Alley Side 0"], "2m", "Harbor").WithThumbnail("coui://streetstudioicons/RB_ShoulderLight.svg").WithColor(145, 155, 163, 150);

			SetUp(Sections["Parking Lane 8 - Alley"], Sections["Alley Side 0"], "9m", "Parking", "Perpendicular").AddLaneThumbnail("coui://streetstudioicons/Thumb_90ParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront90.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear90.svg").WithPieceRequireNone(NetPieceRequirements.Node);
			SetUp(Sections["Parking Lane Angled 8 - Alley"], Sections["Alley Side 0"], "9m", "Parking", "Angled").AddLaneThumbnail("coui://streetstudioicons/Thumb_AngledParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront45-60.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear45-60.svg").WithPieceRequireNone(NetPieceRequirements.Node);
			SetUp(Sections["Parking Lane 5.5 - Alley"], Sections["Alley Side 0"], "6.5m", "Parking", "Perpendicular").AddLaneThumbnail("coui://streetstudioicons/Thumb_90ParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront90.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear90.svg").WithPieceRequireNone(NetPieceRequirements.Node);
			SetUp(Sections["Parking Lane Angled 5.5 - Alley"], Sections["Alley Side 0"], "6.5m", "Parking", "Angled").AddLaneThumbnail("coui://streetstudioicons/Thumb_AngledParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront45-60.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear45-60.svg").WithPieceRequireNone(NetPieceRequirements.Node);

			Sections["Parking Lane 8 - Alley"].AddOrGetComponent<StreetStudioLaneAggregate>().LeftSections = new[] { new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 1"] } };
			Sections["Parking Lane Angled 8 - Alley"].AddOrGetComponent<StreetStudioLaneAggregate>().LeftSections = new[] { new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 1"] } };
			Sections["Parking Lane 5.5 - Alley"].AddOrGetComponent<StreetStudioLaneAggregate>().LeftSections = new[] { new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 1"], PieceRequireNone = new[] { NetPieceRequirements.Node } }, new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 2.5"], PieceRequireAny = new[] { NetPieceRequirements.Node } } };
			Sections["Parking Lane Angled 5.5 - Alley"].AddOrGetComponent<StreetStudioLaneAggregate>().LeftSections = new[] { new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 1"], PieceRequireNone = new[] { NetPieceRequirements.Node } }, new StreetStudioAggregateSection { Section = Sections["Parking Lane Shoulder 2.5"], PieceRequireAny = new[] { NetPieceRequirements.Node } } };
			Sections["Parking Lane Shoulder 1"].AddOrGetComponent<StreetStudioIgnoreSection>();
			Sections["Parking Lane Shoulder 2.5"].AddOrGetComponent<StreetStudioIgnoreSection>();

			return true;
		}

		private StreetStudioLaneInfo SetUp(NetSectionPrefab prefab, NetSectionPrefab side, string value1, string value2, string value3 = "")
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
				new()
				{
					OptionName = OptionName3,
					Value = value3
				},
			};

			prefab.AddOrGetComponent<StreetStudioEdgeLaneInfo>().SidePrefab = side;

			return prefab.AddOrGetComponent<StreetStudioLaneInfo>();
		}
	}
}
