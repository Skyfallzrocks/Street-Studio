﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class ParkingGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Parking Angle";
		private const string OptionName2 = "Markings";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "Parallel",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName1,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "Parallel",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle0.svg"
						},
						new()
						{
							Value = "Angled",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle60.svg"
						},
						new()
						{
							Value = "Perpendicular",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle90.svg"
						},
					}
				},
				new()
				{
					DefaultValue = "",
					Name = OptionName2,
					Type = LaneOptionType.Toggle,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "1",
							ThumbnailUrl = "coui://streetstudioicons/RB_MarkingsWhite.svg"
						},
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_NoMarkingsWhite.svg"
						}
					}
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.NonAsphalt)
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_CarLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_ParkingFront0Center.svg";

			SetUp(Sections!["SS Parking Section Parallel"], "Parallel", "1").AddOrGetComponent<StreetStudioLaneInfo>().AddLaneThumbnail("coui://streetstudioicons/Thumb_CarLaneSmall.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront0.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear0.svg");
			SetUp(Sections!["SS Parking Section Parallel NoMarking"], "Parallel", "").AddOrGetComponent<StreetStudioLaneInfo>().WithNoDirection().AddLaneThumbnail("coui://streetstudioicons/Thumb_CarLaneSmall.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront0.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear0.svg");
			SetUp(Sections["SS Parking Section Angled"], "Angled", "1").AddOrGetComponent<StreetStudioLaneInfo>().WithNoDirection().AddLaneThumbnail("coui://streetstudioicons/Thumb_AngledParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront45-60.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear45-60.svg");
			SetUp(Sections["SS Parking Section Angled NoMarking"], "Angled", "").AddOrGetComponent<StreetStudioLaneInfo>().WithNoDirection().AddLaneThumbnail("coui://streetstudioicons/Thumb_AngledParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront45-60.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear45-60.svg");
			SetUp(Sections["SS Parking Section Perpendicular"], "Perpendicular", "1").AddOrGetComponent<StreetStudioLaneInfo>().WithNoDirection().AddLaneThumbnail("coui://streetstudioicons/Thumb_90ParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront90.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear90.svg");
			SetUp(Sections["SS Parking Section Perpendicular NoMarking"], "Perpendicular", "").AddOrGetComponent<StreetStudioLaneInfo>().WithNoDirection().AddLaneThumbnail("coui://streetstudioicons/Thumb_90ParkingLane.svg").WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront90.svg").WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear90.svg");

			return true;
		}

		private NetSectionPrefab SetUp(NetSectionPrefab prefab, string value1, string value2)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				}
			};

			return prefab;
		}
	}
}
