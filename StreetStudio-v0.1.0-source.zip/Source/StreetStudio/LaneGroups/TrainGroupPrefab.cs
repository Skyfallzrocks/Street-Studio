﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class TrainGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Two-way Support";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					Name = OptionName,
					Type = LaneOptionType.TwoWay,
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled | RoadCategory.Fence | RoadCategory.Pathway | RoadCategory.Subway)
				.WithColor(82, 62, 51)
				.WithFrontThumbnail("coui://streetstudioicons/RB_TrainFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_TrainRear.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_TrackLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_TrainFront.svg";

			SetUp(Sections!["Train Track Section 4"], false);
			SetUp(Sections["Train Track Twoway Section 4"], true);

			return true;
		}

		private void SetUp(NetSectionPrefab prefab, bool value)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = value ? new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = string.Empty
				}
			} : new LaneOptionCombination[0];
		}
	}
}
