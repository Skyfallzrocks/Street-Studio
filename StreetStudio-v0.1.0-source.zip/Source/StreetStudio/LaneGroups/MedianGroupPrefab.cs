﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class MedianGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Median Width";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "2m",
					Type = LaneOptionType.LaneWidth,
					IgnoreForSimilarDuplicate = true,
					Name = OptionName,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "1m" },
						new() { Value = "2m" },
						new() { Value = "5m" }
					}
				},
				new()
				{
					Name = "Decoration",
					Type = LaneOptionType.Decoration,
				},
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.Train | RoadCategory.Subway | RoadCategory.Gravel | RoadCategory.Fence | RoadCategory.Pathway)
				.WithThumbnail("coui://streetstudioicons/RB_Median.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_MedianSmall.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Median_Centered.svg";

			var decoInfo = Sections!["SS Median 5"].AddOrGetComponent<StreetStudioLaneDecorationInfo>();
			decoInfo.GrassThumbnail = "coui://streetstudioicons/RB_GrassMedian.svg";
			decoInfo.TreeThumbnail = "coui://streetstudioicons/RB_TreeMedian.svg";
			decoInfo.GrassAndTreeThumbnail = "coui://streetstudioicons/RB_TreeGrassMedian.svg";
			decoInfo.LaneGrassThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkGrass.svg" };
			decoInfo.LaneTreeThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkTree.svg" };
			decoInfo.LaneGrassAndTreeThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkGrassTree.svg" };

			SetUp<StreetStudioLaneGroup>(Sections["SS Median 1"], "1m");
			SetUp<StreetStudioLaneGroup>(Sections["SS Median 2"], "2m");
			SetUp<StreetStudioLaneGroup>(Sections["SS Median 5"], "5m", true).AddOrGetComponent<StreetStudioLaneInfo>().AddLaneThumbnail("coui://streetstudioicons/Thumb_MedianWide.svg");

			SetUp<StreetStudioVanillaLaneGroup>(Sections["Road Median 1"], "1m");
			SetUp<StreetStudioVanillaLaneGroup>(Sections["Road Median 2"], "2m");
			SetUp<StreetStudioVanillaLaneGroup>(Sections["Road Median 5"], "5m", true);
			SetUp<StreetStudioVanillaLaneGroup>(Sections["Parking Road Median 5"], "5m", true);

			return true;
		}

		private NetSectionPrefab SetUp<T>(NetSectionPrefab prefab, string value, bool hasGrass = false) where T : StreetStudioLaneGroup
		{
			var laneInfo = prefab.AddOrGetComponent<T>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = hasGrass
			? new LaneOptionCombination[]
			{
				new()
				{
					OptionName = "Decoration",
					Value = string.Empty
				},
				new()
				{
					OptionName = OptionName,
					Value = value
				}
			}
			: new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = value
				}
			};

			return prefab;
		}
	}
}
