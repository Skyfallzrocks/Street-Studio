﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class BikeGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Two-way Support";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					Name = OptionName,
					Type = LaneOptionType.TwoWay,
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireAll(RoadCategory.Pathway)
				.WithColor(43, 161, 82, 200)
				.WithFrontThumbnail("coui://streetstudioicons/RB_BikeFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_BikeRear.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_BikeLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_BikeCentered.svg";

			SetUp(Sections!["OneWayBikeSection 3"], false).WithRequireAll(RoadCategory.Pathway).WithMedian();
			SetUp(Sections!["OneWayBikeSection 3"], "BikeSideSection 0", "BikeSideSection 0");

			SetUp(Sections!["TwoWayBikeSection 3"], true).WithRequireAll(RoadCategory.Pathway).WithMedian();
			SetUp(Sections!["TwoWayBikeSection 3"], "BikeSideSection 0", "BikeSideSection 0");
			Sections!["TwoWayBikeSection 3"].AddOrGetComponent<StreetStudioLaneAggregate>().RightSections = new[]
			{
				new StreetStudioAggregateSection
				{
					Section = Sections["TwoWayBikeSection 0"],
					Invert = true
				} 
			};

			Sections["TwoWayBikeSection 0"].AddOrGetComponent<StreetStudioIgnoreSection>();

			return true;
		}

		private StreetStudioLaneInfo SetUp(NetSectionPrefab prefab, bool value)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = value ? new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = string.Empty
				}
			} : new LaneOptionCombination[0];

			return prefab.AddOrGetComponent<StreetStudioLaneInfo>();
		}

		private void SetUp(NetSectionPrefab prefab, string leftSide, string rightSide)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioEdgeLaneInfo>();

			laneInfo.LeftSidePrefab = Sections![leftSide];
			laneInfo.RightSidePrefab = Sections![rightSide];
			laneInfo.DoNotRequireBeingOnEdge = true;
		}
	}
}
