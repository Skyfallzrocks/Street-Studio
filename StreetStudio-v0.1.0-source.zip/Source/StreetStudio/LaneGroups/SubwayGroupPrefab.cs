﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class SubwayGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Two-way Support";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					Name = OptionName,
					Type = LaneOptionType.TwoWay,
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireAll(RoadCategory.Subway)
				.WithColor(66, 60, 51)
				.WithFrontThumbnail("coui://streetstudioicons/RB_SubwayFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_SubwayRear.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_SubwayRail.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_TrackLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_SubwayFront.svg";

			SetUp(Sections!["Subway Track Section 4"], false);
			SetUp(Sections["Subway Track Twoway Section 4"], true);

			return true;
		}

		private void SetUp(NetSectionPrefab prefab, bool value)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = value ? new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = string.Empty
				}
			} : new LaneOptionCombination[0];
		}
	}
}
