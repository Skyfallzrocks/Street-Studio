﻿using Game.Prefabs;

using StreetStudio.Domain.Prefabs;

using System.Collections.Generic;

namespace StreetStudio.LaneGroups
{
	public abstract class BaseLaneGroupPrefab
	{
		public LaneGroupPrefab? Prefab { get; set; }
		public Dictionary<string, NetSectionPrefab>? Sections { get; set; }
		public abstract bool Initialize();
	}
}
