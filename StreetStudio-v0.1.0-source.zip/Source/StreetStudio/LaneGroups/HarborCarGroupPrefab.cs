﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class HarborCarGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName2 = "Transport Option";

		public override bool Initialize()
		{
			if (!Sections!.ContainsKey("Harbor Drive Section 4"))
				return false;

			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "",
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_CarWhite.svg"
						},
						new()
						{
							Value = "Transport" ,
							ThumbnailUrl = "coui://streetstudioicons/RB_BusWhite.svg"
						},
					}
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithColor(145, 155, 163, 150)
				.WithRequireNone(RoadCategory.NonAsphalt & ~RoadCategory.Gravel & ~RoadCategory.Tiled)
				.WithFrontThumbnail("coui://streetstudioicons/RB_CarFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_CarRear.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Cargo_Centered.svg";

			SetUp(Sections!["Harbor Drive Section 4"], "").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled);
			SetUp(Sections["Harbor Drive Section 4 - Transport Option"], "Transport").AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Gravel | RoadCategory.Tiled)
				.WithFrontThumbnail("coui://streetstudioicons/RB_CarBusFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_CarBusRear.svg");

			return true;
		}

		private NetSectionPrefab SetUp(NetSectionPrefab prefab, string value2)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
			};

			return prefab;
		}
	}
}
