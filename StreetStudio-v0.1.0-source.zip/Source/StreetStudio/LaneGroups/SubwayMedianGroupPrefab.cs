﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class SubwayMedianGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Style";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					Name = OptionName,
					Type = LaneOptionType.SingleSelectionButtons,
					DefaultValue = "Raised",
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "Raised",
							ThumbnailUrl = "coui://streetstudioicons/RB_RaisedCenterPlatformWhite.svg"
						},
						new()
						{
							Value = "Flat",
							ThumbnailUrl = "coui://streetstudioicons/RB_CenterPlatformWhite.svg"
						}
					}
				}
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.Tiled | RoadCategory.Fence | RoadCategory.Pathway)
				.WithGroundTexture(LaneGroundType.Train)
				.WithColor(82, 62, 51);

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_CenterPlatform.svg";

			SetUp(Sections!["SS Subway Median 8"], "Raised", true).AddOrGetComponent<StreetStudioLaneInfo>().WithThumbnail("coui://streetstudioicons/RB_CenterPlatform.svg").AddLaneThumbnail("coui://streetstudioicons/Thumb_Platform.svg");
			SetUp(Sections["SS Subway Median 8 - Plain"], "Flat", true).AddOrGetComponent<StreetStudioLaneInfo>().WithThumbnail("coui://streetstudioicons/RB_Empty.svg").AddLaneThumbnail("coui://streetstudioicons/Thumb_PlatformEmpty.svg").WithRequireAny(RoadCategory.Train | RoadCategory.Subway);

			SetUp(Sections["Subway Median 8"], "Raised", false);
			SetUp(Sections["Subway Median 8 - Plain"], "Flat", false);

			return true;
		}

		private NetSectionPrefab SetUp(NetSectionPrefab prefab, string value, bool link)
		{
			var laneInfo = link ? prefab.AddOrGetComponent<StreetStudioLaneGroup>() : prefab.AddOrGetComponent<StreetStudioVanillaLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = value
				}
			};

			return prefab;
		}
	}
}
