﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class SidewalkGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Parking";
		private const string OptionName2 = "Width";
		private const string OptionName3 = "Parking Angle";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "",
					Name = OptionName1,
					Type = LaneOptionType.SingleSelectionButtons,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "H" ,
							ThumbnailUrl = "coui://streetstudioicons/RB_Harbor.svg"
						},
						new()
						{
							Value = "B" ,
							ThumbnailUrl = "coui://streetstudioicons/RB_YesBikes.svg"
						},
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_NoParking.svg"
						},
						new()
						{
							Value = "P" ,
							ThumbnailUrl = "coui://streetstudioicons/RB_YesParking.svg"
						},
					}
				},
				new()
				{
					DefaultValue = "3.5m",
					Type = LaneOptionType.LaneWidth,
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "1m" },
						new() { Value = "1.5m" },
						new() { Value = "2m" },
						new() { Value = "2.5m" },
						new() { Value = "3m" },
						new() { Value = "3.5m" },
						new() { Value = "4m" },
						new() { Value = "4.5m" },
						new() { Value = "5m" },
						new() { Value = "5.5m" },
						new() { Value = "6m" },
						new() { Value = "7m" },
						new() { Value = "9m" },
					}
				},
				new()
				{
					DefaultValue = "",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName3,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle0.svg"
						},
						new()
						{
							Value = "Angled",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle60.svg"
						},
						new()
						{
							Value = "Perpendicular",
							ThumbnailUrl = "coui://streetstudioicons/RB_WhiteParkingAngle90.svg"
						},
					}
				},
				new()
				{
					Name = "Decoration",
					Type = LaneOptionType.Decoration,
				},
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_SidewalkWide.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_WideSidewalkRight.svg";

			var edgeInfo = Prefab.AddOrGetComponent<StreetStudioEdgeLaneInfo>();
			edgeInfo.AddSidewalkStateOnNode = true;
			edgeInfo.SidePrefab = Sections!["Road Side 0"];

			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 1"], "", "1m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 1.5"], "", "1.5m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 2"], "", "2m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 2.5"], "", "2.5m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 3"], "", "3m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 4"], "", "4m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 3.5"], "", "3.5m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 4.5"], "", "4.5m", "", null);

			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 5"], "", "5m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 7"], "", "7m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 6"], "", "6m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk 5.5"], "", "5.5m", "");

			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking 5"], "P", "5m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking 6"], "P", "6m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking 7"], "P", "7m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking 5.5"], "P", "5.5m", "");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking Lane 7"], "P", "7m", "Perpendicular");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking Lane Angled 7"], "P", "7m", "Angled");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking Lane 9"], "P", "9m", "Perpendicular");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Parking Lane Angled 9"], "P", "9m", "Angled");

			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 3.5"], "B", "3.5m", "", null);
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 4.5"], "B", "4.5m", "", "T");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 5"], "B", "5m", "", "T");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 5.5"], "B", "5.5m", "", "T");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 6"], "B", "6m", "", "T");
			SetUp<StreetStudioLaneGroup>(Sections["Sidewalk With Bikelane 7"], "B", "7m", "", "T");

			if (Sections!.ContainsKey("Harbor Sidewalk Section 6"))
			{
				SetUp<StreetStudioLaneGroup>(Sections["Harbor Sidewalk Section 6"], "H", "6m", "", null).WithColor(145, 155, 163, 150);
				var harborEdgeInfo = Sections["Harbor Sidewalk Section 6"].AddOrGetComponent<StreetStudioEdgeLaneInfo>();
				harborEdgeInfo.AddSidewalkStateOnNode = true;
				harborEdgeInfo.SidePrefab = Sections!["Harbor Road Side Section 0"];
			}

			SetUp<StreetStudioVanillaLaneGroup>(Sections["Sidewalk With Parking Lane Divided 9"], "P", "9m", "Perpendicular");
			SetUp<StreetStudioVanillaLaneGroup>(Sections["Sidewalk With Parking Lane Divided Angled 9"], "P", "9m", "Angled");

			return true;
		}

		private StreetStudioLaneInfo SetUp<T>(NetSectionPrefab prefab, string value1, string value2, string value3, string? deco = "") where T : StreetStudioLaneGroup
		{
			var laneInfo = prefab.AddOrGetComponent<T>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = "Decoration",
					Value = deco
				},
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
				new()
				{
					OptionName = OptionName3,
					Value = value3
				}
			};

			var uiObj = prefab.AddOrGetComponent<UIObject>();
			uiObj.m_Icon = value1 == "" ? "coui://streetstudioicons/RB_WideSidewalkRight.svg" : "coui://streetstudioicons/RB_SidewalkRightwParking.svg";

			switch (value1 + value3)
			{
				case "PAngled":
					prefab.AddOrGetComponent<StreetStudioLaneInfo>()
						.WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront45-60withSidewalk.svg")
						.WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear45-60withSidewalk.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_AngledParkingLane.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_ParkingSidewalk.svg");
					break;
				case "PPerpendicular":
					prefab.AddOrGetComponent<StreetStudioLaneInfo>()
						.WithFrontThumbnail("coui://streetstudioicons/RB_ParkingFront90withSidewalk.svg")
						.WithBackThumbnail("coui://streetstudioicons/RB_ParkingRear90withSidewalk.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_90ParkingLane.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_ParkingSidewalk.svg");
					break;
				case "B":
					prefab.AddOrGetComponent<StreetStudioLaneInfo>()
						.WithColor(43, 161, 82, 200)
						.WithThumbnail("coui://streetstudioicons/RB_BikewSidewalkRear.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_BikeLane.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_Sidewalk.svg");
					break;
				case "P":
					prefab.AddOrGetComponent<StreetStudioLaneInfo>()
						.WithFrontThumbnail("coui://streetstudioicons/RB_SidewalkwParkingFront.svg")
						.WithBackThumbnail("coui://streetstudioicons/RB_SidewalkwParkingRear.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_ParkingLane.svg")
						.AddLaneThumbnail("coui://streetstudioicons/Thumb_ParkingSidewalk.svg");
					break;
				default:
					// Plain and harbor sidewalks have no parking, they fall back to the group's thumbnails
					prefab.AddOrGetComponent<StreetStudioLaneInfo>();
					break;
			}

			if (deco is not null)
			{
				var decoInfo = prefab.AddOrGetComponent<StreetStudioLaneDecorationInfo>();
				decoInfo.GrassThumbnail = "coui://streetstudioicons/RB_SidewalkRightwGrass.svg";
				decoInfo.TreeThumbnail = "coui://streetstudioicons/RB_SidewalkRightwTree.svg";
				decoInfo.GrassAndTreeThumbnail = "coui://streetstudioicons/RB_SidewalkRightwTreeAndGrass.svg";
				decoInfo.LaneGrassThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkGrass.svg" };
				decoInfo.LaneTreeThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkTree.svg" };
				decoInfo.LaneGrassAndTreeThumbnail = new[] { "coui://streetstudioicons/Thumb_SidewalkGrassTree.svg" };

				if (value1 == "B")
				{
					decoInfo.TreeThumbnail = "coui://streetstudioicons/RB_BikewSidewalkwTree.svg";
					decoInfo.LaneTreeThumbnail = new[]
					{
						"coui://streetstudioicons/Thumb_BikeLane.svg",
						"coui://streetstudioicons/Thumb_SidewalkTree.svg"
					};
				}
			}

			return prefab.GetComponent<StreetStudioLaneInfo>();
		}
	}
}
