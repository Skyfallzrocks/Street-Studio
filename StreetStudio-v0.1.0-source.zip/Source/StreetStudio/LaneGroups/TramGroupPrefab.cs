﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class TramGroupPrefab : BaseLaneGroupPrefab
	{
		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[0];

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.Gravel | RoadCategory.Pathway | RoadCategory.Fence | RoadCategory.Subway)
				.WithFrontThumbnail("coui://streetstudioicons/RB_TramFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_TramRear.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_TramLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_TramFront.svg";

			var laneInfo1 = Sections!["Tram Track Section 3"].AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo1.GroupPrefab = Prefab;
			laneInfo1.Combination = new LaneOptionCombination[0];

			var laneInfo2 = Sections["SS Tiled Tram Section 3"].AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo2.GroupPrefab = Prefab;
			laneInfo2.Combination = new LaneOptionCombination[0];

			Sections["Tram Track Section 3"].AddOrGetComponent<StreetStudioLaneInfo>().WithRequireNone(RoadCategory.Tiled).WithGroundTexture(LaneGroundType.Asphalt);
			Sections["SS Tiled Tram Section 3"].AddOrGetComponent<StreetStudioLaneInfo>().WithRequireAll(RoadCategory.Tiled).AddLaneThumbnail("coui://streetstudioicons/Thumb_TiledTramLane.svg").WithGroundTexture(LaneGroundType.Tiled);

			return true;
		}
	}
}
