﻿using Colossal.IO.AssetDatabase.Internal;

using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

using System.Collections.Generic;
using System.Globalization;

namespace StreetStudio.LaneGroups
{
	public class EmptyGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName1 = "Lane Width";
		private const string OptionName2 = "Ground Type";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "Asphalt",
					Type = LaneOptionType.SingleSelectionButtons,
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "Asphalt", ThumbnailUrl = "coui://streetstudioicons/RB_CarWhite.svg" },
						new() { Value = "Train", ThumbnailUrl = "coui://streetstudioicons/RB_TrainWhite.svg" },
						new() { Value = "Gravel", ThumbnailUrl = "coui://streetstudioicons/RB_GravelWhite.svg" },
						new() { Value = "Tiled", ThumbnailUrl = "coui://streetstudioicons/RB_TiledWhite.svg" },
						new() { Value = "Harbor", ThumbnailUrl = "coui://streetstudioicons/RB_Harbor.svg" },
					}
				},
				new()
				{
					DefaultValue = "1m",
					Type = LaneOptionType.LaneWidth,
					IgnoreForSimilarDuplicate = true,
					Name = OptionName1,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "0.5m" },
						new() { Value = "1m" },
						new() { Value = "1.5m" },
						new() { Value = "2m" },
						new() { Value = "2.5m" },
						new() { Value = "3m" },
						new() { Value = "3.5m" },
						new() { Value = "4m" },
					}
				},
			};

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Empty.svg";

			SetUp(Sections!, "SS Empty Section {0}", 4, "Asphalt", "Thumb_CarLane", "Thumb_CarLaneSmall").ForEach(x => x.Item2.WithRequireNone(x.Item1 is 3 or 4 ? default : RoadCategory.NonAsphalt).WithGroundTexture(LaneGroundType.Asphalt));
			SetUp(Sections!, "SS Train Empty Section {0}", 4, "Train", "Thumb_TracklessLane", "Thumb_TracklessLaneSmall").ForEach(x => x.Item2.WithRequireAny(x.Item1 is 4 ? default : RoadCategory.Train | RoadCategory.Subway).WithGroundTexture(LaneGroundType.Train).WithColor(82, 62, 51));
			SetUp(Sections!, "SS Gravel Empty Section {0}", 3, "Gravel", "Thumb_GravelLane", "Thumb_GravelLaneSmall").ForEach(x => x.Item2.WithRequireAny(x.Item1 is 3 ? default : RoadCategory.Gravel).WithGroundTexture(LaneGroundType.Gravel).WithColor(143, 131, 97));
			SetUp(Sections!, "SS Tiled Empty Section {0}", 3, "Tiled", "Thumb_TiledWide", "Thumb_TiledSmall").ForEach(x => x.Item2.WithRequireAny(x.Item1 is 3 ? default : RoadCategory.Tiled).WithGroundTexture(LaneGroundType.Tiled).WithColor(76, 78, 83));
		
			if (Sections!.ContainsKey("Harbor Dummy Section 4"))
			SetUp(Sections!["Harbor Dummy Section 4"], "4m", "Harbor").WithRequireNone(RoadCategory.NonAsphalt).WithGroundTexture(LaneGroundType.Asphalt).AddLaneThumbnail("coui://streetstudioicons/Thumb_CarLaneBright.svg").WithColor(145, 155, 163, 150);

			return true;
		}

		private IEnumerable<(float, StreetStudioLaneInfo)> SetUp(Dictionary<string, NetSectionPrefab> sections, string name, float maxWidth, string value2, string largeThumb, string smallThumb, float minWidth = 0.5f)
		{
			for (var width = minWidth; width <= maxWidth; width += 0.5f)
			{
				var prefab = sections[string.Format(name, width.ToString(CultureInfo.InvariantCulture))];
				var laneGroup = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
				laneGroup.GroupPrefab = Prefab;
				laneGroup.Combination = new LaneOptionCombination[]
				{
					new()
					{
						OptionName = OptionName1,
						Value = $"{width.ToString(CultureInfo.InvariantCulture)}m"
					},
					new()
					{
						OptionName = OptionName2,
						Value = value2
					},
				};

				var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneInfo>();

				if (width <= 2)
				{
					laneInfo.AddLaneThumbnail($"coui://streetstudioicons/{smallThumb}.svg");
				}
				else
				{
					laneInfo.AddLaneThumbnail($"coui://streetstudioicons/{largeThumb}.svg");
				}

				yield return (width, laneInfo);
			}
		}

		private StreetStudioLaneInfo SetUp(NetSectionPrefab prefab, string value1, string value2)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName1,
					Value = value1
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				},
			};

			return prefab.AddOrGetComponent<StreetStudioLaneInfo>();
		}
	}
}
