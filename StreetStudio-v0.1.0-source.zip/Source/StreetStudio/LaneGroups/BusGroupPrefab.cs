﻿using Game.Prefabs;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Enums;

namespace StreetStudio.LaneGroups
{
	public class BusGroupPrefab : BaseLaneGroupPrefab
	{
		private const string OptionName = "Lane Width";
		private const string OptionName2 = "Transport Option";

		public override bool Initialize()
		{
			Prefab!.Options = new StreetStudioLaneOption[]
			{
				new()
				{
					DefaultValue = "3m",
					Type = LaneOptionType.LaneWidth,
					Name = OptionName,
					Options = new StreetStudioLaneOptionValue[]
					{
						new() { Value = "3m" },
						new() { Value = "4m" },
					}
				},
				new()
				{
					DefaultValue = "",
					Name = OptionName2,
					Options = new StreetStudioLaneOptionValue[]
					{
						new()
						{
							Value = "",
							ThumbnailUrl = "coui://streetstudioicons/RB_BusWhite.svg"
						},
						new()
						{
							Value = "Tram",
							ThumbnailUrl = "coui://streetstudioicons/RB_TramWhite.svg"
						},
					}
				},
			};

			Prefab.AddOrGetComponent<StreetStudioLaneInfo>()
				.WithRequireNone(RoadCategory.NonAsphalt)
				.WithColor(204, 83, 71, 200)
				.WithFrontThumbnail("coui://streetstudioicons/RB_BusFront.svg")
				.WithBackThumbnail("coui://streetstudioicons/RB_BusRear.svg")
				.AddLaneThumbnail("coui://streetstudioicons/Thumb_BusLane.svg");

			Prefab.AddOrGetComponent<UIObject>().m_Icon = "coui://streetstudioicons/RB_Bus_Centered.svg";

			SetUp(Sections!["Public Transport Lane Section 3 - Tram Option"], "3m", "Tram").AddOrGetComponent<StreetStudioLaneInfo>().WithFrontThumbnail("coui://streetstudioicons/RB_BusTramFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_BusTramRear.svg");
			SetUp(Sections!["Public Transport Lane Section 4 - Tram Option"], "4m", "Tram").AddOrGetComponent<StreetStudioLaneInfo>().WithFrontThumbnail("coui://streetstudioicons/RB_BusTramFront.svg").WithBackThumbnail("coui://streetstudioicons/RB_BusTramRear.svg");
			SetUp(Sections!["SS Public Transport Lane Section 3"], "3m", "");
			SetUp(Sections!["SS Public Transport Lane Section 4"], "4m", "");

			return true;
		}

		private NetSectionPrefab SetUp(NetSectionPrefab prefab, string value, string value2)
		{
			var laneInfo = prefab.AddOrGetComponent<StreetStudioLaneGroup>();
			laneInfo.GroupPrefab = Prefab;
			laneInfo.Combination = new LaneOptionCombination[]
			{
				new()
				{
					OptionName = OptionName,
					Value = value
				},
				new()
				{
					OptionName = OptionName2,
					Value = value2
				}
			};

			return prefab;
		}
	}
}
