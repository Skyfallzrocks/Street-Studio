﻿using Colossal.Entities;
using Colossal.Serialization.Entities;

using Game;
using Game.Common;
using Game.Input;
using Game.Net;
using Game.Prefabs;
using Game.SceneFlow;
using Game.Tools;
using Game.UI.Editor;

using StreetStudio.Domain;
using StreetStudio.Domain.Components;
using StreetStudio.Domain.Enums;
using StreetStudio.Domain.Prefabs;
using StreetStudio.Systems.UI;
using StreetStudio.Utilities;

using System;
using System.Linq;

using Unity.Collections;

using Unity.Entities;
using Unity.Jobs;

namespace StreetStudio.Systems
{
	public partial class StreetStudioToolSystem : ToolBaseSystem
	{
#nullable disable
		private PrefabSystem prefabSystem;
		private StreetStudioUISystem roadBuilderUISystem;
		private StreetStudioSystem roadBuilderSystem;
		private ToolSystem toolSystem;
		private EditorToolUISystem editorToolUISystem;
		private StreetStudioGenericFunctionsSystem roadBuilderGenericFunctionsSystem;
		private EntityQuery highlightedQuery;
		private EntityQuery roadBuilderNetworkQuery;
		private ProxyAction placeAction;
		private new ProxyAction applyAction;
		private new ProxyAction cancelAction;
#nullable enable

		public override string toolID { get; } = "StreetStudioTool";

		protected override void OnCreate()
		{
			base.OnCreate();

			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			roadBuilderUISystem = World.GetOrCreateSystemManaged<StreetStudioUISystem>();
			roadBuilderSystem = World.GetOrCreateSystemManaged<StreetStudioSystem>();
			toolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
			editorToolUISystem = World.GetExistingSystemManaged<EditorToolUISystem>();
			roadBuilderGenericFunctionsSystem = World.GetOrCreateSystemManaged<StreetStudioGenericFunctionsSystem>();

			highlightedQuery = SystemAPI.QueryBuilder().WithAny<Highlighted, StreetStudioUpdateFlagComponent>().Build();
			roadBuilderNetworkQuery = GetEntityQuery(ComponentType.ReadOnly<StreetStudioNetwork>());

			placeAction = Mod.Settings!.GetAction(nameof(Setting.PlaceToggle));
			applyAction = Mod.Settings!.GetAction(nameof(StreetStudio) + "Apply");
			cancelAction = Mod.Settings!.GetAction(nameof(StreetStudio) + "Cancel");

			var builtInApplyAction = InputManager.instance.FindAction(InputManager.kToolMap, "Apply");
			var mimicApplyBinding = applyAction.bindings.FirstOrDefault(b => b.device == InputManager.DeviceType.Mouse);
			var builtInApplyBinding = builtInApplyAction.bindings.FirstOrDefault(b => b.device == InputManager.DeviceType.Mouse);

			mimicApplyBinding.path = builtInApplyBinding.path;
			mimicApplyBinding.modifiers = builtInApplyBinding.modifiers;

			var builtInCancelAction = InputManager.instance.FindAction(InputManager.kToolMap, "Cancel");
			var mimicCancelBinding = cancelAction.bindings.FirstOrDefault(b => b.device == InputManager.DeviceType.Mouse);
			var builtInCancelBinding = builtInCancelAction.bindings.FirstOrDefault(b => b.device == InputManager.DeviceType.Mouse);

			mimicCancelBinding.path = builtInCancelBinding.path;
			mimicCancelBinding.modifiers = builtInCancelBinding.modifiers;

			InputManager.instance.SetBinding(mimicApplyBinding, out _);
			InputManager.instance.SetBinding(mimicCancelBinding, out _);
		}

		protected override void OnGamePreload(Purpose purpose, GameMode mode)
		{
			base.OnGamePreload(purpose, mode);

			if (mode == GameMode.Editor)
			{
				if (editorToolUISystem?.tools?.Any(t => t?.id == toolID) ?? true)
				{
					return;
				}

				var tools = editorToolUISystem.tools;
				Array.Resize(ref tools, tools.Length + 1);
				tools[tools.Length - 1] = new StreetStudioEditorTool(World, this, roadBuilderUISystem);
				editorToolUISystem.tools = tools;
			}
		}

		public override void InitializeRaycast()
		{
			base.InitializeRaycast();

			m_ToolRaycastSystem.netLayerMask = Layer.All;// | Layer.Road | Layer.TrainTrack | Layer.TramTrack | Layer.SubwayTrack | Layer.Pathway | Layer.PublicTransportRoad /*| Layer.Fence*/ ;
			m_ToolRaycastSystem.typeMask = TypeMask.Net;
			m_ToolRaycastSystem.collisionMask = CollisionMask.OnGround | CollisionMask.Overground;
		}

		protected override JobHandle OnUpdate(JobHandle inputDeps)
		{
			placeAction.shouldBeEnabled = roadBuilderUISystem.Mode is StreetStudioToolMode.Editing or StreetStudioToolMode.EditingNonExistent;
			applyAction.shouldBeEnabled = roadBuilderUISystem.Mode is StreetStudioToolMode.Picker;
			cancelAction.shouldBeEnabled = true;

			if (placeAction.WasPerformedThisFrame())
			{
				roadBuilderGenericFunctionsSystem.ActivateRoad(roadBuilderUISystem.GetWorkingId());

				return base.OnUpdate(inputDeps);
			}

			if (cancelAction.WasPerformedThisFrame())
			{
				if (roadBuilderUISystem.Mode is StreetStudioToolMode.Picker)
				{
					applyAction.shouldBeEnabled = false;

					roadBuilderUISystem.ClearTool();
				}
				else
				{
					roadBuilderUISystem.Mode = StreetStudioToolMode.Picker;
				}

				return base.OnUpdate(inputDeps);
			}

			switch (roadBuilderUISystem.Mode)
			{
				case StreetStudioToolMode.Picker:
				{
					var raycastHit = HandlePicker(out var entity);

					HandleHighlight(highlightedQuery, raycastHit ? x => x == entity : null);

					if (raycastHit)
					{
						TryHighlightEntity(entity);
					}

					break;
				}

				case StreetStudioToolMode.Editing:
				case StreetStudioToolMode.EditingNonExistent:
				{
					var workingId = roadBuilderUISystem.GetWorkingId();

					HandleHighlight(roadBuilderNetworkQuery, x => IsWorkingPrefab(x, workingId));

					break;
				}

				case StreetStudioToolMode.EditingSingle:
				{
					HandleHighlight(highlightedQuery, x => x == roadBuilderUISystem.WorkingEntity);

					TryHighlightEntity(roadBuilderUISystem.WorkingEntity);

					break;
				}
			}

			return base.OnUpdate(inputDeps);
		}

		private void TryHighlightEntity(Entity entity)
		{
			if (entity != Entity.Null && !EntityManager.HasComponent<Highlighted>(entity))
			{
				EntityManager.AddComponent<Highlighted>(entity);
				EntityManager.AddComponent<BatchesUpdated>(entity);
			}
		}

		private bool IsWorkingPrefab(Entity entity, string workingId)
		{
			return EntityManager.TryGetComponent<PrefabRef>(entity, out var prefabRef)
&& workingId == prefabSystem.GetPrefabName(prefabRef);
		}

		private bool HandlePicker(out Entity entity)
		{
			if (!GetRaycastResult(out entity, out var hit))
			{
				return false;
			}

			if (!EntityManager.TryGetComponent<PrefabRef>(entity, out var prefabRef) || EntityManager.HasComponent<Owner>(entity) || !EntityManager.HasComponent<Edge>(entity))
			{
				return false;
			}

			if (!Mod.Settings!.RemoveLockRequirements && GameManager.instance.gameMode == GameMode.Game && EntityManager.HasEnabledComponent<Locked>(prefabRef.m_Prefab))
			{
				return false;
			}

			if (!prefabSystem.TryGetSpecificPrefab<NetGeometryPrefab>(prefabRef, out var prefab))
			{
				return false;
			}

			if (prefab is not (RoadPrefab or TrackPrefab or FencePrefab or PathwayPrefab))
			{
				return false;
			}

			if (prefab is RoadPrefab && !EntityManager.HasComponent<Road>(entity))
			{
				return false;
			}

			if (prefab.Has<Bridge>())
			{
				return false;
			}

			if (applyAction.WasPerformedThisFrame())
			{
				if (prefab is INetworkBuilderPrefab)
				{
					roadBuilderUISystem.ShowActionPopup(entity, prefab);
				}
				else
				{
					roadBuilderUISystem.CreateNewPrefab(entity);
				}
			}

			return true;
		}

		private void HandleHighlight(EntityQuery query, Func<Entity, bool>? shouldBeHighlighted)
		{
			var entities = query.ToEntityArray(Allocator.Temp);
			var editing = roadBuilderUISystem.Mode >= StreetStudioToolMode.Editing;

			for (var i = 0; i < entities.Length; i++)
			{
				var entity = entities[i];

				if (shouldBeHighlighted != null && shouldBeHighlighted(entity))
				{
					EntityManager.AddComponent<Highlighted>(entity);

					if (editing)
					{
						EntityManager.AddComponent<StreetStudioUpdateFlagComponent>(entity);
					}
				}
				else
				{
					EntityManager.RemoveComponent<Highlighted>(entity);
					EntityManager.RemoveComponent<StreetStudioUpdateFlagComponent>(entity);
				}

				EntityManager.AddComponent<BatchesUpdated>(entity);
			}
		}

		protected override void OnStopRunning()
		{
			base.OnStopRunning();

			placeAction.shouldBeEnabled = false;
			applyAction.shouldBeEnabled = false;
			cancelAction.shouldBeEnabled = false;

			var entities = highlightedQuery.ToEntityArray(Allocator.Temp);

			for (var i = 0; i < entities.Length; i++)
			{
				var entity = entities[i];

				EntityManager.RemoveComponent<StreetStudioUpdateFlagComponent>(entity);
				EntityManager.RemoveComponent<Highlighted>(entity);
				EntityManager.AddComponent<BatchesUpdated>(entity);
			}
		}

		public override bool TrySetPrefab(PrefabBase prefab)
		{
			return false;
		}

		public override PrefabBase? GetPrefab()
		{
			return default;
		}
	}
}
