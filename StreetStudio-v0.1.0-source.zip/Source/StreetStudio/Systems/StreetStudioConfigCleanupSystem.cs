﻿using Game;
using Game.Common;

using StreetStudio.Domain.Components;

using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioConfigCleanupSystem : GameSystemBase
	{
		private EntityQuery query;

		protected override void OnCreate()
		{
			base.OnCreate();

			query = SystemAPI.QueryBuilder().WithAll<NetworkConfigComponent>().Build();

			RequireForUpdate(query);
		}

		protected override void OnUpdate()
		{
			EntityManager.AddComponent<Deleted>(query);
		}
	}
}
