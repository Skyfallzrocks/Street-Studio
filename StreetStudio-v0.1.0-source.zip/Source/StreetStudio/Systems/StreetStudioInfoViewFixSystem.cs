﻿using Game;
using Game.Prefabs;

using StreetStudio.Domain.Components;

using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioInfoViewFixSystem : GameSystemBase
	{
		private EntityQuery query;

		protected override void OnCreate()
		{
			base.OnCreate();

			query = SystemAPI.QueryBuilder().WithAll<StreetStudioPrefabData, PlaceableInfoviewItem>().Build();

			RequireForUpdate(query);
		}

		protected override void OnUpdate()
		{
			EntityManager.RemoveComponent<PlaceableInfoviewItem>(query);
		}
	}
}
