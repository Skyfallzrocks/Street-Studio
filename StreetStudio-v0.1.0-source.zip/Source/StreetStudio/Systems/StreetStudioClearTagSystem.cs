﻿using Colossal.Entities;

using Game;
using Game.Common;
using Game.Net;
using Game.Prefabs;
using Game.Tools;

using StreetStudio.Domain.Components;
using StreetStudio.Domain.Prefabs;
using StreetStudio.Utilities;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioClearTagSystem : GameSystemBase
	{
#nullable disable
		private PrefabSystem prefabSystem;
		private EntityQuery segmentQuery;
#nullable enable

		protected override void OnCreate()
		{
			base.OnCreate();

			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			segmentQuery = SystemAPI.QueryBuilder()
				.WithAll<Edge, PrefabRef, StreetStudioNetwork>()
				.WithAny<Created, Updated>()
				.WithNone<Temp>()
				.Build();

			RequireForUpdate(segmentQuery);
		}

		protected override void OnUpdate()
		{
			var entities = segmentQuery.ToEntityArray(Allocator.Temp);

			for (var i = 0; i < entities.Length; i++)
			{
				var entity = entities[i];

				if (!prefabSystem.TryGetSpecificPrefab<PrefabBase>(EntityManager.GetComponentData<PrefabRef>(entity), out var prefab) || prefab is not INetworkBuilderPrefab)
				{
					EntityManager.RemoveComponent<StreetStudioNetwork>(entity);

					if (EntityManager.TryGetComponent<Edge>(entity, out var edge))
					{
						if (!HasOtherStreetStudioEdge(edge.m_Start, entity))
						{
							EntityManager.RemoveComponent<StreetStudioNetwork>(edge.m_Start);
						}

						if (!HasOtherStreetStudioEdge(edge.m_End, entity))
						{
							EntityManager.RemoveComponent<StreetStudioNetwork>(edge.m_End);
						}
					}
				}
			}
		}

		// Nodes shared with a road builder edge keep their tag
		private bool HasOtherStreetStudioEdge(Entity node, Entity edge)
		{
			if (!EntityManager.TryGetBuffer<ConnectedEdge>(node, true, out var connectedEdges))
			{
				return false;
			}

			for (var i = 0; i < connectedEdges.Length; i++)
			{
				var connectedEdge = connectedEdges[i].m_Edge;

				if (connectedEdge != edge && EntityManager.HasComponent<StreetStudioNetwork>(connectedEdge))
				{
					return true;
				}
			}

			return false;
		}
	}
}
