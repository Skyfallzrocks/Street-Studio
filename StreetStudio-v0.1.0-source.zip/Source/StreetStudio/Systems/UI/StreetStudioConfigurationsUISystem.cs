﻿using Colossal.Entities;

using Game;
using Game.Prefabs;
using Game.SceneFlow;
using Game.UI;

using StreetStudio.Domain.UI;
using StreetStudio.Utilities;

using System;
using System.Collections.Generic;
using System.Linq;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Systems.UI
{
	public partial class StreetStudioConfigurationsUISystem : ExtendedUISystemBase
	{
#nullable disable
		private StreetStudioSystem roadBuilderSystem;
		private StreetStudioRoadTrackerSystem roadBuilderRoadTrackerSystem;
		private PrefabSystem prefabSystem;
		private StreetStudioGenericFunctionsSystem genericFunctionsSystem;
		private ValueBindingHelper<RoadConfigurationUIBinder[]> RoadConfigurations;
		private string query = string.Empty;
#nullable enable

		public event Action? ConfigurationsUpdated;

		public List<RoadConfigurationUIBinder> AvailableConfigurations { get; private set; } = new();

		protected override void OnCreate()
		{
			base.OnCreate();

			roadBuilderSystem = World.GetOrCreateSystemManaged<StreetStudioSystem>();
			roadBuilderRoadTrackerSystem = World.GetOrCreateSystemManaged<StreetStudioRoadTrackerSystem>();
			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			genericFunctionsSystem = World.GetOrCreateSystemManaged<StreetStudioGenericFunctionsSystem>();

			roadBuilderSystem.ConfigurationsUpdated += UpdateConfigurationList;

			RoadConfigurations = CreateBinding("GetRoadConfigurations", new RoadConfigurationUIBinder[0]);

			CreateTrigger<string>("ActivateRoad", genericFunctionsSystem.ActivateRoad);
			CreateTrigger<string>("EditRoad", genericFunctionsSystem.EditRoad);
			CreateTrigger<string>("FindRoad", genericFunctionsSystem.FindRoad);
			CreateTrigger<string[]>("DeleteRoad", genericFunctionsSystem.DeleteRoad);
			CreateTrigger<string>("Roads.SetSearchQuery", SetSearchQuery);
		}

		private void SetSearchQuery(string obj)
		{
			query = obj;

			RoadConfigurations.Value = AvailableConfigurations
				.Where(x => Filter(x.Name))
				.ToArray();
		}

		private bool Filter(string? name)
		{
			return string.IsNullOrWhiteSpace(query) || query.SearchCheck(name);
		}

		public void UpdateConfigurationList()
		{
			AvailableConfigurations = roadBuilderSystem.Configurations
				.Select(x => GetRoadBinder(x.Value))
				.Where(x => x != null)
				.OrderBy(x => x!.Locked)
				.ThenBy(x => x!.Name)
				.ToList()!;

			SetSearchQuery(query);

			ConfigurationsUpdated?.Invoke();
		}

		public RoadConfigurationUIBinder? GetRoadBinder(Domain.Prefabs.INetworkBuilderPrefab? value)
		{
			if (value is null)
			{
				return null;
			}

			return new RoadConfigurationUIBinder
			{
				ID = value.Config?.ID,
#if DEBUG && false
				Name = value.Config?.Name + " - " + value.Config.ID,
#else
				Name = value.Config?.Name,
#endif
				IsNotInPlayset = !value.Config?.IsInPlayset() ?? true,
				Locked = !Mod.Settings!.RemoveLockRequirements && GameManager.instance.gameMode == GameMode.Game && EntityManager.HasEnabledComponent<Locked>(prefabSystem.GetEntity(value.Prefab)),
				Used = roadBuilderRoadTrackerSystem.UsedNetworkPrefabs.Contains(value),
				Category = value.Config?.Category ?? default,
				Available = roadBuilderSystem.Configurations.ContainsKey(value.Config?.ID ?? string.Empty),
				Thumbnail = ImageSystem.GetIcon(value.Prefab)
			};
		}
	}
}
