﻿using Game.City;
using Game.Input;
using Game.Prefabs;
using Game.SceneFlow;
using Game.Simulation;
using Game.Tools;
using Game.UI;
using Game.UI.InGame;

using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Configurations;
using StreetStudio.Domain.Enums;
using StreetStudio.Domain.Prefabs;
using StreetStudio.Domain.UI;
using StreetStudio.Utilities;

using System;
using System.Collections.Generic;
using System.Linq;

using Unity.Entities;

using UnityEngine;

namespace StreetStudio.Systems.UI
{
	public partial class StreetStudioUISystem : ExtendedUISystemBase
	{
		private Entity workingEntity;
		private INetworkConfig? workingConfig;

#nullable disable
		private PrefabSystem prefabSystem;
		private PrefabUISystem prefabUISystem;
		private ToolSystem toolSystem;
		private StreetStudioSystem roadBuilderSystem;
		private StreetStudioGenerationDataSystem roadGenerationDataSystem;
		private StreetStudioToolSystem roadBuilderToolSystem;
		private DefaultToolSystem defaultToolSystem;
		private SimulationSystem simulationSystem;
		private StreetStudioNetSectionsUISystem netSectionsUISystem;
		private StreetStudioNetSectionsSystem netSectionsSystem;
		private CityConfigurationSystem cityConfigurationSystem;
		private StreetStudioConfigurationsUISystem roadBuilderConfigurationsUISystem;
		private StreetStudioGenericFunctionsSystem roadBuilderGenericFunctionsSystem;
		private ValueBindingHelper<StreetStudioToolMode> StreetStudioMode;
		private ValueBindingHelper<string> RoadId;
		private ValueBindingHelper<string> RoadName;
		private ValueBindingHelper<string> RoadSize;
		private ValueBindingHelper<string> RoadTypeName;
		private ValueBindingHelper<RoadLaneUIBinder[]> RoadLanes;
		private ValueBindingHelper<OptionSectionUIEntry[]> RoadOptions;
		private ValueBindingHelper<bool> RoadListView;
		private ValueBindingHelper<bool> IsPaused;
		private ValueBindingHelper<int> FpsMeterLevel;
		private ValueBindingHelper<bool> IsCustomRoadSelected;
		private ProxyAction _toolKeyBinding;
#nullable enable

		public StreetStudioToolMode Mode { get => StreetStudioMode; set => StreetStudioMode.Value = value; }
		public Entity WorkingEntity => workingEntity;

		protected override void OnCreate()
		{
			base.OnCreate();
			InitializeStudio();

			_toolKeyBinding = Mod.Settings!.GetAction(nameof(Setting.ToolToggle));
			_toolKeyBinding.shouldBeEnabled = true;

			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			prefabUISystem = World.GetOrCreateSystemManaged<PrefabUISystem>();
			toolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
			roadBuilderSystem = World.GetOrCreateSystemManaged<StreetStudioSystem>();
			roadGenerationDataSystem = World.GetOrCreateSystemManaged<StreetStudioGenerationDataSystem>();
			roadBuilderToolSystem = World.GetOrCreateSystemManaged<StreetStudioToolSystem>();
			defaultToolSystem = World.GetOrCreateSystemManaged<DefaultToolSystem>();
			simulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
			netSectionsUISystem = World.GetOrCreateSystemManaged<StreetStudioNetSectionsUISystem>();
			netSectionsSystem = World.GetOrCreateSystemManaged<StreetStudioNetSectionsSystem>();
			cityConfigurationSystem = World.GetOrCreateSystemManaged<CityConfigurationSystem>();
			roadBuilderConfigurationsUISystem = World.GetOrCreateSystemManaged<StreetStudioConfigurationsUISystem>();
			roadBuilderGenericFunctionsSystem = World.GetOrCreateSystemManaged<StreetStudioGenericFunctionsSystem>();

			toolSystem.EventToolChanged += OnToolChanged;

			StreetStudioMode = CreateBinding("StreetStudioToolMode", StreetStudioToolMode.None);
			RoadId = CreateBinding("GetRoadId", string.Empty);
			RoadName = CreateBinding("GetRoadName", "SetRoadName", string.Empty, name => UpdateRoad(x => x.Name = name));
			RoadSize = CreateBinding("GetRoadSize", string.Empty);
			RoadTypeName = CreateBinding("GetRoadTypeName", string.Empty);
			RoadLanes = CreateBinding("GetRoadLanes", new RoadLaneUIBinder[0]);
			RoadOptions = CreateBinding("GetRoadOptions", new OptionSectionUIEntry[0]);
			IsPaused = CreateBinding("IsPaused", simulationSystem.selectedSpeed == 0f);
			FpsMeterLevel = CreateBinding("FpsMeterLevel", 0);
			RoadListView = CreateBinding("RoadListView", "SetRoadListView", true);
			IsCustomRoadSelected = CreateBinding("IsCustomRoadSelected", false);

			CreateTrigger<RoadLaneUIBinder[]>("SetRoadLanes", x => UpdateRoad(c => UpdateLaneOrder(c, x)));
			CreateTrigger<int, int, int>("RoadOptionClicked", (x, y, z) => UpdateRoad(c => RoadOptionClicked(c, x, y, z)));
			CreateTrigger<int, int, int, int>("OptionClicked", (i, x, y, z) => UpdateRoad(c => LaneOptionClicked(c, i, x, y, z)));
			CreateTrigger<int>("DuplicateLane", x => UpdateRoad(c => DuplicateLane(c, x)));
			CreateTrigger<bool>("SetDragging", x => roadBuilderSystem.IsDragging = x);
			CreateTrigger("ToggleTool", () => ToggleTool());
			CreateTrigger("CreateNewPrefab", () => CreateNewPrefab(workingEntity));
			CreateTrigger("ClearTool", ClearTool);
			CreateTrigger("PickPrefab", PickPrefab);
			CreateTrigger("EditPrefab", EditPrefab);
			CreateTrigger("ManageRoads", ManageRoads);
			CreateTrigger("CancelActionPopup", CancelActionPopup);
		}

		protected override void OnUpdate()
		{
			IsPaused.Value = simulationSystem.selectedSpeed == 0f;
			FpsMeterLevel.Value = (int)(GameManager.instance?.settings?.general?.fpsMode ?? Game.Settings.GeneralSettings.FPSMode.Off);
			RoadId.Value = GetWorkingId();

			if (_toolKeyBinding.WasPerformedThisFrame())
			{
				ToggleTool();
			}

			base.OnUpdate();
		}

		private void OnToolChanged(ToolBaseSystem system)
		{
			if (system is not StreetStudioToolSystem)
			{
				StreetStudioMode.Value = StreetStudioToolMode.None;
			}
		}

		public void ToggleTool(bool? enable = null)
		{
			if (enable == false || (enable is null && toolSystem.activeTool is StreetStudioToolSystem))
			{
				ClearTool();
			}
			else
			{
				StreetStudioMode.Value = StreetStudioToolMode.Picker;

				toolSystem.selected = Entity.Null;
				toolSystem.activeTool = roadBuilderToolSystem;

				roadBuilderConfigurationsUISystem.UpdateConfigurationList();
			}
		}

		public void ClearTool()
		{
			StreetStudioMode.Value = StreetStudioToolMode.None;

			toolSystem.selected = Entity.Null;
			toolSystem.activeTool = defaultToolSystem;
		}

		private void ManageRoads()
		{
			StreetStudioMode.Value = StreetStudioToolMode.ManageRoads;
		}

		public void ShowActionPopup(Entity entity, PrefabBase prefab)
		{
			IsCustomRoadSelected.Value = prefab is INetworkBuilderPrefab;

			SetWorkingEntity(entity, StreetStudioToolMode.ActionSelection);
		}

		public string GetWorkingId()
		{
			if (Mode < StreetStudioToolMode.Editing)
			{
				return string.Empty;
			}

			if (Mode == StreetStudioToolMode.EditingNonExistent || workingEntity == Entity.Null)
			{
				return workingConfig?.ID ?? string.Empty;
			}

			if (prefabSystem.TryGetSpecificPrefab<PrefabBase>(EntityManager.GetComponentData<PrefabRef>(workingEntity), out var prefab) && prefab is INetworkBuilderPrefab builderPrefab)
			{
				return builderPrefab.Config?.ID ?? string.Empty;
			}

			return string.Empty;
		}

		public void CancelActionPopup()
		{
			SetWorkingEntity(Entity.Null, StreetStudioToolMode.Picker);
		}

		public void EditPrefab()
		{
			if (workingEntity != Entity.Null)
			{
				SetWorkingEntity(workingEntity, StreetStudioToolMode.Editing);
			}
		}

		public void PickPrefab()
		{
			if (workingEntity != Entity.Null && prefabSystem.TryGetSpecificPrefab<PrefabBase>(EntityManager.GetComponentData<PrefabRef>(workingEntity), out var prefab))
			{
				roadBuilderGenericFunctionsSystem.ActivateRoad(prefab.name);
			}
			else if (roadBuilderSystem.Configurations.TryGetValue(GetWorkingId(), out var networkPrefab) && networkPrefab?.Config?.ID is not null)
			{
				roadBuilderGenericFunctionsSystem.ActivateRoad(networkPrefab.Config.ID);
			}
		}

		public void CreateNewPrefab(Entity entity)
		{
			SetWorkingEntity(entity, StreetStudioToolMode.EditingSingle);
		}

		private void SetWorkingEntity(Entity entity, StreetStudioToolMode mode)
		{
			ResetStudio();
			workingEntity = entity;

			StreetStudioMode.Value = mode;

			roadBuilderConfigurationsUISystem.UpdateConfigurationList();

			if (mode is StreetStudioToolMode.Picker)
			{
				workingConfig = null;
				RoadListView.Value = true;
				return;
			}

			var config = roadBuilderSystem.GetOrGenerateConfiguration(workingEntity);

			SetWorkingPrefab(config, mode);
		}

		public void SetWorkingPrefab(INetworkConfig? config, StreetStudioToolMode mode)
		{
			StreetStudioMode.Value = mode;
			workingConfig = config;

			if (config is null)
			{
				return;
			}

			ResetStudio();
			RoadListView.Value = false;
			SetBindings(config);
		}

		private void UpdateRoad(Action<INetworkConfig> action)
		{
			var createNew = StreetStudioMode == StreetStudioToolMode.EditingSingle;
			var nonExistent = StreetStudioMode == StreetStudioToolMode.EditingNonExistent;
			var config = nonExistent ? workingConfig : createNew
				? roadBuilderSystem.GenerateConfiguration(workingEntity)
				: roadBuilderSystem.GetOrGenerateConfiguration(workingEntity);

			Mod.Log.Debug("UpdateRoad > " + StreetStudioMode.Value);

			if (config == null)
			{
				Mod.Log.Warn("Failed to create configuration?");

				return;
			}

			CaptureStudio(config);
			action(config);
			workingConfig = config;

			if (nonExistent)
			{
				roadBuilderSystem.UpdateRoad(config, Entity.Null, false);

				workingConfig = config;
			}
			else if (createNew)
			{
				roadBuilderSystem.UpdateRoad(config, workingEntity, true);

				StreetStudioMode.Value = StreetStudioToolMode.Editing;
			}
			else
			{
				roadBuilderSystem.UpdateRoad(config, workingEntity, false);
			}

			SetBindings(config);
		}

		private void SetBindings(INetworkConfig config)
		{
			netSectionsUISystem.RefreshEntries(config);
			RoadTypeName.Value = $"StreetStudio.Config[{config.GetType().Name}]";
			RoadName.Value = config.Name;
			RoadOptions.Value = RoadOptionsUtil.GetRoadOptions(config);
			RoadLanes.Value = From(config);

			var width = RoadLanes.Value.Sum(x => x.NetSection?.Width ?? 0);

			RoadSize.Value = RoadOptionsUtil.IsMetric() ? $"{Math.Round(width):0.#}m / {width / 8f:0.#}U" : $"{Math.Round(width * 3.28084f):0} ft / {width / 8f:0.#}U";
		}

		private void UpdateLaneOrder(INetworkConfig config, RoadLaneUIBinder[] roadLanes)
		{
			var newLanes = new List<LaneConfig>();

			foreach (var item in roadLanes)
			{
				var existingLane = config.Lanes.ElementAtOrDefault(item.Index);

				if (existingLane != null)
				{
					newLanes.Add(existingLane);
				}
				else
				{
					var lane = item.ToLaneConfig();

					if (lane.GroupPrefabName is not null && netSectionsSystem.LaneGroups.TryGetValue(lane.GroupPrefabName, out var group))
					{
						var similarLane = !Mod.Settings!.NoImitateLaneOptionsOnPlace ? FindSimilarLane(config.Lanes, newLanes.Count - 1, lane.GroupPrefabName) : null;

						if (similarLane != null)
						{
							lane.GroupOptions = new(similarLane.GroupOptions);

							foreach (var option in (group.Options ?? new StreetStudioLaneOption[0]).Where(x => x?.IgnoreForSimilarDuplicate == true))
							{
								lane.GroupOptions[option.Name ?? string.Empty] = option.DefaultValue;
							}
						}

						LaneOptionsUtil.FixGroupOptions(config, lane, group);
					}

					if (newLanes.Count == 0)
					{
						lane.Invert = true;
					}
					else if (newLanes.Count > 1)
					{
						lane.Invert = newLanes[newLanes.Count - 1].Invert;
					}
					else if (config.Lanes.Count > 1)
					{
						lane.Invert = config.Lanes[1].Invert;
					}

					newLanes.Add(lane);
				}
			}

			if (!Mod.Settings!.RemoveSafetyMeasures)
			{
				ReorderEdgeLanes(config, newLanes);
			}

			if (cityConfigurationSystem.leftHandTraffic)
			{
				newLanes.Reverse();
			}

			config.Lanes = newLanes;
		}

		private void ReorderEdgeLanes(INetworkConfig config, List<LaneConfig> newLanes)
		{
			var lastEdgeIndex = -1;

			for (var i = 0; i < newLanes.Count / 2; i++)
			{
				var lane = newLanes[i];

				if (!NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, lane, out var section, out var groupPrefab))
				{
					continue;
				}

				if (NetworkConfigExtensionsUtil.GetEdgeLaneInfo(section, groupPrefab, out var edgeInfo))
				{
					if (edgeInfo?.DoNotRequireBeingOnEdge ?? false)
					{
						lastEdgeIndex = i;
						continue;
					}

					if (lastEdgeIndex != i - 1)
					{
						newLanes.RemoveAt(i);
						newLanes.Insert(lastEdgeIndex + 1, lane);
						i = lastEdgeIndex = -1;
						continue;
					}

					lane.Invert = !cityConfigurationSystem.leftHandTraffic;

					lastEdgeIndex = i;
				}
			}

			lastEdgeIndex = newLanes.Count;

			for (var i = newLanes.Count - 1; i >= newLanes.Count / 2; i--)
			{
				var lane = newLanes[i];

				if (!NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, lane, out var section, out var groupPrefab))
				{
					continue;
				}

				if (NetworkConfigExtensionsUtil.GetEdgeLaneInfo(section, groupPrefab, out var edgeInfo))
				{
					if (edgeInfo?.DoNotRequireBeingOnEdge ?? false)
					{
						lastEdgeIndex = i;
						continue;
					}

					if (lastEdgeIndex != i + 1)
					{
						newLanes.RemoveAt(i);
						newLanes.Insert(lastEdgeIndex - 1, lane);
						i = lastEdgeIndex = newLanes.Count;
						continue;
					}

					lane.Invert = cityConfigurationSystem.leftHandTraffic;

					lastEdgeIndex = i;
				}
			}
		}

		private LaneConfig? FindSimilarLane(List<LaneConfig> array, int startIndex, string groupPrefabName)
		{
			if (array.Count == 0 || startIndex < 0 || startIndex >= array.Count)
			{
				return null;
			}

			// Check the starting index first
			if (array[startIndex].GroupPrefabName == groupPrefabName)
			{
				return array[startIndex];
			}

			var left = startIndex - 1;
			var right = startIndex + 1;

			while (left >= 0 || right < array.Count)
			{
				if (left >= 0 && array[left].GroupPrefabName == groupPrefabName)
				{
					return array[left];
				}

				if (right < array.Count && array[right].GroupPrefabName == groupPrefabName)
				{
					return array[right];
				}

				left--;
				right++;
			}

			return null;
		}

		private void DuplicateLane(INetworkConfig config, int index)
		{
			var existingLane = config.Lanes.ElementAtOrDefault(index);

			if (existingLane is null)
			{
				return;
			}

			config.Lanes.Insert(index, new LaneConfig
			{
				SectionPrefabName = existingLane.SectionPrefabName,
				GroupPrefabName = existingLane.GroupPrefabName,
				Invert = existingLane.Invert,
				GroupOptions = new(existingLane.GroupOptions),
			});
		}

		private void RoadOptionClicked(INetworkConfig config, int option, int id, int value)
		{
			RoadOptionsUtil.OptionClicked(config, option, id, value);

			if (!Mod.Settings!.UnrestrictedLanes)
			{
				config.Lanes.RemoveAll(x =>
				{
					if (!NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, x, out var section, out var group))
					{
						// A group lane with no variant allowed in the new road type is removed, lanes from mods that aren't loaded are kept
						return !string.IsNullOrEmpty(x.GroupPrefabName) && netSectionsSystem.LaneGroups.ContainsKey(x.GroupPrefabName!);
					}

					return !(section?.MatchCategories(config) ?? true) || !(group?.MatchCategories(config) ?? true);
				});
			}
		}

		private void LaneOptionClicked(INetworkConfig config, int index, int option, int id, int value)
		{
			var existingLane = config.Lanes.ElementAtOrDefault(index);

			if (existingLane != null)
			{
				LaneOptionsUtil.OptionClicked(roadGenerationDataSystem.RoadGenerationData, config, existingLane, option, id, value);
			}
		}

		private RoadLaneUIBinder[] From(INetworkConfig config)
		{
			var leftEdgeMissing = !Mod.Settings!.RemoveSafetyMeasures && config.Lanes.Count > 0 && !(NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, config.Lanes[0], out var leftSection, out var leftGroupPrefab) && NetworkConfigExtensionsUtil.GetEdgeLaneInfo(leftSection, leftGroupPrefab, out _));
			var rightEdgeMissing = !Mod.Settings.RemoveSafetyMeasures && config.Lanes.Count > 0 && !(NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, config.Lanes[config.Lanes.Count - 1], out var rightSection, out var rightGroupPrefab) && NetworkConfigExtensionsUtil.GetEdgeLaneInfo(rightSection, rightGroupPrefab, out _));
			var binders = new RoadLaneUIBinder[config.Lanes.Count + (leftEdgeMissing ? 1 : 0) + (rightEdgeMissing ? 1 : 0)];

			if (leftEdgeMissing)
			{
				binders[0] = new RoadLaneUIBinder { Index = int.MinValue, IsEdgePlaceholder = true, InvertImage = !cityConfigurationSystem.leftHandTraffic };
			}

			for (var i = 0; i < config.Lanes.Count; i++)
			{
				binders[leftEdgeMissing ? i + 1 : i] = CreateLaneBinder(config, config.Lanes[i], i, noDirectionBackward => FindDirection(config, noDirectionBackward));
			}

			if (rightEdgeMissing)
			{
				binders[binders.Length - 1] = new RoadLaneUIBinder { Index = int.MaxValue, IsEdgePlaceholder = true, InvertImage = cityConfigurationSystem.leftHandTraffic };
			}

			if (cityConfigurationSystem.leftHandTraffic)
			{
				var lhtBinders = new RoadLaneUIBinder[binders.Length];

				for (var i = 0; i < binders.Length; i++)
				{
					lhtBinders[i] = binders[binders.Length - i - 1];
				}

				return lhtBinders;
			}

			return binders;
		}

		// findDirection resolves which way a direction-less lane faces, it receives the lane's index
		private RoadLaneUIBinder CreateLaneBinder(INetworkConfig config, LaneConfig lane, int index, Func<int, bool> findDirection)
		{
			var isMetric = RoadOptionsUtil.IsMetric();
			var validSection = NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, lane, out var section, out var groupPrefab);
			var noDirection = validSection && ((section?.TryGet<StreetStudioLaneInfo>(out var laneInfo) == true && laneInfo.NoDirection) || ((groupPrefab?.TryGet<StreetStudioLaneInfo>(out var groupInfo) ?? false) && groupInfo.NoDirection));
			var isEdge = NetworkConfigExtensionsUtil.GetEdgeLaneInfo(section, groupPrefab, out _);
			var isBackward = noDirection ? findDirection(index) : lane.Invert;
			var width = validSection ? section?.CalculateWidth(groupPrefab, includeAggregates: true) ?? 0F : 0F;

			GetThumbnailAndColor(config, lane, section, groupPrefab, isBackward, out var thumbnail, out var color, out var texture);

			return new RoadLaneUIBinder
			{
				Index = index,
				Invert = lane.Invert,
				NoDirection = noDirection,
				InvertImage = isEdge && cityConfigurationSystem.leftHandTraffic ? !isBackward : isBackward,
				TwoWay = validSection && section?.SupportsTwoWay(lane, groupPrefab) == true,
				SectionPrefabName = string.IsNullOrEmpty(lane.GroupPrefabName) ? lane.SectionPrefabName : lane.GroupPrefabName,
				IsGroup = !string.IsNullOrEmpty(lane.GroupPrefabName),
				Options = LaneOptionsUtil.GenerateOptions(roadGenerationDataSystem.RoadGenerationData, config, lane),
				Texture = texture ?? "asphalt",
				// Invariant culture, comma decimal separators would produce invalid CSS
				Color = color is not Color c ? null : FormattableString.Invariant($"rgba({Mathf.RoundToInt(c.r * 255)}, {Mathf.RoundToInt(c.g * 255)}, {Mathf.RoundToInt(c.b * 255)}, {c.a:0.###})"),
				NetSection = new()
				{
					PrefabName = section?.name ?? groupPrefab?.name,
					IsGroup = !string.IsNullOrEmpty(lane.GroupPrefabName),
					IsEdge = isEdge,
					DisplayName = !validSection && groupPrefab is null ? "Unknown Lane" : GetAssetName((groupPrefab as PrefabBase) ?? section!),
					Width = width,
					WidthText = isMetric ? $"{width:0.##} m" : $"{Math.Round(width * 3.28084 * 4, MidpointRounding.AwayFromZero) / 4:0.##} ft",
					Thumbnail = thumbnail,
				}
			};
		}

		// Builds forward and backward previews of a single section or lane group, as they'd look in the lane bar
		public RoadLaneUIBinder[] CreatePreviewLanes(PrefabBase prefab, INetworkConfig config)
		{
			if (roadGenerationDataSystem.RoadGenerationData is null)
			{
				return new RoadLaneUIBinder[0];
			}

			var isGroup = prefab is LaneGroupPrefab;
			var lanes = new[] { false, true }.Select(invert => new LaneConfig
			{
				SectionPrefabName = isGroup ? null : prefab.name,
				GroupPrefabName = isGroup ? prefab.name : null,
				Invert = invert
			}).ToList();

			config.Lanes = lanes;

			return lanes.Select((lane, i) => CreateLaneBinder(config, lane, i, _ => lane.Invert)).ToArray();
		}

		private bool FindDirection(INetworkConfig config, int i)
		{
			if (config.Lanes.Count <= 3)
			{
				return false;
			}

			if (i < config.Lanes.Count / 2)
			{
				return config.Lanes[i + 1].Invert;
			}
			else
			{
				return config.Lanes[i - 1].Invert;
			}
		}

		// The back icon is shown for forward lanes and the front icon for backward ones, each falls back to the other when only one is set
		private static string? GetFacingThumbnail(StreetStudioLaneInfo info, bool invert)
		{
			var preferred = invert ? info.FrontThumbnail : info.BackThumbnail;
			var other = invert ? info.BackThumbnail : info.FrontThumbnail;

			return !string.IsNullOrEmpty(preferred) ? preferred : !string.IsNullOrEmpty(other) ? other : null;
		}

		private static void GetThumbnailAndColor(INetworkConfig config, LaneConfig lane, NetSectionPrefab? section, LaneGroupPrefab? groupPrefab, bool invert, out string? thumbnail, out Color? color, out string? texture)
		{
			thumbnail = null;
			color = null;
			texture = null;

			if (section is null)
			{
				return;
			}

			// The picked variant's decoration icons win, the group's are used for variants without their own
			if ((section.TryGet<StreetStudioLaneDecorationInfo>(out var decorationInfo) || (groupPrefab?.TryGet(out decorationInfo) ?? false))
				&& groupPrefab?.Options?.FirstOrDefault(x => x?.Type is LaneOptionType.Decoration) is StreetStudioLaneOption decorationOption)
			{
				var decorationThumbnail = LaneOptionsUtil.GetSelectedOptionValue(config, lane, decorationOption) switch
				{
					"G" => decorationInfo!.GrassThumbnail,
					"T" => decorationInfo!.TreeThumbnail,
					"GT" => decorationInfo!.GrassAndTreeThumbnail,
					_ => null
				};

				if (!string.IsNullOrEmpty(decorationThumbnail))
				{
					thumbnail = decorationThumbnail;
				}
			}

			if (section.TryGet<StreetStudioLaneInfo>(out var sectionInfo))
			{
				thumbnail ??= GetFacingThumbnail(sectionInfo, invert);

				if (sectionInfo.LaneColor != default)
				{
					color = sectionInfo.LaneColor;
				}

				if (sectionInfo.GroundTexture != default)
				{
					texture = sectionInfo.GroundTexture.ToString().ToLower();
				}
			}

			if (thumbnail is null && ImageSystem.GetIcon(section) is string sectionIcon)
			{
				thumbnail = sectionIcon;
			}

			if (groupPrefab?.TryGet<StreetStudioLaneInfo>(out var groupInfo) ?? false)
			{
				thumbnail ??= GetFacingThumbnail(groupInfo!, invert);

				if (groupInfo!.LaneColor != default && color is null)
				{
					color = groupInfo.LaneColor;
				}

				if (groupInfo.GroundTexture != default && texture is null)
				{
					texture = groupInfo.GroundTexture.ToString().ToLower();
				}
			}

			if (thumbnail is null && groupPrefab is not null)
			{
				thumbnail = ImageSystem.GetIcon(groupPrefab);
			}

			if (color is null)
			{
				if (config.Category.HasFlag(RoadCategory.Gravel))
				{
					texture ??= "gravel";
					color = new(143 / 255f, 131 / 255f, 97 / 255f);
				}
				else if (config.Category.HasFlag(RoadCategory.Tiled))
				{
					texture ??= "tiled";
					color = new(76 / 255f, 78 / 255f, 83 / 255f);
				}
			}

			if (section.IsTrainOrSubway())
			{
				texture ??= "train";
			}
			else if (section.IsBus())
			{
				texture ??= "paintedasphalt";
			}
		}

		public string GetLaneName(INetworkConfig config, LaneConfig lane)
		{
			var validSection = NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, config, lane, out var section, out var groupPrefab);

			if (validSection)
			{
				return GetAssetName((groupPrefab as PrefabBase) ?? section!);
			}

			return string.Empty;
		}

		public string GetAssetName(PrefabBase prefab)
		{
			GetTitleAndDescription(prefab, out var titleId, out var _);

			if (GameManager.instance.localizationManager.activeDictionary.TryGetValue(titleId, out var name))
			{
				return name;
			}

			return prefab.name.Replace('_', ' ').FormatWords();
		}

		public void GetTitleAndDescription(PrefabBase? prefab, out string titleId, out string descriptionId)
		{
			prefabUISystem.GetTitleAndDescription(prefab is null ? Entity.Null : prefabSystem.GetEntity(prefab), out titleId, out descriptionId);
		}
	}
}
