using Colossal.Json;
using StreetStudio.Domain.Configurations;
using StreetStudio.Domain.Enums;
using StreetStudio.LaneGroups;
using StreetStudio.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StreetStudio.Systems.UI
{
    public partial class StreetStudioUISystem
    {
        private readonly Stack<INetworkConfig> studioUndo = new();
        private readonly Stack<INetworkConfig> studioRedo = new();
        private bool studioRestoring;
        private ValueBindingHelper<bool> studioCanUndo = null!;
        private ValueBindingHelper<bool> studioCanRedo = null!;
        private ValueBindingHelper<string> studioStatus = null!;
        private ValueBindingHelper<int> studioApplyRevision = null!;

        private void InitializeStudio()
        {
            studioCanUndo = CreateBinding("Studio.CanUndo", false);
            studioCanRedo = CreateBinding("Studio.CanRedo", false);
            studioStatus = CreateBinding("Studio.Status", "Select a street to start designing.");
            studioApplyRevision = CreateBinding("Studio.ApplyRevision", 0);
            CreateTrigger("Studio.Undo", () => RestoreStudio(studioUndo, studioRedo));
            CreateTrigger("Studio.Redo", () => RestoreStudio(studioRedo, studioUndo));
            CreateTrigger<string>("Studio.Apply", ApplyStudio);
            CreateTrigger("Studio.Save", () => {
                if (workingConfig?.ID == null || !roadBuilderSystem.Configurations.ContainsKey(workingConfig.ID)) return;
                try { LocalSaveUtil.Save(workingConfig); studioStatus.Value = "Template saved to Street Studio's local library."; }
                catch (Exception ex) { Mod.Log.Warn(ex, "Template save failed"); studioStatus.Value = "Could not save template. Check the Street Studio log."; }
            });
        }

        private static INetworkConfig CloneStudio(INetworkConfig config)
        {
            var type = config.Type;
            try { config.Type = config.GetType().Name; return LocalSaveUtil.LoadFromJson(JSON.Dump(config))!; }
            finally { config.Type = type; }
        }

        private void ResetStudio()
        {
            studioUndo.Clear(); studioRedo.Clear();
            RefreshStudioHistory();
            studioStatus.Value = "Ready. Lane edits update the street live; quick designs apply when you press Apply.";
        }

        private void CaptureStudio(INetworkConfig config)
        {
            if (studioRestoring) return;
            // Bound history to avoid retaining whole designs for an unbounded session.
            if (studioUndo.Count >= 30) {
                var keep = studioUndo.Take(29).Reverse().ToArray();
                studioUndo.Clear(); foreach (var item in keep) studioUndo.Push(item);
            }
            studioUndo.Push(CloneStudio(config)); studioRedo.Clear(); RefreshStudioHistory();
        }

        private void RefreshStudioHistory()
        {
            studioCanUndo.Value = studioUndo.Count > 0; studioCanRedo.Value = studioRedo.Count > 0;
        }

        private static void CopyStudio(INetworkConfig target, INetworkConfig source)
        {
            target.Name = source.Name; target.Category = source.Category; target.Addons = source.Addons;
            target.Lanes = source.Lanes; target.MaxSlopeSteepness = source.MaxSlopeSteepness;
            target.PillarPrefabName = source.PillarPrefabName; target.ToolbarState = source.ToolbarState;
            if (target is RoadConfig road && source is RoadConfig saved) road.SpeedLimit = saved.SpeedLimit;
            if (target is TrackConfig track && source is TrackConfig savedTrack) track.SpeedLimit = savedTrack.SpeedLimit;
        }

        private void RestoreStudio(Stack<INetworkConfig> from, Stack<INetworkConfig> to)
        {
            if (workingConfig == null || from.Count == 0) return;
            var previous = CloneStudio(from.Peek());
            var current = CloneStudio(workingConfig);
            studioRestoring = true;
            try { UpdateRoad(c => CopyStudio(c, previous)); from.Pop(); to.Push(current); studioStatus.Value = "Design restored."; }
            finally { studioRestoring = false; RefreshStudioHistory(); }
        }

        public class StudioRecipe
        {
            public int Lanes { get; set; } = 2;
            public int Sidewalk { get; set; } = 4;
            public int Median { get; set; } = 2;
            public int Speed { get; set; } = 40;
            public bool Bikes { get; set; }
            public bool Buses { get; set; }
            public bool Parking { get; set; }
            public bool Trees { get; set; }
            public bool Grass { get; set; }
            public bool Markings { get; set; } = true;
        }

        private static StudioRecipe ParseStudioRecipe(string json)
        {
            var r = JSON.MakeInto<StudioRecipe>(JSON.Load(json));
            if (r == null || r.Lanes < 1 || r.Lanes > 6 || r.Sidewalk < 1 || r.Sidewalk > 9 ||
                !new[] {0,1,2,5}.Contains(r.Median) || r.Speed < 10 || r.Speed > 130)
                throw new ArgumentException("Invalid design dimensions");
            return r;
        }

        private static RoadAddons StudioDecorations(RoadAddons original, StudioRecipe r)
        {
            original &= ~(RoadAddons.GrassLeft | RoadAddons.GrassRight | RoadAddons.GrassCenter |
                RoadAddons.TreesLeft | RoadAddons.TreesRight | RoadAddons.TreesCenter);
            if (r.Grass) {
                if (!r.Bikes) original |= RoadAddons.GrassLeft | RoadAddons.GrassRight;
                if (r.Median == 5) original |= RoadAddons.GrassCenter;
            }
            if (r.Trees) {
                original |= RoadAddons.TreesLeft | RoadAddons.TreesRight;
                if (r.Median == 5) original |= RoadAddons.TreesCenter;
            }
            return original;
        }

        private void ApplyStudio(string json)
        {
            try {
                if (workingConfig is not RoadConfig) { studioStatus.Value = "Quick designs require an asphalt road. Use the lane editor for tracks and paths."; return; }
                var r = ParseStudioRecipe(json);
                var design = CloneStudio(workingConfig);
                design.Category = 0;
                design.Addons = StudioDecorations(design.Addons, r);
                var lanes = new List<LaneConfig>();
                LaneConfig Group(Type type, bool invert, params (string, string?)[] options) {
                    var name = type.FullName!;
                    if (!netSectionsSystem.LaneGroups.TryGetValue(name, out var group)) throw new InvalidOperationException("Lane group not loaded: " + name);
                    var lane = new LaneConfig { GroupPrefabName = name, Invert = invert };
                    foreach (var option in options) lane.GroupOptions[option.Item1] = option.Item2;
                    LaneOptionsUtil.FixGroupOptions(design, lane, group);
                    if (!NetworkPrefabGenerationUtil.GetNetSection(roadGenerationDataSystem.RoadGenerationData, design, lane, out var _, out var _))
                        throw new InvalidOperationException("No compatible lane variant: " + name);
                    // Decoration is stored in road edge-state flags. Keeping an override in
                    // GroupOptions would make the lane controls disagree with the game state.
                    lane.GroupOptions.Remove("Decoration");
                    return lane;
                }
                var decoration = (r.Grass ? "G" : "") + (r.Trees ? "T" : "");
                for (var side = 0; side < 2; side++) {
                    bool invert = side == 0;
                    var half = new List<LaneConfig>();
                    // Bike lanes on roads are integrated sidewalk variants. The standalone
                    // BikeGroupPrefab is restricted to pathways and must not be used here.
                    var sidewalkWidth = r.Bikes ? (r.Sidewalk <= 3 ? "3.5m" : r.Sidewalk == 4 ? "4.5m" : Math.Min(7, r.Sidewalk) + "m") : r.Sidewalk + "m";
                    half.Add(Group(typeof(SidewalkGroupPrefab), invert, ("Width", sidewalkWidth), ("Parking", r.Bikes ? "B" : ""), ("Decoration", decoration)));
                    if (r.Parking) half.Add(Group(typeof(ParkingGroupPrefab), invert, ("Parking Angle", "Parallel"), ("Markings", r.Markings ? "1" : "")));
                    if (r.Buses) half.Add(Group(typeof(BusGroupPrefab), invert, ("Lane Width", "3m")));
                    for (int i=0; i<r.Lanes; i++) half.Add(Group(typeof(CarGroupPrefab), invert, ("Lane Width", "3m"), ("Markings", r.Markings ? "" : "1")));
                    if (side == 1) half.Reverse();
                    lanes.AddRange(half);
                    if (side == 0 && r.Median > 0) lanes.Add(Group(typeof(MedianGroupPrefab), false, ("Median Width", r.Median + "m"), ("Decoration", r.Median == 5 ? decoration : "")));
                }
                if (cityConfigurationSystem.leftHandTraffic) foreach (var lane in lanes) lane.Invert = !lane.Invert;
                design.Lanes = lanes;
                ((RoadConfig)design).SpeedLimit = r.Speed * 2f;
                UpdateRoad(c => CopyStudio(c, design));
                studioStatus.Value = "Design applied. Use Undo to restore the previous street.";
                studioApplyRevision.Value++;
            }
            catch (Exception ex) { Mod.Log.Warn(ex, "Quick design failed"); studioStatus.Value = "Design not applied: " + ex.Message; }
        }
    }
}
