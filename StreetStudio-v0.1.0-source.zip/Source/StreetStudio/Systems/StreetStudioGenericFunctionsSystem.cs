﻿using Colossal.Core;
using Colossal.Entities;

using Game;
using Game.Common;
using Game.Net;
using Game.Prefabs;
using Game.Rendering;
using Game.SceneFlow;
using Game.Tools;
using Game.UI;
using Game.UI.Editor;
using Game.UI.InGame;

using StreetStudio.Domain.Components;
using StreetStudio.Domain.Enums;
using StreetStudio.Systems.UI;
using StreetStudio.Utilities;

using System.Collections.Generic;
using System.Linq;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioGenericFunctionsSystem : SystemBase
	{
#nullable disable
		private StreetStudioSystem roadBuilderSystem;
		private StreetStudioUISystem roadBuilderUISystem;
		private StreetStudioPrefabUpdateSystem roadBuilderUpdateSystem;
		private PrefabSystem prefabSystem;
		private PrefabUISystem prefabUISystem;
		private ToolSystem toolSystem;
		private EditorToolUISystem editorToolUISystem;
		private CameraUpdateSystem cameraUpdateSystem;
		private StreetStudioRoadTrackerSystem roadTrackerSystem;
#nullable enable

		private EntityQuery prefabRefQuery;
		private EntityQuery edgeRefQuery;

		private string? lastFindId;
		private int lastFindIndex;

		protected override void OnCreate()
		{
			base.OnCreate();

			roadBuilderSystem = World.GetOrCreateSystemManaged<StreetStudioSystem>();
			roadBuilderUISystem = World.GetOrCreateSystemManaged<StreetStudioUISystem>();
			roadBuilderUpdateSystem = World.GetOrCreateSystemManaged<StreetStudioPrefabUpdateSystem>();
			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			prefabUISystem = World.GetOrCreateSystemManaged<PrefabUISystem>();
			toolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
			editorToolUISystem = World.GetOrCreateSystemManaged<EditorToolUISystem>();
			cameraUpdateSystem = World.GetOrCreateSystemManaged<CameraUpdateSystem>();
			roadTrackerSystem = World.GetOrCreateSystemManaged<StreetStudioRoadTrackerSystem>();

			prefabRefQuery = SystemAPI.QueryBuilder()
				.WithAll<StreetStudioNetwork, PrefabRef>()
				.Build();

			edgeRefQuery = SystemAPI.QueryBuilder()
				.WithAll<StreetStudioNetwork, PrefabRef, Edge>()
				.Build();
		}

		protected override void OnUpdate()
		{ }

		public void ActivateRoad(string id)
		{
			if (!roadBuilderSystem.Configurations.TryGetValue(id, out var prefab))
			{
				return;
			}

			if (GameManager.instance.gameMode == GameMode.Editor)
			{
				editorToolUISystem.activeTool = editorToolUISystem.tools.First(x => x is EditorPrefabTool);

				MainThreadDispatcher.RegisterUpdater(() => toolSystem.ActivatePrefabTool(prefab.Prefab));
			}
			else
			{
				toolSystem.ActivatePrefabTool(prefab.Prefab);
			}
		}

		public void EditRoad(string id)
		{
			if (!roadBuilderSystem.Configurations.TryGetValue(id, out var prefab))
			{
				return;
			}

			roadBuilderUISystem.SetWorkingPrefab(prefab.Config, StreetStudioToolMode.EditingNonExistent);
		}

		public void FindRoad(string id)
		{
			if (!roadBuilderSystem.Configurations.TryGetValue(id, out var prefab))
			{
				return;
			}

			if (lastFindId != id)
			{
				lastFindIndex = 0;
			}

			lastFindId = id;

			var prefabEntity = prefabSystem.GetEntity(prefab.Prefab);
			var edgeEntities = edgeRefQuery.ToEntityArray(Allocator.Temp);
			var index = 0;
			var first = Entity.Null;

			for (var i = 0; i < edgeEntities.Length; i++)
			{
				var entity = edgeEntities[i];

				if (EntityManager.TryGetComponent<PrefabRef>(entity, out var prefabRef) && prefabRef.m_Prefab == prefabEntity)
				{
					if (index == lastFindIndex)
					{
						JumpTo(entity);

						return;
					}

					if (index == 0)
					{
						first = entity;
					}

					index++;
				}
			}

			lastFindIndex = 0;
			JumpTo(first);
		}

		private void JumpTo(Entity entity)
		{
			lastFindIndex++;

			if (cameraUpdateSystem.orbitCameraController != null && entity != Entity.Null)
			{
				cameraUpdateSystem.orbitCameraController.followedEntity = entity;
				cameraUpdateSystem.orbitCameraController.TryMatchPosition(cameraUpdateSystem.activeCameraController);
				cameraUpdateSystem.activeCameraController = cameraUpdateSystem.orbitCameraController;
			}
		}

		public void DeleteRoad(params string?[] ids)
		{
			GameManager.instance.userInterface.appBindings.ShowConfirmationDialog(new ConfirmationDialog("Options.SECTION[StreetStudio.StreetStudio.Mod]", ids.Length == 1 ? "StreetStudio.DIALOG_MESSAGE[DELETE]": "StreetStudio.DIALOG_MESSAGE[DELETEMANY]", "Common.DIALOG_ACTION[Yes]", "Common.DIALOG_ACTION[No]"), msg =>
			{
				if (msg == 0)
				{
					foreach (var item in ids)
					{
						ApplyDeleteRoad(item);
					}
				}
			});
		}

		private void ApplyDeleteRoad(string? id)
		{
			if (id is null || !roadBuilderSystem.Configurations.TryGetValue(id, out var prefab))
			{
				return;
			}

			prefab.Deleted = true;

			if (roadBuilderUISystem.GetWorkingId() == prefab.Config?.ID)
			{
				roadBuilderUISystem.SetWorkingPrefab(null, StreetStudioToolMode.Picker);
			}

			if (prefab.Config is not null)
			{
				LocalSaveUtil.DeletePreviousLocalConfig(prefab.Config);
			}

			var prefabEntity = prefabSystem.GetEntity(prefab.Prefab);
			var edgeEntities = prefabRefQuery.ToEntityArray(Allocator.Temp);
			var edgeList = new HashSet<Entity>();

			for (var i = 0; i < edgeEntities.Length; i++)
			{
				var entity = edgeEntities[i];

				if (EntityManager.TryGetComponent<PrefabRef>(entity, out var prefabRef) && prefabRef.m_Prefab == prefabEntity)
				{
					if (EntityManager.HasComponent<Edge>(entity))
					{
						var subObjects = EntityManager.TryGetBuffer<Game.Objects.SubObject>(entity, true, out var subObjectsBuffer)
							? subObjectsBuffer.ToNativeArray(Allocator.Temp)
							: default;

						EntityManager.AddComponent<Deleted>(entity);

						if (subObjects.IsCreated)
						{
							foreach (var item in subObjects)
							{
								EntityManager.AddComponent<Deleted>(item.m_SubObject);
							}
						}

						foreach (var edge in roadBuilderUpdateSystem.GetEdges(entity))
						{
							edgeList.Add(edge);
						}
					}
					else
					{
						EntityManager.AddComponent<StreetStudioToBeDeletedComponent>(entity);
						EntityManager.AddComponent<Updated>(entity);
					}

					EntityManager.RemoveComponent<StreetStudioNetwork>(entity);
				}
			}

			foreach (var entity in edgeList)
			{
				roadBuilderUpdateSystem.UpdateEdge(entity);
			}

			prefab.Prefab.components.Clear();

			roadBuilderSystem.UpdatePrefab(prefab.Prefab);

			// The tag was removed from the deleted edges, so the tracker won't pick this change up by itself
			roadTrackerSystem.Refresh();

			roadBuilderSystem.UpdateConfigurationList();
		}
	}
}
