﻿using Colossal.Entities;

using Game;
using Game.Common;
using Game.Net;
using Game.Prefabs;
using Game.Tools;

using StreetStudio.Domain.Components;
using StreetStudio.Domain.Prefabs;
using StreetStudio.Utilities;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioApplyTagSystem : GameSystemBase
	{
#nullable disable
		private PrefabSystem prefabSystem;
		private EntityQuery segmentQuery;
#nullable enable

		protected override void OnCreate()
		{
			base.OnCreate();

			prefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
			segmentQuery = SystemAPI.QueryBuilder()
				.WithAll<Edge, PrefabRef>()
				.WithAny<Created, Updated>()
				.WithNone<StreetStudioNetwork, Temp>()
				.Build();

			RequireForUpdate(segmentQuery);
		}

		protected override void OnUpdate()
		{
			var entities = segmentQuery.ToEntityArray(Allocator.Temp);

			for (var i = 0; i < entities.Length; i++)
			{
				var entity = entities[i];

				if (prefabSystem.TryGetSpecificPrefab<PrefabBase>(EntityManager.GetComponentData<PrefabRef>(entity), out var prefab) && prefab is INetworkBuilderPrefab builderPrefab && !builderPrefab.Deleted)
				{
					EntityManager.AddComponent<StreetStudioNetwork>(entity);

					if (EntityManager.TryGetComponent<Edge>(entity, out var edge))
					{
						EntityManager.AddComponent<StreetStudioNetwork>(edge.m_Start);
						EntityManager.AddComponent<StreetStudioNetwork>(edge.m_End);
					}
				}
			}
		}
	}
}
