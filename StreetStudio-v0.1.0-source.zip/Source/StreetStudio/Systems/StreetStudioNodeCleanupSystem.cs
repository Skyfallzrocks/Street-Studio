﻿using Colossal.Entities;

using Game;
using Game.Common;
using Game.Net;
using Game.Prefabs;
using Game.Tools;

using StreetStudio.Domain.Components;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Systems
{
	public partial class StreetStudioNodeCleanupSystem : GameSystemBase
	{
		private EntityQuery query;

		protected override void OnCreate()
		{
			base.OnCreate();

			query = SystemAPI.QueryBuilder().WithAll<StreetStudioToBeDeletedComponent>().WithNone<Updated, Temp>().Build();

			RequireForUpdate(query);
		}

		protected override void OnUpdate()
		{
			foreach (var entity in query.ToEntityArray(Allocator.Temp))
			{
				if (EntityManager.TryGetBuffer<ConnectedEdge>(entity, true, out var connectedEdgesBuffer))
				{
					// Copy before making structural changes, which invalidate the buffer
					var connectedEdges = connectedEdgesBuffer.ToNativeArray(Allocator.Temp);

					if (connectedEdges.Length == 0)
					{
						EntityManager.AddComponent<Deleted>(entity);

						if (EntityManager.TryGetBuffer<Game.Objects.SubObject>(entity, true, out var subObjectsBuffer))
						{
							foreach (var item in subObjectsBuffer.ToNativeArray(Allocator.Temp))
							{
								EntityManager.AddComponent<Deleted>(item.m_SubObject);
							}
						}
					}
					else
					{
						EntityManager.RemoveComponent<StreetStudioToBeDeletedComponent>(entity);

						var prefabSet = false;

						foreach (var edge in connectedEdges)
						{
							EntityManager.AddComponent<Updated>(edge.m_Edge);

							if (EntityManager.TryGetComponent<Edge>(edge.m_Edge, out var edgeData))
							{
								EntityManager.AddComponent<Updated>(edgeData.m_Start);
								EntityManager.AddComponent<Updated>(edgeData.m_End);
							}

							if (!prefabSet && EntityManager.TryGetComponent<PrefabRef>(edge.m_Edge, out var prefabRef))
							{
								EntityManager.SetComponentData(entity, new PrefabRef
								{
									m_Prefab = prefabRef.m_Prefab
								});

								prefabSet = true;
							}
						}
					}
				}
				else
				{
					EntityManager.AddComponent<Deleted>(entity);
				}
			}
		}
	}
}
