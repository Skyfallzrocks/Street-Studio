﻿using Game.Prefabs;
using Game.UI.Editor;
using Game.UI.Widgets;

using StreetStudio.Domain.Enums;
using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;
using System.Linq;

using Unity.Entities;

using UnityEngine;

namespace StreetStudio.Domain.Components.Prefabs
{
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab), typeof(LaneGroupPrefab) })]
	public class StreetStudioLaneInfo : ComponentBase
	{
		public RoadCategory RequireAll;
		public RoadCategory RequireAny;
		public RoadCategory RequireNone;
		public LaneGroundType GroundTexture;
		public Color LaneColor;
		public bool NoDirection;
		public bool Median;
		[CustomField(typeof(UIIconField))]
		public string? BackThumbnail;
		[CustomField(typeof(UIIconField))]
		public string? FrontThumbnail;
		public string[]? LaneThumbnails;
		public NetPieceRequirements[] PieceRequireAll = new NetPieceRequirements[0];
		public NetPieceRequirements[] PieceRequireAny = new NetPieceRequirements[0];
		public NetPieceRequirements[] PieceRequireNone = new NetPieceRequirements[0];

		internal bool StreetStudio { get; set; }

		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{ }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{ }

		public StreetStudioLaneInfo WithRequireAll(RoadCategory roadCategory)
		{
			RequireAll = roadCategory;
			return this;
		}

		public StreetStudioLaneInfo WithRequireAny(RoadCategory roadCategory)
		{
			RequireAny = roadCategory;
			return this;
		}

		public StreetStudioLaneInfo WithRequireNone(RoadCategory roadCategory)
		{
			RequireNone = roadCategory;
			return this;
		}

		public StreetStudioLaneInfo WithPieceRequireAll(params NetPieceRequirements[] array)
		{
			PieceRequireAll = array;
			return this;
		}

		public StreetStudioLaneInfo WithPieceRequireAny(params NetPieceRequirements[] array)
		{
			PieceRequireAny = array;
			return this;
		}

		public StreetStudioLaneInfo WithPieceRequireNone(params NetPieceRequirements[] array)
		{
			PieceRequireNone = array;
			return this;
		}

		public StreetStudioLaneInfo WithFrontThumbnail(string thumbnail)
		{
			FrontThumbnail = thumbnail;
			return this;
		}

		public StreetStudioLaneInfo WithBackThumbnail(string thumbnail)
		{
			BackThumbnail = thumbnail;
			return this;
		}

		public StreetStudioLaneInfo WithThumbnail(string thumbnail)
		{
			FrontThumbnail = BackThumbnail = thumbnail;
			return this;
		}

		public StreetStudioLaneInfo AddLaneThumbnail(string thumbnail)
		{
			if (LaneThumbnails is null)
			{
				LaneThumbnails = new[] { thumbnail };
			}
			else
			{
				LaneThumbnails = LaneThumbnails.Append(thumbnail).ToArray();
			}

			return this;
		}

		public StreetStudioLaneInfo WithColor(byte r, byte g, byte b, byte a = 255)
		{
			LaneColor = new Color(r / 255f, g / 255f, b / 255f, a / 255f);
			return this;
		}

		public StreetStudioLaneInfo WithGroundTexture(LaneGroundType groundType)
		{
			GroundTexture = groundType;
			return this;
		}

		public StreetStudioLaneInfo WithNoDirection()
		{
			NoDirection = true;
			return this;
		}

		public StreetStudioLaneInfo WithMedian()
		{
			Median = true;
			return this;
		}
	}
}
