﻿using Game.Prefabs;

using StreetStudio.Domain.Enums;
using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Components.Prefabs
{
	// Also allowed on lane groups, which makes every variant of the group an edge lane
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab), typeof(LaneGroupPrefab) })]
	public class StreetStudioEdgeLaneInfo : ComponentBase
	{
		public NetSectionPrefab? LeftSidePrefab;
		public NetSectionPrefab? RightSidePrefab;
		public bool AddSidewalkStateOnNode;
		public bool DoNotRequireBeingOnEdge;

		internal NetSectionPrefab? SidePrefab { set => LeftSidePrefab = RightSidePrefab = value; }

		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{ }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{ }

		public StreetStudioEdgeLaneInfo WithLeftSide(NetSectionPrefab prefab)
		{
			LeftSidePrefab = prefab;
			return this;
		}

		public StreetStudioEdgeLaneInfo WithRightSide(NetSectionPrefab prefab)
		{
			RightSidePrefab = prefab;
			return this;
		}

		public StreetStudioEdgeLaneInfo WithSide(NetSectionPrefab prefab)
		{
			LeftSidePrefab = RightSidePrefab = prefab;
			return this;
		}

		public StreetStudioEdgeLaneInfo WithAddSidewalkStateOnNode()
		{
			AddSidewalkStateOnNode = true;
			return this;
		}

		public StreetStudioEdgeLaneInfo WithDoNotRequireBeingOnEdge()
		{
			DoNotRequireBeingOnEdge = true;
			return this;
		}
	}
}
