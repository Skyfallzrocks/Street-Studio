﻿using Game.Prefabs;

using System;
using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Components.Prefabs
{
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab) })]
	public class StreetStudioIgnoreSection : ComponentBase
	{
		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{
		}

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{
		}
	}
}
