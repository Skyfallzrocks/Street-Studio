﻿using StreetStudio.Domain.Enums;

using System;

namespace StreetStudio.Domain.Components.Prefabs
{
	[Serializable]
	public class StreetStudioLaneOption
	{
		public LaneOptionType Type;
		public string? Name;
		public string? DefaultValue;
		public bool IgnoreForSimilarDuplicate;
		public StreetStudioLaneOptionValue[]? Options;
	}
}
