﻿using Game.Prefabs;

using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Components.Prefabs
{
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab), typeof(LaneGroupPrefab) })]
	public class StreetStudioLaneAggregate : ComponentBase
	{
		public StreetStudioAggregateSection[]? LeftSections;
		public StreetStudioAggregateSection[]? RightSections;

		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{ }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{ }
	}
}
