﻿using System;

namespace StreetStudio.Domain.Components.Prefabs
{
	[Serializable]
	public class LaneOptionCombination
	{
		public string? OptionName;
		public string? Value;
	}
}
