﻿using Game.Prefabs;

using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Components.Prefabs
{
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab) })]
	public class StreetStudioLaneGroup : ComponentBase
	{
		public LaneGroupPrefab? GroupPrefab;
		public LaneOptionCombination[]? Combination;

		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{ }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{ }
	}
}
