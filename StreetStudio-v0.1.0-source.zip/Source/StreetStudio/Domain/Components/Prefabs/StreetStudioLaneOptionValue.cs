﻿using Game.UI.Editor;
using Game.UI.Widgets;

using System;

namespace StreetStudio.Domain.Components.Prefabs
{
	[Serializable]
	public class StreetStudioLaneOptionValue
	{
		public string? Value;
		[CustomField(typeof(UIIconField))]
		public string? ThumbnailUrl;
	}
}
