﻿namespace StreetStudio.Domain.Components.Prefabs
{
	public class StreetStudioVanillaLaneGroup : StreetStudioLaneGroup { }
}
