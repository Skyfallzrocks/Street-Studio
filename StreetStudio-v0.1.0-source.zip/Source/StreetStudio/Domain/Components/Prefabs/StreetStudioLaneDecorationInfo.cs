﻿using Game.Prefabs;
using Game.UI.Editor;
using Game.UI.Widgets;

using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Components.Prefabs
{
	[ComponentMenu("StreetStudio/", new Type[] { typeof(NetSectionPrefab), typeof(LaneGroupPrefab) })]
	public class StreetStudioLaneDecorationInfo : ComponentBase
	{
		[CustomField(typeof(UIIconField))]
		public string? GrassThumbnail;
		[CustomField(typeof(UIIconField))]
		public string? TreeThumbnail;
		[CustomField(typeof(UIIconField))]
		public string? GrassAndTreeThumbnail;
		public string[]? LaneGrassThumbnail;
		public string[]? LaneTreeThumbnail;
		public string[]? LaneGrassAndTreeThumbnail;
		
		public override void GetArchetypeComponents(HashSet<ComponentType> components)
		{ }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{ }
	}
}
