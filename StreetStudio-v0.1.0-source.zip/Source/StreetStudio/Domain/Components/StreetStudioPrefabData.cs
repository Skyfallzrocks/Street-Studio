﻿using Unity.Entities;

namespace StreetStudio.Domain.Components
{
	public struct StreetStudioPrefabData : IComponentData
	{ }
}
