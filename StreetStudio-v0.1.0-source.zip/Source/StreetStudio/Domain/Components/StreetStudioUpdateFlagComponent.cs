﻿using Unity.Entities;

namespace StreetStudio.Domain.Components
{
	public struct StreetStudioUpdateFlagComponent : IComponentData
	{ }
}
