﻿using Colossal.Serialization.Entities;

using Unity.Entities;

namespace StreetStudio.Domain.Components
{
	public struct StreetStudioNetwork : IComponentData, IEmptySerializable
	{ }
}
