﻿using Colossal.Serialization.Entities;

using StreetStudio.Systems;

using Unity.Collections;
using Unity.Entities;

namespace StreetStudio.Domain.Components
{
	public struct NetworkConfigComponent : IComponentData, ISerializable
	{
		public FixedString4096Bytes NetworkId;

		public void Deserialize<TReader>(TReader reader) where TReader : IReader
		{
			StreetStudioSerializeSystem.DeserializeNetwork(reader);
		}

		public void Serialize<TWriter>(TWriter writer) where TWriter : IWriter
		{
			StreetStudioSerializeSystem.SerializeNetwork(writer, NetworkId.ConvertToString());
		}
	}
}
