﻿using Colossal.Serialization.Entities;

using StreetStudio.Domain.Enums;

using System;
using System.Collections.Generic;

namespace StreetStudio.Domain.Configurations
{
	public interface INetworkConfig : ISerializable
	{
		string? ID { get; set; }
		string? OriginalID { get; set; }
		string? Type { get; set; }
		ushort Version { get; set; }
		string? Name { get; set; }
		RoadCategory Category { get; set; }
		RoadAddons Addons { get; set; }
		float MaxSlopeSteepness { get; set; }
		List<LaneConfig> Lanes { get; set; }
		string? PillarPrefabName { get; set; }
		ShowInToolbarState ToolbarState { get; set; }
		List<string>? Playsets { get; set; }
		bool Uploaded { get; set; }

		void ApplyVersionChanges();
		Type GetPrefabType();
	}
}