﻿using Game.Prefabs;

using StreetStudio.Domain.Components;
using StreetStudio.Domain.Components.Prefabs;

using System.Collections.Generic;

using Unity.Entities;

namespace StreetStudio.Domain.Prefabs
{
	public class LaneGroupPrefab : PrefabBase
	{
		public StreetStudioLaneOption[]? Options;

		internal List<NetSectionPrefab> LinkedSections { get; set; } = new();
		internal bool StreetStudio { get; set; }

		public override void GetPrefabComponents(HashSet<ComponentType> components)
		{
			base.GetPrefabComponents(components);

			components.Add(ComponentType.ReadWrite<StreetStudioLaneGroupPrefabData>());
		}
	}
}
