﻿using Game.Prefabs;

using StreetStudio.Domain.Configurations;

namespace StreetStudio.Domain.Prefabs
{
	public interface INetworkBuilderPrefab
	{
		INetworkConfig? Config { get; set; }
		NetGeometryPrefab Prefab { get; }
		bool Deleted { get; set; }
	}
}
