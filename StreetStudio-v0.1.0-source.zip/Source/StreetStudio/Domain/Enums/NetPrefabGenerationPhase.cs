﻿namespace StreetStudio.Domain.Enums
{
	public enum NetPrefabGenerationPhase
	{
		None,
		NetLaneCreation,
		NetPieceCreation,
		NetSectionCreation,
		NetGroupsCreation,
		Complete
	}
}
