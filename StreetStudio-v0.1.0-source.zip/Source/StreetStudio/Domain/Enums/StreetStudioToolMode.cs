﻿namespace StreetStudio.Domain.Enums
{
	public enum StreetStudioToolMode
	{
		None = 0,
		Picker = 1,
		ManageRoads = 2,
		ActionSelection = 3,
		Editing = 4,
		EditingSingle = 5,
		EditingNonExistent = 6,
	}
}
