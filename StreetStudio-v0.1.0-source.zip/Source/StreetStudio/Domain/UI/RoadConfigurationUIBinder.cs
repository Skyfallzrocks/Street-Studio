﻿using StreetStudio.Domain.Enums;

namespace StreetStudio.Domain.UI
{
	public class RoadConfigurationUIBinder
	{
		public string? ID;
		public string? Name;
		public string? Thumbnail;
		public string? Author;
		public bool Locked;
		public bool Used;
		public bool IsNotInPlayset;
		public bool Available;
		public RoadCategory Category;
		public string[]? Tags;
	}
}
