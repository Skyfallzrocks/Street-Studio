﻿using StreetStudio.Domain.Enums;

namespace StreetStudio.Domain.UI
{
	public class NetSectionGroup
	{
		public LaneSectionType Type;
		public NetSectionItem[]? Sections;
	}
}
