﻿using Game.UI.Editor;

using StreetStudio.Systems;
using StreetStudio.Systems.UI;

using Unity.Entities;

namespace StreetStudio.Domain
{
	internal class StreetStudioEditorTool : EditorTool
	{
		private readonly StreetStudioUISystem _roadBuilderUISystem;

		public StreetStudioEditorTool(World world, StreetStudioToolSystem toolSystem, StreetStudioUISystem roadBuilderUISystem) : base(world)
		{
			_roadBuilderUISystem = roadBuilderUISystem;

			id = toolSystem.toolID;
			icon = "coui://streetstudioicons/EditStreetStudio.svg";
			tool = toolSystem;
		}

		protected override void OnEnable()
		{
			_roadBuilderUISystem.ToggleTool(true);
		}

		protected override void OnDisable()
		{
			_roadBuilderUISystem.ToggleTool(false);
		}
	}
}
