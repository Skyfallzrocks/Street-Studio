﻿using Colossal.Core;
using Colossal.IO.AssetDatabase;
using Colossal.Logging;
using Colossal.UI;

using Game;
using Game.Modding;
using Game.Prefabs;
using Game.SceneFlow;

using StreetStudio.Systems;
using StreetStudio.Systems.UI;
using StreetStudio.Utilities;

using System;
using System.IO;
using System.Threading.Tasks;

namespace StreetStudio
{
	public class Mod : IMod
	{
		public const string Id = nameof(StreetStudio);

		public static ILog Log { get; } = LogManager.GetLogger(nameof(StreetStudio)).SetShowsErrorsInUI(true);
		public static Setting? Settings { get; private set; }

		public void OnLoad(UpdateSystem updateSystem)
		{
			Log.Info(nameof(OnLoad));

#if DEBUG
			Log.SetEffectiveness(Level.Debug);
#endif

			UIManager.defaultUISystem.AddHostLocation("streetstudiothumbnails", FoldersUtil.TempFolder, true);

			if (GameManager.instance.modManager.TryGetExecutableAsset(this, out var asset))
			{
				UIManager.defaultUISystem.AddHostLocation($"streetstudioicons", Path.Combine(Path.GetDirectoryName(asset.path), "Icons"), false);
			}
			else
			{
				Log.Error("Load Failed, could not get executable path");
			}

			Settings = new Setting(this);
			Settings.RegisterKeyBindings();
			Settings.RegisterInOptionsUI();

			foreach (var item in new LocaleHelper("StreetStudio.Locale.json").GetAvailableLanguages())
			{
				GameManager.instance.localizationManager.AddSource(item.LocaleId, item);
			}

			foreach (var item in new LocaleHelper("StreetStudio.LocaleCustomAssets.json").GetAvailableLanguages())
			{
				GameManager.instance.localizationManager.AddSource(item.LocaleId, item);
			}

			AssetDatabase.global.LoadSettings(nameof(StreetStudio), Settings, new Setting(this));

			updateSystem.UpdateAfter<StreetStudioGenerationDataSystem, PrefabInitializeSystem>(SystemUpdatePhase.PrefabUpdate);
			updateSystem.UpdateAfter<StreetStudioPrefabUpdateSystem, PrefabInitializeSystem>(SystemUpdatePhase.PrefabUpdate);
			updateSystem.UpdateAt<StreetStudioInitializerSystem>(SystemUpdatePhase.MainLoop);
			updateSystem.UpdateAt<StreetStudioInfoViewFixSystem>(SystemUpdatePhase.PrefabUpdate);
			updateSystem.UpdateBefore<StreetStudioSerializeSystem>(SystemUpdatePhase.Serialize);
			updateSystem.UpdateAt<StreetStudioNodeCleanupSystem>(SystemUpdatePhase.Modification1);
			updateSystem.UpdateAt<StreetStudioSystem>(SystemUpdatePhase.Modification1);
			updateSystem.UpdateAt<StreetStudioApplyTagSystem>(SystemUpdatePhase.Modification2);
			updateSystem.UpdateAt<StreetStudioClearTagSystem>(SystemUpdatePhase.Modification2);
			updateSystem.UpdateAt<StreetStudioRoadTrackerSystem>(SystemUpdatePhase.Modification3);
			updateSystem.UpdateAt<StreetStudioToolSystem>(SystemUpdatePhase.ToolUpdate);
			updateSystem.UpdateAt<StreetStudioConfigCleanupSystem>(SystemUpdatePhase.MainLoop);
			updateSystem.UpdateAt<StreetStudioUISystem>(SystemUpdatePhase.UIUpdate);
			updateSystem.UpdateAt<StreetStudioNetSectionsUISystem>(SystemUpdatePhase.UIUpdate);
			updateSystem.UpdateAt<StreetStudioConfigurationsUISystem>(SystemUpdatePhase.UIUpdate);
			updateSystem.UpdateAt<StreetStudioRoadManagementUISystem>(SystemUpdatePhase.UIUpdate);
			updateSystem.UpdateAt<StreetStudioLaneSetupUISystem>(SystemUpdatePhase.UIUpdate);

			MainThreadDispatcher.RegisterUpdater(() => Task.Run(PdxModsUtil.Start));
		}

		public void OnDispose()
		{
			Log.Info(nameof(OnDispose));

			Settings?.UnregisterInOptionsUI();

			UIManager.defaultUISystem.RemoveHostLocation("streetstudiothumbnails");

			try
			{
				var tempDir = new DirectoryInfo(FoldersUtil.TempFolder);

				if (tempDir.Exists)
				{
					tempDir.Delete(true);
				}
			}
			catch (Exception ex)
			{
				Log.Warn(ex, "Failed to delete the temp folder");
			}
		}

		public static void ReloadActiveLocale()
		{
			try
			{
				GameManager.instance.localizationManager.ReloadActiveLocale();
			}
			catch (Exception ex)
			{
				Log.Warn(ex, "Unexpected error during dictionary refresh");
			}
		}
	}
}