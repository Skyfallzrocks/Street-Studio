﻿using Unity.Entities;

namespace StreetStudio.Utilities
{
	public static class GenericFunctionsUtil
	{
		static GenericFunctionsUtil()
		{
			var world = World.DefaultGameObjectInjectionWorld;


		}
	}
}
