﻿using Game.SceneFlow;

using StreetStudio.Domain.Configurations;
using StreetStudio.Domain.Enums;
using StreetStudio.Domain.UI;

using System.Collections.Generic;

using UnityEngine;

using static Game.Settings.InterfaceSettings;

namespace StreetStudio.Utilities
{
	public static class RoadOptionsUtil
	{
		private enum ActionType
		{
			SpeedLimit,
			Addons,
			RoadCategory,
			ShowInToolbar
		}

		public static OptionSectionUIEntry[] GetRoadOptions(INetworkConfig config)
		{
			var options = new List<OptionSectionUIEntry>();

			if (config is RoadConfig roadConfig)
			{
				options.Add(new()
				{
					Id = (int)ActionType.SpeedLimit,
					Name = LocaleHelper.Translate("StreetStudio.SpeedLimit", "Speed Limit"),
					Options = new[]
					{
						new OptionItemUIEntry
						{
							IsValue = true,
							Value = $"{(int)(roadConfig.SpeedLimit / (IsMetric() ? 2f : 3.218688f) / 5) * 5} {(IsMetric() ? "km/h" : "mph")}"
						}
					}
				});

				options.Add(new()
				{
					Id = (int)ActionType.RoadCategory,
					Name = LocaleHelper.Translate("StreetStudio.Category", "Category"),
					Options = new[]
					{
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Highway,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Highway}]",
							Icon = "coui://streetstudioicons/RB_HighwayWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Highway)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.PublicTransport,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.PublicTransport}]",
							Icon = "coui://streetstudioicons/RB_BusWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.PublicTransport)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Gravel,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Gravel}]",
							Icon = "coui://streetstudioicons/RB_GravelWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Gravel)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Tiled,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Tiled}]",
							Icon = "coui://streetstudioicons/RB_TiledWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Tiled)
						},
					}
				});
			}

			if (config is TrackConfig trackConfig)
			{
				options.Add(new()
				{
					Id = (int)ActionType.SpeedLimit,
					Name = LocaleHelper.Translate("StreetStudio.SpeedLimit", "Speed Limit"),
					Options = new[]
					{
						new OptionItemUIEntry
						{
							IsValue = true,
							Value =  $"{(int)(trackConfig.SpeedLimit / (IsMetric() ? 2f : 3.218688f) / 5) * 5} {(IsMetric() ? "km/h" : "mph")}"
						}
					}
				});

				options.Add(new()
				{
					Id = (int)ActionType.RoadCategory,
					Name = LocaleHelper.Translate("StreetStudio.Category", "Category"),
					Options = new[]
					{
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Tram,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Tram}]",
							Icon = "coui://streetstudioicons/RB_TramWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Tram)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Train,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Train}]",
							Icon = "coui://streetstudioicons/RB_TrainWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Train)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Subway,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Subway}]",
							Icon = "coui://streetstudioicons/RB_SubwayWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Subway)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Gravel,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Gravel}]",
							Icon = "coui://streetstudioicons/RB_GravelWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Gravel)
						},
						new OptionItemUIEntry
						{
							Id = (int)RoadCategory.Tiled,
							Name = $"StreetStudio.RoadCategory[{RoadCategory.Tiled}]",
							Icon = "coui://streetstudioicons/RB_TiledWhite.svg",
							Selected = config.Category.HasFlag(RoadCategory.Tiled)
						},
					}
				});
			}

			options.Add(new()
			{
				Id = (int)ActionType.Addons,
				Name = LocaleHelper.Translate("StreetStudio.Addons", "Addons"),
				Options = new[]
				{
					new OptionItemUIEntry
					{
						Id = (int)RoadAddons.GeneratesTrafficLights,
						Name = $"StreetStudio.RoadAddon[{RoadAddons.GeneratesTrafficLights}]",
						Icon = "coui://streetstudioicons/RB_TrafficLightsWhite.svg",
						Selected = config.Addons.HasFlag(RoadAddons.GeneratesTrafficLights),
						Hidden = config is not RoadConfig
					},
					new OptionItemUIEntry
					{
						Id = (int)RoadAddons.GeneratesZoningBlocks,
						Name = $"StreetStudio.RoadAddon[{RoadAddons.GeneratesZoningBlocks}]",
						Icon = "coui://streetstudioicons/RB_ZoneBlocks.svg",
						Selected = config.Addons.HasFlag(RoadAddons.GeneratesZoningBlocks),
						Hidden = config is not RoadConfig
					},
					new OptionItemUIEntry
					{
						Id = (int)RoadAddons.HasUndergroundWaterPipes,
						Name = $"StreetStudio.RoadAddon[{RoadAddons.HasUndergroundWaterPipes}]",
						Icon = "coui://streetstudioicons/RB_PipesWhite.svg",
						Selected = config.Addons.HasFlag(RoadAddons.HasUndergroundWaterPipes)
					},
					new OptionItemUIEntry
					{
						Id = (int)RoadAddons.HasUndergroundElectricityCable,
						Name = $"StreetStudio.RoadAddon[{RoadAddons.HasUndergroundElectricityCable}]",
						Icon = "coui://streetstudioicons/RB_UndergroundElectricityWhite.svg",
						Selected = config.Addons.HasFlag(RoadAddons.HasUndergroundElectricityCable)
					},
					new OptionItemUIEntry
					{
						Id = (int)RoadAddons.RequiresUpgradeForElectricity,
						Name = $"StreetStudio.RoadAddon[{RoadAddons.RequiresUpgradeForElectricity}]",
						Icon = "coui://streetstudioicons/RB_UpgradeElectricityWhite.svg",
						Disabled = !config.Addons.HasFlag(RoadAddons.HasUndergroundElectricityCable),
						Selected = config.Addons.HasFlag(RoadAddons.RequiresUpgradeForElectricity)
					}
				}
			});

			options.Add(new()
			{
				Id = (int)ActionType.ShowInToolbar,
				Name = LocaleHelper.Translate("StreetStudio.ShowInToolbar", "Toolbar View"),
				IsToggle = true,
				Options = new[]
				{
					new OptionItemUIEntry
					{
						Id = (int)ShowInToolbarState.Hide,
						Name = $"StreetStudio.ShowInToolbarState[{ShowInToolbarState.Hide}]",
						Icon = "coui://streetstudioicons/RB_Hide.svg",
						Selected = config.ToolbarState == ShowInToolbarState.Hide
					},
					new OptionItemUIEntry
					{
						Id = (int)ShowInToolbarState.Inherit,
						Name = $"StreetStudio.ShowInToolbarState[{ShowInToolbarState.Inherit}]",
						Icon = "coui://streetstudioicons/RB_Any.svg",
						Selected = config.ToolbarState == ShowInToolbarState.Inherit
					},
					new OptionItemUIEntry
					{
						Id = (int)ShowInToolbarState.Show,
						Name = $"StreetStudio.ShowInToolbarState[{ShowInToolbarState.Show}]",
						Icon = "coui://streetstudioicons/RB_Show.svg",
						Selected = config.ToolbarState == ShowInToolbarState.Show
					},
				}
			});

			return options.ToArray();
		}

		public static void OptionClicked(INetworkConfig config, int option, int id, int value)
		{
			switch ((ActionType)option)
			{
				case ActionType.SpeedLimit:
					var multiplier = 5 * (IsMetric() ? 2f : 3.218688f);

					if (config is RoadConfig roadConfig)
					{
						roadConfig.SpeedLimit = Mathf.Max(roadConfig.SpeedLimit + (value * multiplier), multiplier);
					}

					if (config is TrackConfig trackConfig)
					{
						trackConfig.SpeedLimit = Mathf.Max(trackConfig.SpeedLimit + (value * multiplier), multiplier);
					}

					break;

				case ActionType.RoadCategory:
					if (config is TrackConfig)
					{
						// Track surfaces combine with the track type instead of replacing it
						const RoadCategory surfaces = RoadCategory.Gravel | RoadCategory.Tiled;
						var category = (RoadCategory)id;

						if ((category & surfaces) != 0)
						{
							config.Category = config.Category.HasFlag(category)
								? config.Category & ~category
								: (config.Category & ~surfaces) | category;
						}
						else
						{
							config.Category = category | (config.Category & surfaces);
						}

						break;
					}

					if (config.Category.HasFlag((RoadCategory)id))
					{
						config.Category = config is TrackConfig ? RoadCategory.Tram : RoadCategory.Road;
					}
					else
					{
						config.Category = (RoadCategory)id;
					}

					break;

				case ActionType.Addons:
					var addon = (RoadAddons)id;

					if (config.Addons.HasFlag(addon))
					{
						config.Addons &= ~addon;
					}
					else
					{
						config.Addons |= addon;
					}

					break;

				case ActionType.ShowInToolbar:
					config.ToolbarState = (ShowInToolbarState)id;
					break;
			}
		}

		public static bool IsMetric()
		{
			return GameManager.instance?.settings?.userInterface?.unitSystem is null or UnitSystem.Metric;
		}
	}
}
