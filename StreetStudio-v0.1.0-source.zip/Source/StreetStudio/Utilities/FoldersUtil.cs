﻿using Colossal.PSI.Environment;

using System.IO;

namespace StreetStudio.Utilities
{
	public static class FoldersUtil
	{
		public static string ContentFolder { get; }
		public static string SettingsFolder { get; }
		public static string TempFolder { get; }
		public static string GameUIPath { get; }

		static FoldersUtil()
		{
			ContentFolder = Path.Combine(EnvPath.kUserDataPath, "ModsData", nameof(StreetStudio));

			SettingsFolder = Path.Combine(EnvPath.kUserDataPath, "ModsSettings", nameof(StreetStudio));

			TempFolder = Path.Combine(EnvPath.kTempDataPath, nameof(StreetStudio));

			GameUIPath = Path.Combine(EnvPath.kContentPath, "Game", "~UI~");

			if (Directory.Exists(TempFolder))
			{
				new DirectoryInfo(TempFolder).Delete(true);
			}

			Directory.CreateDirectory(ContentFolder);
			Directory.CreateDirectory(TempFolder);
		}
	}
}
