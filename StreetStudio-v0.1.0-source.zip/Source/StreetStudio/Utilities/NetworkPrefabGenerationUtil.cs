﻿using Colossal.PSI.Common;

using Game.Prefabs;
using Game.SceneFlow;

using StreetStudio.Domain;
using StreetStudio.Domain.Components.Prefabs;
using StreetStudio.Domain.Configurations;
using StreetStudio.Domain.Enums;
using StreetStudio.Domain.Prefabs;

using System;
using System.Collections.Generic;
using System.Linq;

using Unity.Mathematics;

using UnityEngine;

namespace StreetStudio.Utilities
{
	public class NetworkPrefabGenerationUtil
	{
		private readonly RoadGenerationData _roadGenerationData;
		private StreetStudioEdgeLaneInfo? leftSectionEdgeInfo;
		private StreetStudioEdgeLaneInfo? rightSectionEdgeInfo;

		public INetworkBuilderPrefab NetworkPrefab { get; }

		public NetworkPrefabGenerationUtil(INetworkBuilderPrefab prefab, RoadGenerationData roadGenerationData)
		{
			_roadGenerationData = roadGenerationData;

			NetworkPrefab = prefab;
		}

		public static INetworkBuilderPrefab CreatePrefab(INetworkConfig config)
		{
			var prefab = (config is null ? null : ScriptableObject.CreateInstance(config.GetPrefabType()) as INetworkBuilderPrefab)
				?? throw new Exception("Unknown config type " + (config?.GetType().Name ?? "NULL"));

			prefab.Config = config;
			prefab.Prefab.name = config?.ID;
			prefab.Prefab.m_Sections = new NetSectionInfo[0];
			prefab.Prefab.m_EdgeStates = new NetEdgeStateInfo[0];
			prefab.Prefab.m_NodeStates = new NetNodeStateInfo[0];

			Mod.Log.DebugFormat("CreatePrefab: {0}", prefab.Prefab.name);

			return prefab;
		}

		public bool GenerateRoad(bool generateId = true)
		{
			try
			{
				GenerateRoadInternal(generateId);

				return true;
			}
			catch (Exception ex)
			{
				Mod.Log.Error(ex, "Unhandled Error During Road Generation");

				return false;
			}
		}

		private void GenerateRoadInternal(bool generateId)
		{
			var cfg = NetworkPrefab.Config;
			var prefab = NetworkPrefab.Prefab;

			if (cfg is null)
			{
				throw new NullReferenceException($"Trying to generate road with NULL configuration - '{NetworkPrefab.Prefab.name}'");
			}

			Mod.Log.Debug($"GenerateRoadInternal: id={cfg.ID} name={cfg.Name} type={cfg.GetType().Name} lanes={cfg.Lanes?.Count} generateId={generateId}");

			prefab.isDirty = true;
			prefab.name = cfg.ID;
			prefab.m_MaxSlopeSteepness = cfg.MaxSlopeSteepness;
			prefab.m_InvertMode = CompositionInvertMode.InvertLefthandTraffic;
			prefab.m_Sections = Fix(GenerateSections()).ToArray();
			prefab.m_NodeStates = GenerateNodeStates().ToArray();
			prefab.m_EdgeStates = GenerateEdgeStates().ToArray();
			prefab.m_AggregateType = _roadGenerationData.AggregateNetPrefabs.TryGetValue(GetAggregateName(), out var aggregate) ? aggregate : null;

			if (cfg is RoadConfig roadConfig)
			{
				var roadPrefab = (NetworkPrefab as RoadPrefab)!;
				roadPrefab.m_SpeedLimit = roadConfig.SpeedLimit;
				roadPrefab.m_RoadType = roadConfig.Category.HasFlag(RoadCategory.PublicTransport) ? RoadType.PublicTransport : RoadType.Normal;
				roadPrefab.m_TrafficLights = roadConfig.Addons.HasFlag(RoadAddons.GeneratesTrafficLights);
				roadPrefab.m_HighwayRules = roadConfig.Category.HasFlag(RoadCategory.Highway);
				roadPrefab.m_ZoneBlock = roadConfig.Addons.HasFlag(RoadAddons.GeneratesZoningBlocks) ? _roadGenerationData.ZoneBlockPrefab : null;
			}

			if (cfg is TrackConfig trackConfig)
			{
				var trackPrefab = (NetworkPrefab as TrackBuilderPrefab)!;
				trackPrefab.m_SpeedLimit = trackConfig.SpeedLimit;
				trackPrefab.m_TrackType =
					cfg.Category.HasFlag(RoadCategory.Train) ? Game.Net.TrackTypes.Train :
					cfg.Category.HasFlag(RoadCategory.Subway) ? Game.Net.TrackTypes.Subway :
					cfg.Category.HasFlag(RoadCategory.Tram) ? Game.Net.TrackTypes.Tram :
					Game.Net.TrackTypes.None;
			}

			prefab.components.ForEach(UnityEngine.Object.Destroy);
			prefab.components.Clear();
			prefab.components.AddRange(GenerateComponents());

			foreach (var item in prefab.components)
			{
				item.prefab = prefab;
				item.name = item.GetType().Name;
			}

			if (generateId)
			{
				//ThumbnailGenerationUtil.DeleteThumbnail(NetworkPrefab.Config.ID);

				NetworkPrefab.Prefab.name = cfg.ID = $"{NetworkPrefab.GetType().Name.ToLower()[0]}{Guid.NewGuid()}-{PlatformManager.instance.userSpecificPath}";

				// A new ID is a new version of the road that hasn't been uploaded yet
				cfg.Uploaded = false;
			}
#if !DEBUG
			if (GameManager.instance.configuration.uiDeveloperMode)
			{
				return;
			}
#endif
			var thumbnail = new ThumbnailGenerationUtil(NetworkPrefab, _roadGenerationData).GenerateThumbnail();

			if (thumbnail is not null and not "")
			{
				prefab.AddOrGetComponent<UIObject>().m_Icon = thumbnail;
			}
		}

		private string GetAggregateName()
		{
			var category = NetworkPrefab.Config!.Category;

			if (category.HasFlag(RoadCategory.Subway))
			{
				return "Subway Track";
			}

			if (category.HasFlag(RoadCategory.Train))
			{
				return "Train Track";
			}

			if (category.HasFlag(RoadCategory.Tram))
			{
				return "Tram Track";
			}

			if (category.HasFlag(RoadCategory.Pathway))
			{
				return "Pathway";
			}

			if (category.HasFlag(RoadCategory.Highway))
			{
				return "Highway";
			}

			if (category.HasFlag(RoadCategory.PublicTransport))
			{
				return "Public Transport Lane";
			}

			if ((leftSectionEdgeInfo?.AddSidewalkStateOnNode ?? false) || (rightSectionEdgeInfo?.AddSidewalkStateOnNode ?? false))
			{
				return "Street";
			}

			return "Alley";
		}

		private IEnumerable<NetNodeStateInfo> GenerateNodeStates()
		{
			if ((NetworkPrefab.Config!.Category & RoadCategory.Gravel) != 0)
			{
				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new[] { NetPieceRequirements.Pavement, NetPieceRequirements.Elevated, NetPieceRequirements.Tunnel },
					m_SetState = new[] { NetPieceRequirements.Gravel }
				};

				// Matches the edge states, paved gravel nodes switch to pavement
				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new[] { NetPieceRequirements.Pavement },
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = new[] { NetPieceRequirements.Pavement }
				};
			}
			else if ((NetworkPrefab.Config.Category & RoadCategory.Tiled) != 0)
			{
				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new[]
					{
						NetPieceRequirements.Pavement,
						NetPieceRequirements.Gravel,
					},
					m_SetState = new[]
					{
						NetPieceRequirements.Tiles
					}
				};

				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new[]
					{
						NetPieceRequirements.Pavement,
						NetPieceRequirements.Gravel,
					},
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = new[]
					{
						NetPieceRequirements.Pavement
					}
				};
			}
			else if ((NetworkPrefab.Config.Category & (RoadCategory.Train | RoadCategory.Subway | RoadCategory.Gravel | RoadCategory.Pathway)) == 0)
			{
				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = new[] { NetPieceRequirements.Pavement }
				};
			}

			// Left maps to the Opposite states, matching the grass addons
			var addOppositeSidewalk = leftSectionEdgeInfo?.AddSidewalkStateOnNode ?? false;
			var addSidewalk = rightSectionEdgeInfo?.AddSidewalkStateOnNode ?? false;

			if (addSidewalk || addOppositeSidewalk)
			{
				yield return new NetNodeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = addSidewalk && addOppositeSidewalk
						? new[] { NetPieceRequirements.Sidewalk, NetPieceRequirements.OppositeSidewalk }
						: new[] { addSidewalk ? NetPieceRequirements.Sidewalk : NetPieceRequirements.OppositeSidewalk }
				};
			}
		}

		private IEnumerable<NetEdgeStateInfo> GenerateEdgeStates()
		{
			var states = new List<NetPieceRequirements>();

			if (NetworkPrefab.Config!.Category.HasFlag(RoadCategory.Pathway))
			{
				yield break;
			}

			if ((NetworkPrefab.Config.Category & (RoadCategory.Train | RoadCategory.Subway | RoadCategory.Gravel | RoadCategory.Tiled)) == 0)
			{
				states.Add(NetPieceRequirements.Pavement);
			}

			var trackLanes = NetworkPrefab.Prefab.m_Sections.SelectMany(x => x.m_Section.FindLanes<TrackLane>()).ToList();

			if (trackLanes.Any(x => x.m_TrackType is Game.Net.TrackTypes.Tram))
			{
				states.Add(NetPieceRequirements.TramTrack);
				states.Add(NetPieceRequirements.OppositeTramTrack);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.GrassLeft))
			{
				states.Add(NetPieceRequirements.OppositeGrass);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.GrassRight))
			{
				states.Add(NetPieceRequirements.SideGrass);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.GrassCenter))
			{
				states.Add(NetPieceRequirements.MiddleGrass);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.TreesLeft))
			{
				states.Add(NetPieceRequirements.OppositeTrees);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.TreesRight))
			{
				states.Add(NetPieceRequirements.SideTrees);
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.TreesCenter))
			{
				states.Add(NetPieceRequirements.MiddleTrees);
			}

			if (states.Count != 0)
			{
				yield return new NetEdgeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = states.ToArray()
				};
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Gravel))
			{
				yield return new NetEdgeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					// NetPieceRequirements is not a flags enum, each requirement is its own element
					m_RequireNone = new[] { NetPieceRequirements.Pavement, NetPieceRequirements.Elevated, NetPieceRequirements.Tunnel },
					m_SetState = new[] { NetPieceRequirements.Gravel }
				};

				yield return new NetEdgeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new[] { NetPieceRequirements.Pavement, NetPieceRequirements.Elevated, NetPieceRequirements.Tunnel },
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = new[] { NetPieceRequirements.Pavement }
				};
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tiled))
			{
				yield return new NetEdgeStateInfo
				{
					m_RequireAll = new NetPieceRequirements[0],
					m_RequireAny = new NetPieceRequirements[0],
					m_RequireNone = new NetPieceRequirements[0],
					m_SetState = new[] { NetPieceRequirements.Tiles }
				};
			}
		}

		private IEnumerable<NetSectionInfo> GenerateSections()
		{
			// Missing sections are dropped first, so the sides and median are placed relative to the lanes that remain
			var lanes = new List<(LaneConfig lane, NetSectionPrefab? section, LaneGroupPrefab? groupPrefab)>();

			foreach (var configLane in NetworkPrefab.Config!.Lanes)
			{
				if (GetNetSection(_roadGenerationData, NetworkPrefab.Config, configLane, out var foundSection, out var foundGroupPrefab))
				{
					lanes.Add((configLane, foundSection, foundGroupPrefab));
				}
				else
				{
					Mod.Log.Warn($"NET SECTION '{configLane.SectionPrefabName ?? configLane.GroupPrefabName ?? "NULL"}' could not be found");
				}
			}

			for (var i = 0; i < lanes.Count; i++)
			{
				var (lane, section, groupPrefab) = lanes[i];

				if (i == 0 && (NetworkConfigExtensionsUtil.GetEdgeLaneInfo(section, groupPrefab, out leftSectionEdgeInfo) | !Mod.Settings!.DoNotAddSides))
				{
					yield return new NetSectionInfo
					{
						m_Section = leftSectionEdgeInfo?.LeftSidePrefab ?? _roadGenerationData.NetSectionPrefabs[GetSideName()],
						m_Invert = true
					};
				}

				if (i == lanes.Count / 2 && lanes.Count % 2 == 0)
				{
					yield return new NetSectionInfo
					{
						m_Section = _roadGenerationData.NetSectionPrefabs[GetEmptyMedianName()],
					};
				}

				StreetStudioLaneInfo? laneInfo = null;

				// A variant without its own lane info uses the group's median and piece requirements
				if (section?.TryGet<StreetStudioLaneInfo>(out laneInfo) != true)
				{
					groupPrefab?.TryGet(out laneInfo);
				}

				if (section?.TryGet<StreetStudioLaneAggregate>(out var aggregate) == true || (groupPrefab?.TryGet(out aggregate) ?? false))
				{
					var sections = new List<NetSectionInfo>();

					if (aggregate?.LeftSections != null)
					{
						sections.AddRange(aggregate.LeftSections.Where(x => x?.Section is not null).Select(x => new NetSectionInfo
						{
							m_Section = x.Section,
							m_Invert = x.Invert ? !lane.Invert : lane.Invert,
							m_RequireAll = x.PieceRequireAll,
							m_RequireAny = x.PieceRequireAny,
							m_RequireNone = x.PieceRequireNone,
						}));
					}

					sections.Add(new NetSectionInfo
					{
						m_Section = section,
						m_Invert = lane.Invert,
						m_Median = laneInfo?.Median ?? false,
						m_RequireAll = laneInfo?.PieceRequireAll ?? new NetPieceRequirements[0],
						m_RequireAny = laneInfo?.PieceRequireAny ?? new NetPieceRequirements[0],
						m_RequireNone = laneInfo?.PieceRequireNone ?? new NetPieceRequirements[0],
					});

					if (aggregate?.RightSections != null)
					{
						sections.AddRange(aggregate.RightSections.Where(x => x?.Section is not null).Select(x => new NetSectionInfo
						{
							m_Section = x.Section,
							m_Invert = x.Invert ? !lane.Invert : lane.Invert,
							m_RequireAll = x.PieceRequireAll,
							m_RequireAny = x.PieceRequireAny,
							m_RequireNone = x.PieceRequireNone,
						}));
					}

					if (lane.Invert)
					{
						sections.Reverse();
					}

					foreach (var item in sections)
					{
						yield return item;
					}
				}
				else
				{
					yield return new NetSectionInfo
					{
						m_Section = section,
						m_Invert = lane.Invert,
						m_Median = laneInfo?.Median ?? false,
						m_RequireAll = laneInfo?.PieceRequireAll ?? new NetPieceRequirements[0],
						m_RequireAny = laneInfo?.PieceRequireAny ?? new NetPieceRequirements[0],
						m_RequireNone = laneInfo?.PieceRequireNone ?? new NetPieceRequirements[0],
					};
				}

				if (i == lanes.Count - 1 && (NetworkConfigExtensionsUtil.GetEdgeLaneInfo(section, groupPrefab, out rightSectionEdgeInfo) | !Mod.Settings!.DoNotAddSides))
				{
					yield return new NetSectionInfo
					{
						m_Section = rightSectionEdgeInfo?.RightSidePrefab ?? _roadGenerationData.NetSectionPrefabs[GetSideName()],
						m_Invert = false
					};
				}
			}
		}

		public static bool GetNetSection(RoadGenerationData? roadGenerationData, INetworkConfig config, LaneConfig item, out NetSectionPrefab? section, out LaneGroupPrefab? groupPrefab)
		{
			if (!string.IsNullOrEmpty(item.SectionPrefabName)
				&& roadGenerationData is not null
				&& roadGenerationData.NetSectionPrefabs.TryGetValue(item.SectionPrefabName ?? string.Empty, out section))
			{
				groupPrefab = default;
				return true;
			}
			else if (!string.IsNullOrEmpty(item.GroupPrefabName)
				&& roadGenerationData is not null
				&& roadGenerationData.LaneGroupPrefabs.TryGetValue(item.GroupPrefabName ?? string.Empty, out groupPrefab)
				&& GetNetSection(config, item, groupPrefab, out section))
			{
				return true;
			}

			groupPrefab = default;
			section = default;
			return false;
		}

		private static bool GetNetSection(INetworkConfig config, LaneConfig lane, LaneGroupPrefab group, out NetSectionPrefab? section)
		{
			// Decorations don't pick a variant, they're applied to whichever variant is picked
			var options = (group.Options ?? new StreetStudioLaneOption[0]).Where(x => x is not null && x.Type is not LaneOptionType.Decoration).ToList();
			var bestScore = -1;
			NetSectionPrefab? bestSection = null;

			foreach (var item in group.LinkedSections)
			{
				if (!item.MatchCategories(config))
				{
					continue;
				}

				var score = 0;

				foreach (var option in options)
				{
					if (LaneOptionsUtil.MatchesOptionValue(item, option, LaneOptionsUtil.GetSelectedOptionValue(config, lane, option)))
					{
						score++;
					}
				}

				if (score == options.Count)
				{
					section = item;
					return true;
				}

				if (score > bestScore)
				{
					bestScore = score;
					bestSection = item;
				}
			}

			// No variant matches every stored value, which happens when a lane mod renames or removes a value.
			// The closest variant keeps the lane in the road instead of silently dropping it.
			if (bestSection is not null)
			{
				Mod.Log.Debug($"No exact variant of '{group.name}' for the lane's options, using '{bestSection.name}'");

				section = bestSection;
				return true;
			}

			section = default;
			return false;
		}

		private IEnumerable<ComponentBase> GenerateComponents()
		{
			Mod.Log.Debug($"GenerateComponents: id={NetworkPrefab.Config!.ID}");

			var netPollution = ScriptableObject.CreateInstance<NetPollution>();
			var undergroundNetSections = ScriptableObject.CreateInstance<UndergroundNetSections>();
			var netSubObjects = ScriptableObject.CreateInstance<NetSubObjects>();
			var placeableNet = ScriptableObject.CreateInstance<PlaceableNet>();
			var unlockable = ScriptableObject.CreateInstance<Unlockable>();
			var unlockOnBuild = ScriptableObject.CreateInstance<UnlockOnBuild>();

			netSubObjects.m_SubObjects = GenerateSubObjects().ToArray();
			yield return netSubObjects;

			placeableNet.m_AllowParallelMode = true;
			placeableNet.m_XPReward = 2;
			placeableNet.m_ElevationRange = NetworkPrefab.Config!.Category.HasFlag(RoadCategory.Pathway) ? new()
			{
				min = -20,
				max = 20
			}
			: new()
			{
				min = -100,
				max = 100
			};
			yield return placeableNet;

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.HasUndergroundElectricityCable))
			{
				var electricityConnection = ScriptableObject.CreateInstance<ElectricityConnection>();

				electricityConnection.m_Voltage = ElectricityConnection.Voltage.Low;
				electricityConnection.m_Direction = Game.Net.FlowDirection.Both;
				electricityConnection.m_Capacity = 400000;
				electricityConnection.m_RequireAll = NetworkPrefab.Config.Addons.HasFlag(RoadAddons.RequiresUpgradeForElectricity) ? new NetPieceRequirements[] { NetPieceRequirements.Lighting } : new NetPieceRequirements[0];
				electricityConnection.m_RequireAny = new NetPieceRequirements[0];
				electricityConnection.m_RequireNone = new NetPieceRequirements[0];

				yield return electricityConnection;
			}

			GetUIGroupAndRequirement(out var service, out var group, out var requirements, out var unlocks);

			var showInToolbar = NetworkPrefab.Config.ToolbarState is ShowInToolbarState.Show || (NetworkPrefab.Config.ToolbarState is ShowInToolbarState.Inherit && !Mod.Settings!.HideRoadsFromToolbarByDefault);

			if (!NetworkPrefab.Config.IsInPlayset())
			{
				showInToolbar = false;
			}

			if (service != null && showInToolbar)
			{
				var serviceObject = ScriptableObject.CreateInstance<ServiceObject>();
				serviceObject.m_Service = _roadGenerationData.ServicePrefabs[service];
				yield return serviceObject;
			}

			if (!NetworkPrefab.Config.Category.HasFlag(RoadCategory.Pathway))
			{
				yield return netPollution;
			}

			undergroundNetSections.m_Sections = Fix(GenerateUndergroundNetSections()).ToArray();

			if (undergroundNetSections.m_Sections.Length > 0)
			{
				yield return undergroundNetSections;
			}

			var uIObject = ScriptableObject.CreateInstance<UIObject>();
			uIObject.m_Group = showInToolbar && group != null ? _roadGenerationData.UIGroupPrefabs[group] : null;
			uIObject.m_Icon = group != null ? _roadGenerationData.UIGroupPrefabs[group].GetComponent<UIObject>().m_Icon : string.Empty;
			uIObject.m_Priority = 999999;
			yield return uIObject;

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.HasUndergroundWaterPipes))
			{
				yield return ScriptableObject.CreateInstance<WaterPipeConnection>();
			}

			if (!Mod.Settings!.RemoveLockRequirements)
			{
				unlockable.m_RequireAll = requirements.Select(x => _roadGenerationData.UnlocksPrefabs[x]).ToArray();
				unlockOnBuild.m_Unlocks = unlocks.Select(x => _roadGenerationData.UnlocksPrefabs[x] as ObjectBuiltRequirementPrefab).ToArray();
			}
			else
			{
				unlockable.m_RequireAll = new PrefabBase[0];
				unlockOnBuild.m_Unlocks = new ObjectBuiltRequirementPrefab[0];
			}

			if (unlockable.m_RequireAll.Length > 0)
			{
				unlockable.m_RequireAny = new PrefabBase[0];
				yield return unlockable;
			}

			if (unlockOnBuild.m_Unlocks.Length > 0)
			{
				yield return unlockOnBuild;
			}

			var assetPackItem = ScriptableObject.CreateInstance<AssetPackItem>();
			assetPackItem.m_Packs = new[] { _roadGenerationData.StreetStudioPack };
			yield return assetPackItem;
		}

		private IEnumerable<NetSectionInfo> GenerateUndergroundNetSections()
		{
			if (NetworkPrefab.Config!.Addons.HasFlag(RoadAddons.HasUndergroundWaterPipes))
			{
				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Sewage Pipe Section 1.5"],
					m_Offset = new float3(0, -1.25f, 0)
				};

				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Pipeline Spacing Section 1"],
					m_Offset = new float3(0, -1.25f, 0)
				};
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.HasUndergroundElectricityCable))
			{
				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Ground Cable Section 1"],
					m_RequireAll = NetworkPrefab.Config.Addons.HasFlag(RoadAddons.RequiresUpgradeForElectricity) ? new[] { NetPieceRequirements.Lighting } : null,
					m_Offset = new float3(0, -0.65f, 0)
				};
			}

			if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.HasUndergroundWaterPipes))
			{
				if (NetworkPrefab.Config.Addons.HasFlag(RoadAddons.HasUndergroundElectricityCable))
				{
					yield return new NetSectionInfo
					{
						m_Section = _roadGenerationData.NetSectionPrefabs["Pipeline Spacing Section 1"],
						m_Offset = new float3(0, -0.85f, 0)
					};
				}

				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Water Pipe Section 1"],
					m_Offset = new float3(0, -0.85f, 0)
				};

				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Pipeline Spacing Section 1"],
					m_Offset = new float3(0, -1.45f, 0),
					m_RequireNone = new[] { NetPieceRequirements.Node, NetPieceRequirements.Edge }
				};

				yield return new NetSectionInfo
				{
					m_Section = _roadGenerationData.NetSectionPrefabs["Stormwater Pipe Section 1.5"],
					m_Offset = new float3(0, -1.45f, 0),
					m_RequireNone = new[] { NetPieceRequirements.Node, NetPieceRequirements.Edge }
				};
			}
		}

		private IEnumerable<NetSectionInfo> Fix(IEnumerable<NetSectionInfo> sections)
		{
			foreach (var item in sections)
			{
				item.m_RequireAll ??= new NetPieceRequirements[0];
				item.m_RequireAny ??= new NetPieceRequirements[0];
				item.m_RequireNone ??= new NetPieceRequirements[0];

				yield return item;
			}
		}

		private IEnumerable<NetSubObjectInfo> GenerateSubObjects()
		{
			if (_roadGenerationData.PillarPrefabs.TryGetValue(NetworkPrefab.Config!.PillarPrefabName ?? string.Empty, out var pillar))
			{
				yield return new NetSubObjectInfo
				{
					m_Object = pillar,
					m_Position = new float3(0, -3, 0),
					m_Rotation = new quaternion(0, 0, 0, 1),
					m_Placement = NetObjectPlacement.Node,
					m_RequireElevated = true,
				};
			}

			if (!NetworkPrefab.Config.Category.HasFlag(RoadCategory.Pathway))
			{
				var carLanes = NetworkPrefab.Prefab.m_Sections.Where(x => x.m_Section.FindLanes<CarLane>().Count > 0).ToList();
				var trackLanes = NetworkPrefab.Prefab.m_Sections.Where(x => x.m_Section.FindLanes<TrackLane>().Any(x => x.m_TrackType is Game.Net.TrackTypes.Train)).ToList();

				if (carLanes.Count > 0)
				{
					var isOneWay = carLanes.All(x => x.m_Invert == carLanes[0].m_Invert);

					yield return new NetSubObjectInfo
					{
						m_Object = isOneWay ? _roadGenerationData.RoadOutsideConnectionOneWay : _roadGenerationData.RoadOutsideConnectionTwoWay,
						m_Position = new float3(0, 5, 0),
						m_Rotation = new quaternion(0, 0, 0, 1),
						m_Placement = NetObjectPlacement.Node,
						m_RequireOutsideConnection = true,
					};
				}

				if (trackLanes.Count > 0)
				{
					var isOneWay = trackLanes.All(x => x.m_Invert == trackLanes[0].m_Invert);

					yield return new NetSubObjectInfo
					{
						m_Object = isOneWay ? _roadGenerationData.TrainOutsideConnectionOneWay : _roadGenerationData.TrainOutsideConnectionTwoWay,
						m_Position = new float3(0, 5, 0),
						m_Rotation = new quaternion(0, 0, 0, 1),
						m_Placement = NetObjectPlacement.Node,
						m_RequireOutsideConnection = true,
					};
				}
			}
		}

		private void GetUIGroupAndRequirement(out string? service, out string? group, out string[] requirements, out string[] unlocks)
		{
			Mod.Log.Debug($"GetUIGroupAndRequirement: id={NetworkPrefab.Config!.ID} category={NetworkPrefab.Config.Category}");

			if (NetworkPrefab.Config!.Category.HasFlag(RoadCategory.Train))
			{
				service = "Transportation";
				group = "TransportationTrain";
				requirements = new[] { "TransportationTrain" };
				unlocks = new[] { "Train Track Built Req" };
			}
			else if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tram))
			{
				service = "Transportation";
				group = "TransportationTram";
				requirements = new[] { "TransportationTram" };
				unlocks = new[] { "Tram Track Built Req" };
			}
			else if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Subway))
			{
				service = "Transportation";
				group = "TransportationSubway";
				requirements = new[] { "TransportationSubway" };
				unlocks = new[] { "Subway Track Built Req" };
			}
			else if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.PublicTransport))
			{
				service = "Transportation";
				group = "TransportationRoad";
				requirements = new[] { "TransportationRoad" };
				unlocks = new string[0];
			}
			else if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Highway))
			{
				service = "Roads";
				group = "RoadsHighways";
				requirements = new[] { "RoadsHighways" };
				unlocks = new string[0];
			}
			else if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Pathway))
			{
				service = "Landscaping";
				group = "Pathways";
				requirements = new[] { "Pathways" };
				unlocks = new string[0];
			}
			else if (NetworkPrefab is RoadPrefab)
			{
				service = "Roads";
				var width = NetworkPrefab.Prefab.CalculateWidth();

				if (width >= 34)
				{
					group = "RoadsLargeRoads";
					requirements = new[] { "RoadsLargeRoads", "BasicRoadServiceNode" };
				}
				else if (width >= 22)
				{
					group = "RoadsMediumRoads";
					requirements = new[] { "RoadsMediumRoads", "BasicRoadServiceNode" };
				}
				else
				{
					group = "RoadsSmallRoads";
					requirements = new[] { "RoadsSmallRoads", "BasicRoadServiceNode" };
				}

				unlocks = new string[0];
			}
			else
			{
				service = null;
				group = null;
				requirements = new string[0];
				unlocks = new string[0];
			}
		}

		private string GetSideName()
		{
			if (NetworkPrefab.Config!.Category.HasFlag(RoadCategory.Train))
			{
				return "Train Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tram))
			{
				return "Alley Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Subway))
			{
				return "Subway Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Highway))
			{
				return "Highway Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Gravel))
			{
				return "Gravel Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tiled))
			{
				return "Tiled Side 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Pathway))
			{
				return "Pavement Path Side Section 0";
			}

			return "Alley Side 0";
		}

		private string GetEmptyMedianName()
		{
			if (NetworkPrefab.Config!.Category.HasFlag(RoadCategory.Train))
			{
				return "Train Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tram))
			{
				return "Tram Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Subway))
			{
				return "Subway Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Highway))
			{
				return "Highway Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Gravel))
			{
				return "Gravel Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.Tiled))
			{
				return "SS Tiled Median 0";
			}

			if (NetworkPrefab.Config.Category.HasFlag(RoadCategory.PublicTransport))
			{
				return "Public Transport Median 0";
			}

			return "Road Median 0";
		}
	}
}
