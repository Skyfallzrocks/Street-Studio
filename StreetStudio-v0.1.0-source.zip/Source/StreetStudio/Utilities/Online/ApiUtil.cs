using StreetStudio.Domain.API;
using StreetStudio.Domain.Configurations;
using System.Threading;
using System.Threading.Tasks;
namespace StreetStudio.Utilities.Online {
 // Street Studio is local-only. The upstream Road Builder service is not used.
 public class ApiUtil {
 public static ApiUtil Instance { get; } = new();
 public Task<PagedContent<StreetStudioEntry>?> GetEntries(string? query=null,int? category=null,int order=0,int page=1,CancellationToken cancellationToken=default) => Task.FromResult<PagedContent<StreetStudioEntry>?>(null);
 public Task<ApiResponse?> UploadRoad(StreetStudioEntryPost road,CancellationToken cancellationToken=default) => Task.FromResult<ApiResponse?>(new ApiResponse { success=false,message="Street Studio stores templates locally. Online sharing is unavailable." });
 public Task<INetworkConfig?> GetConfig(string id,CancellationToken cancellationToken=default) => Task.FromResult<INetworkConfig?>(null);
 }}
