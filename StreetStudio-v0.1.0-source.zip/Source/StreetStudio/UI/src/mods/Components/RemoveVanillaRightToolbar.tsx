import { bindValue, useValue } from "cs2/api";
import { ModuleRegistryExtend } from "cs2/modding";
import { roadBuilderToolMode$ } from "mods/bindings";
import { StreetStudioToolModeEnum } from "domain/StreetStudioToolMode";

export const RemoveVanillaRightToolbar: ModuleRegistryExtend = (Component) => {
  return (props) => {
    const { children, ...otherProps } = props || {};

    const roadBuilderToolMode = useValue(roadBuilderToolMode$);

      if (roadBuilderToolMode != StreetStudioToolModeEnum.None) {
      return <></>;
    }

    return <Component {...otherProps}>{children}</Component>;
  };
};
