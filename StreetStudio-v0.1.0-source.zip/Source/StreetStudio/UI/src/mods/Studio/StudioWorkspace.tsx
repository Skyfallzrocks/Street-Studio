import { bindValue, trigger, useValue } from "cs2/api";
import { Button, Scrollable } from "cs2/ui";
import { useEffect, useState } from "react";
import mod from "mod.json";
import { NetSectionItem } from "domain/NetSectionItem";
import { RoadLane } from "domain/RoadLane";
import { OptionsPanelComponent } from "mods/Components/OptionsPanel/OptionsPanel";
import { allNetSections$, roadLanes$, roadOptions$, getRoadName$, getRoadSize$, getRoadId$, roadBuilderToolMode$, clearTool, manageRoads, pickPrefab, createNewPrefab, duplicateLane, setRoadName, setRoadLanes, laneOptionClicked, roadOptionClicked, toggleTool } from "mods/bindings";
import { StreetStudioToolModeEnum } from "domain/StreetStudioToolMode";
import studioIcon from "images/StreetStudio.svg";
import styles from "./StudioWorkspace.module.scss";

const canUndo$ = bindValue(mod.id, "Studio.CanUndo", false);
const canRedo$ = bindValue(mod.id, "Studio.CanRedo", false);
const status$ = bindValue(mod.id, "Studio.Status", "Ready.");
const applyRevision$ = bindValue(mod.id, "Studio.ApplyRevision", 0);
const command = (action: string) => trigger(mod.id, "Studio." + action);

export interface Recipe {
  Lanes: number; Sidewalk: number; Median: number; Speed: number;
  Bikes: boolean; Buses: boolean; Parking: boolean; Trees: boolean; Grass: boolean; Markings: boolean;
}
export const starter: Recipe = { Lanes: 2, Sidewalk: 4, Median: 2, Speed: 40, Bikes: false, Buses: false, Parking: false, Trees: false, Grass: false, Markings: true };
export const presets: {name: string; detail: string; group: string; recipe: Recipe}[] = [
  {name: "City Standard", detail: "4 traffic lanes · everyday streets", group: "Urban", recipe: {...starter}},
  {name: "Bus Corridor", detail: "Dedicated bus lanes · 40 km/h", group: "Transit", recipe: {...starter, Buses: true}},
  {name: "Bike Friendly", detail: "Bike lanes · 30 km/h", group: "Active", recipe: {...starter, Lanes: 1, Bikes: true, Speed: 30}},
  {name: "Boulevard", detail: "5 m planted median · 6 traffic lanes", group: "Urban", recipe: {...starter, Lanes: 3, Median: 5, Trees: true, Grass: true, Speed: 50}},
  {name: "Main Street", detail: "Parking · wide sidewalks", group: "Local", recipe: {...starter, Lanes: 1, Median: 0, Sidewalk: 5, Parking: true, Speed: 30}},
  {name: "Transit Avenue", detail: "Bus + bike lanes · 40 km/h", group: "Transit", recipe: {...starter, Buses: true, Bikes: true}},
  {name: "Green Corridor", detail: "Trees + grass · 30 km/h", group: "Active", recipe: {...starter, Lanes: 1, Median: 5, Trees: true, Grass: true, Speed: 30}},
];

const categories = [
  {name: "Travel Lanes", icon: "RB_CarWhite.svg", query: "car", hint: "Add driving, bus or tram lanes."},
  {name: "Medians & Islands", icon: "RB_Median.svg", query: "median", hint: "Build continuous medians. Custom islands and refuge shapes need a separate geometry tool."},
  {name: "Sidewalks", icon: "RB_WideSidewalkRight.svg", query: "sidewalk", hint: "Choose a sidewalk, then select it below to adjust width, trees and grass."},
  {name: "Bike Lanes", icon: "RB_YesBikes.svg", query: "bike|sidewalk", hint: "For roads, add a sidewalk and select its bike option. Quick Design adds integrated bike sidewalks on both sides."},
  {name: "Crosswalks", icon: "RB_MarkingsWhite.svg", query: "@crosswalk", hint: "Sidewalks generate intersection crossing geometry. Place or remove crossings with the game's road services tools. Custom crossing patterns are not included."},
  {name: "Curb Extensions", icon: "RB_Median.svg", query: "@curb", hint: "Road edge sections provide curbs. Bulb-outs, corner radius editing, drainage and custom curb islands require new geometry tools and are not included."},
  {name: "Bus & Transit", icon: "RB_BusWhite.svg", query: "bus|tram", hint: "Add transit lanes here. Place stops, shelters and routes with the game's transport tools."},
  {name: "Parking", icon: "RB_WhiteParkingAngle0.svg", query: "parking", hint: "Add parallel, angled or perpendicular parking, depending on the selected lane."},
  {name: "Trees & Greenery", icon: "RB_TreeMedian.svg", query: "median|sidewalk", hint: "Select a sidewalk or a wide median below to change grass and trees. Quick Design can add both."},
  {name: "Street Furniture", icon: "RB_WhiteWrench.svg", query: "@furniture", hint: "Individual benches, lights, bins, signs, fences, walls and banners are placed with the game's asset tools. Street Studio does not include an individual prop placement tool."},
  {name: "Road Markings", icon: "RB_MarkingsWhite.svg", query: "car|parking", hint: "Select a traffic or parking lane below to change its available markings. Custom paint, arrows and tactile warning pads are not included."},
  {name: "Tunnels & Bridges", icon: "RB_WhiteWrench.svg", query: "@elevation", hint: "Build this road with the game's road tool and adjust elevation for standard bridges and tunnels. Unique bridge styles and a dedicated elevation editor are not included."},
  {name: "All Elements", icon: "RB_WhiteWrench.svg", query: "", hint: "Every compatible lane loaded by Street Studio. Custom lanes appear here when they support this fork's components."},
];

function RoadMini({recipe}: {recipe: Recipe}) {
  return <div className={styles.roadMini}>
    <i className={recipe.Trees ? styles.green : styles.walk}/>
    {recipe.Bikes && <i className={styles.bike}/>}{recipe.Parking && <i className={styles.parking}/>}{recipe.Buses && <i className={styles.bus}/>}
    {Array.from({length: recipe.Lanes}, (_, i) => <i key={"l"+i} className={styles.drive}/>)}
    {recipe.Median > 0 && <i className={recipe.Grass ? styles.green : styles.median}/>}
    {Array.from({length: recipe.Lanes}, (_, i) => <i key={"r"+i} className={styles.drive}/>)}
    {recipe.Buses && <i className={styles.bus}/>}{recipe.Parking && <i className={styles.parking}/>}{recipe.Bikes && <i className={styles.bike}/>}
    <i className={recipe.Trees ? styles.green : styles.walk}/>
  </div>;
}

export const StudioWorkspace = ({editor}: {editor: boolean}) => {
  const lanes = useValue(roadLanes$), groups = useValue(allNetSections$) || [];
  const options = useValue(roadOptions$), roadName = useValue(getRoadName$), roadSize = useValue(getRoadSize$), roadId = useValue(getRoadId$);
  const mode = useValue(roadBuilderToolMode$);
  const canUndo = useValue(canUndo$), canRedo = useValue(canRedo$), status = useValue(status$);
  const applyRevision = useValue(applyRevision$);
  const [category, setCategory] = useState(0), [search, setSearch] = useState("");
  const [tab, setTab] = useState("design"), [selected, select] = useState(-1), [help, showHelp] = useState(false);
  const [recipe, setRecipe] = useState<Recipe>({...starter}), [preset, setPreset] = useState("City Standard"), [filter, setFilter] = useState("All");
  const [name, setName] = useState(roadName || ""), [dirty, setDirty] = useState(false);
  useEffect(() => {setName(roadName || "");}, [roadName]);
  useEffect(() => {select(-1); setDirty(false);}, [roadId]);
  useEffect(() => {setDirty(false);}, [applyRevision]);
  useEffect(() => {if (selected >= lanes.length) select(-1);}, [lanes.length]);
  useEffect(() => {
    const keyboard = (e: KeyboardEvent) => {
      const element = e.target as HTMLElement;
      if (element?.tagName === "INPUT" || element?.tagName === "TEXTAREA" || element?.isContentEditable || !(e.ctrlKey || e.metaKey)) return;
      if (e.key.toLowerCase() === "z" && !e.shiftKey && canUndo) {e.preventDefault(); command("Undo");}
      else if ((e.key.toLowerCase() === "y" || (e.key.toLowerCase() === "z" && e.shiftKey)) && canRedo) {e.preventDefault(); command("Redo");}
    };
    window.addEventListener("keydown", keyboard);
    return () => window.removeEventListener("keydown", keyboard);
  }, [canUndo, canRedo]);
  const cat = categories[category];
  const elements = groups.flatMap(g => g.Sections).filter(item => {
    const text = (item.DisplayName + " " + item.PrefabName).toLowerCase();
    return !cat.query.startsWith("@") && (!cat.query || cat.query.split("|").some(q => text.indexOf(q) >= 0)) && text.indexOf(search.toLowerCase()) >= 0;
  });
  const current = lanes[selected];
  function change<K extends keyof Recipe>(key: K, value: Recipe[K]) {setRecipe({...recipe, [key]: value}); setPreset("Custom"); setDirty(true);}
  function add(item: NetSectionItem) {
    const list = lanes.filter(l => !l.IsEdgePlaceholder);
    const lane: RoadLane = {SectionPrefabName: item.PrefabName, IsGroup: item.IsGroup, Index: -1};
    const pos = current && !current.IsEdgePlaceholder ? list.findIndex(l => l.Index === current.Index) + 1 : Math.max(0, list.length - 1);
    list.splice(pos, 0, lane); setRoadLanes(list); select(pos); setTab("lane");
  }
  function move(direction: number) {
    if (!current || current.IsEdgePlaceholder) return;
    const list = lanes.filter(l => !l.IsEdgePlaceholder), index = list.findIndex(l => l.Index === current.Index), next = index + direction;
    if (next < 0 || next >= list.length) return;
    [list[index], list[next]] = [list[next], list[index]]; setRoadLanes(list); select(-1);
  }
  const stepper = (label: string, key: "Lanes"|"Sidewalk"|"Median"|"Speed", values: number[], unit: string) => <div className={styles.field}>
    <span>{label}</span><div className={styles.stepper}>
      <Button disabled={values.indexOf(recipe[key]) <= 0} onSelect={() => change(key, values[values.indexOf(recipe[key])-1])}>−</Button>
      <b>{recipe[key]}{unit}</b>
      <Button disabled={values.indexOf(recipe[key]) >= values.length-1} onSelect={() => change(key, values[values.indexOf(recipe[key])+1])}>+</Button>
    </div>
  </div>;
  const toggle = (label: string, key: "Bikes"|"Buses"|"Parking"|"Trees"|"Grass"|"Markings", detail: string) => <Button className={styles.toggleRow} onSelect={() => change(key, !recipe[key])}>
    <span><b>{label}</b><small>{detail}</small></span><i className={recipe[key] ? styles.toggleOn : styles.toggleOff}><i/></i>
  </Button>;
  return <div className={`${styles.workspace} ${editor ? styles.editor : ""}`}>
    <div className={styles.header}>
      <div className={styles.logo}><img src={studioIcon}/></div><div className={styles.brand}>Street <strong>Studio</strong><small>by LivelySkylines</small></div>
      <span className={styles.tagline}>DESIGN · BUILD · UPGRADE · EXPAND</span>
      <div className={styles.headerActions}>
        <Button disabled={!canUndo} onSelect={() => command("Undo")}>↶ Undo</Button><Button disabled={!canRedo} onSelect={() => command("Redo")}>↷ Redo</Button>
        <Button onSelect={createNewPrefab}>Copy design</Button><Button onSelect={manageRoads}>Templates</Button><Button onSelect={() => showHelp(!help)}>Help</Button><Button onSelect={clearTool}>×</Button>
      </div>
    </div>
    <div className={styles.left}>
      <div className={styles.eyebrow}>STREET ELEMENTS</div>
      <Scrollable className={styles.categories} vertical smooth>
        {categories.map((c, i) => <Button key={c.name} className={`${styles.category} ${category === i ? styles.active : ""}`} onSelect={() => {setCategory(i); setSearch("");}}>
          <img src={`coui://streetstudioicons/${c.icon}`}/><span>{c.name}</span>
        </Button>)}
      </Scrollable>
      <div className={styles.leftFooter}><Button onSelect={() => {toggleTool(); toggleTool();}}>Pick another street</Button><Button onSelect={pickPrefab}>Build this road →</Button></div>
    </div>
    <div className={styles.hud}><span>EDITING STREET</span><b>{roadName || "Custom street"}</b><small>{roadSize} · {lanes.filter(l => !l.IsEdgePlaceholder).length} sections</small>
      <small>{mode === StreetStudioToolModeEnum.EditingSingle ? "Creates a separate design for this segment" : mode === StreetStudioToolModeEnum.EditingNonExistent ? "Editing a saved design" : "Changes every segment using this design"}</small>
    </div>
    {help && <div className={styles.help}>
      <div className={styles.eyebrow}>WELCOME TO STREET STUDIO</div><h2>Your street, your way.</h2>
      <p>1. Choose a quick preset below, adjust its dimensions and press Apply Design. Quick designs replace the entire cross-section with an asphalt road.</p>
      <p>2. For detailed editing, add elements from the library. Select a section in the layout to change its width, direction or decoration.</p>
      <p>3. Lane edits update live. Undo restores the previous design. Save Template keeps the current applied street in your local library.</p>
      <p>Use the game's road tool for elevation, tunnels, bridges, intersections and camera movement. Custom bridge styles, corner geometry and individual prop placement are not included.</p>
      <Button onSelect={() => showHelp(false)}>Got it — let's build</Button>
    </div>}
    <div className={styles.right}>
      <div className={styles.eyebrow}>ROAD PROPERTIES</div>
      <div className={styles.nameField}><input aria-label="Road design name" value={name} maxLength={250} onChange={e => setName(e.target.value)} onBlur={() => {if(name !== roadName) setRoadName(name);}} onKeyDown={e => {if(e.key === "Enter") e.currentTarget.blur();}}/></div>
      <div className={styles.tabs}>{[["design","Quick Design"],["lane","Selected Lane"],["road","Road Options"]].map(([id,label]) => <Button key={id} className={tab === id ? styles.active : ""} onSelect={() => setTab(id)}>{label}</Button>)}</div>
      <Scrollable className={styles.properties} vertical smooth>
        {tab === "design" && <>
          <div className={styles.sectionTitle}>DIMENSIONS <span>{preset}</span></div>
          {stepper("Traffic lanes / direction", "Lanes", [1,2,3,4,5,6], "")}
          {stepper("Sidewalks / side", "Sidewalk", [1,2,3,4,5,6,7,9], " m")}
          {stepper("Center median", "Median", [0,1,2,5], " m")}
          {stepper("Design speed", "Speed", [10,20,30,40,50,60,70,80,90,100,110,120,130], " km/h")}
          <div className={styles.sectionTitle}>LANES & STREETSCAPE</div>
          {toggle("Bike lanes", "Bikes", "Both sides · integrated bike sidewalks")}
          {toggle("Dedicated bus lanes", "Buses", "Both sides · 3 m lanes")}
          {toggle("On-street parking", "Parking", "Both sides · parallel bays")}
          {toggle("Trees", "Trees", "Where supported by sidewalks and 5 m medians")}
          {toggle("Grass", "Grass", "Where supported by sidewalks and 5 m medians")}
          {toggle("Lane markings", "Markings", "Traffic lanes and parking bays")}
          <p className={styles.note}>Widths follow available game sections. The applied street's measured width appears above. Quick Design settings are a replacement recipe, not a reading of the current street.</p>
        </>}
        {tab === "lane" && (current && !current.IsEdgePlaceholder ? <>
          <h3>{current.NetSection?.DisplayName || current.SectionPrefabName}</h3><p className={styles.note}>Changes to these controls update the street immediately.</p>
          <OptionsPanelComponent options={current.Options || []} OnChange={(x,y,z) => laneOptionClicked(current.Index,x,y,z)}/>
          <div className={styles.laneActions}><Button onSelect={() => move(-1)}>← Move</Button><Button onSelect={() => move(1)}>Move →</Button><Button onSelect={() => duplicateLane(current.Index)}>Duplicate</Button><Button onSelect={() => {setRoadLanes(lanes.filter((l,i) => i !== selected)); select(-1);}}>Remove</Button></div>
        </> : <p className={styles.note}>Select a section in the street layout below to adjust it.</p>)}
        {tab === "road" && <><p className={styles.note}>These advanced settings update the current street immediately.</p><OptionsPanelComponent options={options || []} OnChange={roadOptionClicked}/></>}
      </Scrollable>
      <div className={styles.applyBar}><Button onSelect={() => {setRecipe({...starter}); setPreset("City Standard"); setDirty(true);}}>Reset recipe</Button>
        <Button className={styles.apply} onSelect={() => trigger(mod.id,"Studio.Apply",JSON.stringify(recipe))}>✓ Apply Design</Button></div>
    </div>
    <div className={styles.library}>
      <div className={styles.libraryTitle}><b>{cat.name}</b><input aria-label="Search street elements" placeholder="Search elements…" value={search} onChange={e => setSearch(e.target.value)}/></div>
      <p>{cat.hint}</p>
      <Scrollable className={styles.elementList} horizontal smooth>
        {elements.map(item => <Button key={item.PrefabName} disabled={item.IsRestricted} className={styles.element} onSelect={() => add(item)}>
          <img src={item.Thumbnail}/><span>{item.DisplayName}</span><small>{item.IsRestricted ? "Unavailable for this road" : "+ Add · " + (item.WidthText || "options")}</small>
        </Button>)}
        {!elements.length && <div className={styles.empty}>{cat.query.startsWith("@") ? "Use the game tools described above." : "No compatible elements found. Try All Elements or clear the search."}</div>}
      </Scrollable>
    </div>
    <div className={styles.bottom}>
      <div className={styles.presetHeading}><b>QUICK PRESETS</b>{["All","Urban","Transit","Active","Local"].map(f => <Button key={f} className={filter === f ? styles.active : ""} onSelect={() => setFilter(f)}>{f}</Button>)}<small>{dirty ? "Recipe has unapplied changes" : "Choose a preset, then Apply Design"}</small></div>
      <Scrollable className={styles.presetList} horizontal smooth>{presets.filter(p => filter === "All" || p.group === filter).map(p => <Button key={p.name} className={`${styles.preset} ${preset === p.name ? styles.chosen : ""}`} onSelect={() => {setRecipe({...p.recipe}); setPreset(p.name); setDirty(true); setTab("design");}}>
        <RoadMini recipe={p.recipe}/><b>{p.name}</b><small>{p.detail}</small>
      </Button>)}</Scrollable>
      <div className={styles.layoutHeading}><b>STREET LAYOUT</b><span>Left edge → Right edge · select a section to edit</span><Button onSelect={() => command("Save")}>Save Template</Button></div>
      <Scrollable className={styles.layout} horizontal smooth>
        {lanes.map((lane,i) => <Button key={i} className={`${styles.lane} ${selected === i ? styles.chosen : ""}`} style={{backgroundColor: lane.Color || "#293843", minWidth: `${Math.max(48, (lane.NetSection?.Width || 3)*16)}rem`}} onSelect={() => {select(i); setTab("lane");}}>
          <span>{lane.IsEdgePlaceholder ? "+ Edge" : lane.NoDirection ? "─" : lane.TwoWay ? "↕" : lane.Invert ? "↓" : "↑"}</span><b>{lane.NetSection?.DisplayName || lane.SectionPrefabName || "Edge"}</b><small>{lane.NetSection?.WidthText}</small>
        </Button>)}
      </Scrollable>
      <div className={styles.status}>{status}</div>
    </div>
  </div>;
};
