import { Button, FOCUS_DISABLED, Scrollable, Tooltip } from "cs2/ui";
import { LaneListItem } from "../Components/LaneListItem/LaneListItem";
import styles from "./SidePanel.module.scss";
import { useValue } from "cs2/api";
import {
  allNetSections$,
  allRoadConfigurations$,
  fpsMeterLevel$,
  manageRoads,
  roadBuilderToolMode$,
  roadListView$,
  setRoadListView,
  setRoadsSearchBinder,
  setSearchBinder,
} from "mods/bindings";
import { useEffect, useState } from "react";
import { useLocalization } from "cs2/l10n";
import { SearchTextBox } from "mods/Components/SearchTextBox/SearchTextBox";
import { RoadConfigListItem } from "mods/Components/RoadConfigListItem/RoadConfigListItem";
import { StreetStudioToolModeEnum } from "domain/StreetStudioToolMode";
import classNames from "classnames";
import { LaneListGroup } from "mods/Components/LaneListItem/LaneListGroup";
import { GetCategoryIcon, GetCategoryName, RoadCategory } from "domain/RoadCategory";

export const SidePanel = (props: { editor: boolean }) => {
  const { translate } = useLocalization();
  const toolMode = useValue(roadBuilderToolMode$);
  const roadListView = useValue(roadListView$);
  const roadConfigurations = useValue(allRoadConfigurations$);
  const netSections = useValue(allNetSections$);
  const fpsMeterLevel = useValue(fpsMeterLevel$);
  const [selectedCategory, setSelectedCategory] = useState<string | RoadCategory | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedItemId, setSelectedItemId] = useState<number | undefined>(); // state to track selected child

  let items: JSX.Element[];

  function setAndBindSearch(query: string) {
    setSearchQuery(query);

    if (roadListView || toolMode == StreetStudioToolModeEnum.Picker) setRoadsSearchBinder(query);
    else setSearchBinder(query);
  }

  useEffect(() => {
    // when the road list view changes value
    setAndBindSearch("");
  }, [roadListView]);

  // The selected category's button disappears once no road matches it, so fall back to all roads
  useEffect(() => {
    if (selectedCategory !== undefined && !roadConfigurations.some((r) => r.Category === selectedCategory && !r.IsNotInPlayset))
      setSelectedCategory(undefined);
  }, [selectedCategory, roadConfigurations]);

  //if (toolMode == StreetStudioToolModeEnum.Picker && searchQuery === "" && roadConfigurations.length === 0) return <></>;

  if (roadListView || toolMode == StreetStudioToolModeEnum.Picker) {
    items = roadConfigurations
      .filter((val, idx) => (selectedCategory == undefined || selectedCategory == val.Category) && !val.IsNotInPlayset)
      .map((val, idx) => <RoadConfigListItem key={val.ID ?? idx} road={val} index={idx} selected={selectedItemId == idx} onSelect={setSelectedItemId} />);
  } else {
    const small = netSections.map((x) => x.Sections.length).reduce((x, s) => x + s, 0) >= 15;
    // Sorted on a copy, the array belongs to the binding
    items = [...netSections]
      .sort((a, b) => (a.Type > b.Type ? 1 : -1))
      .map((grp) => (
        <LaneListGroup key={grp.Type} type={grp.Type} small={small}>
          {grp.Sections.map((val, idx) => (
            <LaneListItem key={idx} netSection={val} small={small} />
          ))}
        </LaneListGroup>
      ));
  }

  return (
    <div
      className={classNames(
        styles.panel,
        props.editor ? styles.editor : styles.game,
        styles["fpsLevel" + fpsMeterLevel],
        toolMode == StreetStudioToolModeEnum.Picker && styles.expanded
      )}
    >
      <div className={styles.header}>
        {toolMode == StreetStudioToolModeEnum.Picker && (
          <div className={styles.subHeader}>
            <div className={styles.title}>{translate("StreetStudio.CreatedRoads")}</div>
            <div className={styles.roadCount}>{translate("StreetStudio.RoadCount")?.replace("{0}", items.length.toString())}</div>
          </div>
        )}
        {toolMode != StreetStudioToolModeEnum.Picker && (
          <div className={styles.mode}>
            <div className={classNames(!roadListView && styles.selected)} onClick={() => setRoadListView(false)}>
              {translate("StreetStudio.AvailableLanes")}
            </div>
            <div className={classNames(roadListView && styles.selected)} onClick={() => setRoadListView(true)}>
              {translate("StreetStudio.CreatedRoads")}
            </div>
          </div>
        )}
        <div style={{ marginTop: "6rem" }}>
          <SearchTextBox value={searchQuery} onChange={setAndBindSearch} />
        </div>
        {(roadListView || toolMode == StreetStudioToolModeEnum.Picker) && (
          <div className={styles.categories}>
            <Tooltip tooltip={translate("StreetStudio.AllRoads")}>
              <Button className={classNames(selectedCategory == undefined && styles.selected)} variant="flat" onSelect={() => setSelectedCategory(undefined)}>
                <img src="Media/Tools/Snap Options/All.svg" />
              </Button>
            </Tooltip>
            {Object.values(RoadCategory)
              .filter((x) => GetCategoryIcon(x as RoadCategory) != undefined && roadConfigurations.some((r) => r.Category === x && !r.IsNotInPlayset))
              .map((x) => (
                <Tooltip key={x} tooltip={translate(GetCategoryName(x as RoadCategory))}>
                  <Button className={classNames(selectedCategory == x && styles.selected)} variant="flat" onSelect={() => setSelectedCategory(x)}>
                    <img src={GetCategoryIcon(x as RoadCategory)} />
                  </Button>
                </Tooltip>
              ))}
          </div>
        )}
      </div>
      <Scrollable
        className={classNames(styles.list, roadListView || toolMode == StreetStudioToolModeEnum.Picker ? styles.roads : styles.lanes)}
        vertical
        smooth
        trackVisibility="scrollable"
      >
        {items}
      </Scrollable>
      {toolMode == StreetStudioToolModeEnum.Picker && (
        <div className={styles.manageRoadsButton}>
          <Button onSelect={manageRoads} variant="flat" focusKey={FOCUS_DISABLED}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_WhiteWrench.svg)" }} />
            {translate("StreetStudio.ManageRoads", "Manage Your Roads")}
          </Button>
        </div>
      )}
    </div>
  );
};
