import { Button, Tooltip } from "cs2/ui";
import styles from "./ManageRoadPanel.module.scss";
import { NetSectionItem } from "domain/NetSectionItem";
import { CSSProperties, MouseEventHandler, forwardRef, useContext, useEffect, useRef, useState } from "react";
import classNames from "classnames";
import { DragContext } from "mods/Contexts/DragContext";
import { MouseButtons } from "mods/util";
import { VanillaComponentResolver } from "vanillacomponentresolver";
import { RoadConfiguration } from "domain/RoadConfiguration";
import {
  deleteRoad,
  editRoad,
  findRoad,
  activateRoad,
  getRoadId$,
  setRoadName,
  getRoadName$,
  RestrictPlayset$,
  managedRoadOptionClicked,
  managedRoadOptions$,
  setManagedRoadName,
} from "mods/bindings";
import { useValue } from "cs2/api";
import { useLocalization } from "cs2/l10n";
import { GetCategoryIcon, GetCategoryName, RoadCategory } from "domain/RoadCategory";
import { OptionsPanelComponent } from "mods/Components/OptionsPanel/OptionsPanel";

export const ManageRoadPanel = ({ road }: { road: RoadConfiguration }) => {
  const { translate } = useLocalization();
  const managedRoadOptions = useValue(managedRoadOptions$);
  const nameRef = useRef(null);
  const [showNameTextbox, setTextboxVisibility] = useState<boolean>(false);

  let [newRoadName, setNewRoadName] = useState(road.Name);

  let onFinishEditRoadName = () => {
    setManagedRoadName(newRoadName);
    setTextboxVisibility(false);
  };

  let onStartEditRoadName = () => {
    setNewRoadName(road.Name);
  };

  useEffect(() => {
    const el = (nameRef.current as any)?.firstChild?.firstChild;

    if (el && typeof el.select === "function") {
        el.focus();
        el.select();
    }
  }, [showNameTextbox]);

  return (
    <>
      <img className={styles.thumbnail} src={road.Thumbnail ?? "coui://streetstudioicons/RB_Unknown.svg"} />
      {showNameTextbox ? (
        <div className={styles.nameBox} ref={nameRef}>
          <VanillaComponentResolver.instance.EllipsisTextInput
            onChange={({ target }) => setNewRoadName(target.value)}
            placeholder={translate("StreetStudio.RoadName", "Road Name")!}
            value={newRoadName}
            className={styles.textInput}
            onBlur={onFinishEditRoadName}
            onFocus={onStartEditRoadName}
            maxLength={250}
          />
        </div>
      ) : (
        <div className={styles.name} onClick={() => setTextboxVisibility(true)}>
          <p>{road.Name}</p>
        </div>
      )}
      <div className={styles.roadType}>
        <img src={GetCategoryIcon(road.Category)} />
        <span>{translate(GetCategoryName(road.Category))}</span>
      </div>

      <div className={styles.divider} />

      <div className={styles.options}>
        <OptionsPanelComponent OnChange={managedRoadOptionClicked} options={managedRoadOptions} />
      </div>

      <div className={styles.divider} />

      <div className={styles.buttons}>
        <Tooltip tooltip={translate("StreetStudio.PlaceTooltip")}>
          <Button variant="flat" onSelect={() => activateRoad(road.ID)}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_PlaceMore.svg)", width: "24rem", height: "24rem", marginRight: "6rem" }} />
            {translate("StreetStudio.Place")}
          </Button>
        </Tooltip>
        <Tooltip tooltip={translate("StreetStudio.EditTooltip")}>
          <Button variant="flat" onSelect={() => editRoad(road.ID)}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_Edit.svg)" }} /> {translate("StreetStudio.Edit")}
          </Button>
        </Tooltip>
        <Tooltip tooltip={translate("StreetStudio.FindTooltip")}>
          <Button disabled={!road.Used} variant="flat" onSelect={() => findRoad(road.ID)} className={classNames(!road.Used && styles.disabled)}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_Location.svg)" }} /> {translate("StreetStudio.Find")}
          </Button>
        </Tooltip>
        <Tooltip tooltip={translate("StreetStudio.DeleteTooltip")}>
          <Button variant="flat" onSelect={() => deleteRoad([road.ID])} className={styles.danger}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_Trash.svg)" }} /> {translate("StreetStudio.Delete")}
          </Button>
        </Tooltip>
      </div>
    </>
  );
};
