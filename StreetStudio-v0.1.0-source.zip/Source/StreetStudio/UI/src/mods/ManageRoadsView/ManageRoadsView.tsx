import { Button, Scrollable, Tooltip } from "cs2/ui";
import { LaneListItem } from "../Components/LaneListItem/LaneListItem";
import styles from "./ManageRoadsView.module.scss";
import { useValue } from "cs2/api";
import {
  managementRoadConfigurations$,
  deleteRoad,
  DiscoverErrorLoading$,
  DiscoverItems$,
  DiscoverLoading$,
  managedRoad$,
  RestrictPlayset$,
  setDiscoverPage,
  setDiscoverSearchBinder,
  setDiscoverSorting,
  setManagementRoad,
  setManagementSearchBinder,
  setManagementSetCategory,
  toggleTool,
} from "mods/bindings";
import { useEffect, useState } from "react";
import { useLocalization } from "cs2/l10n";
import { SearchTextBox } from "mods/Components/SearchTextBox/SearchTextBox";
import classNames from "classnames";
import { DiscoverRoadConfigListItem } from "mods/Components/RoadConfigListItem/DiscoverRoadConfigListItem";
import { GetCategoryIcon, GetCategoryName, RoadCategory } from "domain/RoadCategory";
import { ManageRoadConfigListItem } from "mods/Components/RoadConfigListItem/ManageRoadConfigListItem";
import { ManageRoadPanel } from "./ManageRoadPanel";
import { Pagination } from "./Pagination";
import { CustomDropdown } from "mods/Components/DropDown/DropDown";

export const ManageRoadsView = (props: { editor: boolean }) => {
  const { translate } = useLocalization();
  const DiscoverLoading = useValue(DiscoverLoading$);
  const DiscoverErrorLoading = useValue(DiscoverErrorLoading$);
  const DiscoverItems = useValue(DiscoverItems$);
  const RestrictPlayset = useValue(RestrictPlayset$);
  // The management list is filtered by the "My Roads" search, separately from the side panel's list
  const roadConfigurations = useValue(managementRoadConfigurations$);
  const managedRoad = useValue(managedRoad$);
  let [searchQuery, setSearchQuery] = useState<string>("");
  let [pageChanging, setPageChanging] = useState<boolean>(false);
  let [discoverView, setDiscoverView] = useState<boolean>(false);
  let [showAllPlaysets, setShowAllPlaysets] = useState<boolean>(false);
  let [hideLocked, setHideLocked] = useState<boolean>(false);
  let [usedFilter, setUsedFilter] = useState<boolean | undefined>(undefined);
  let [sorting, setSorting] = useState<number>(0);
  let [selectedCategory, setSelectedCategory] = useState<string | RoadCategory | undefined>(undefined);
  let items: JSX.Element;

  function GetRoadConfigurations() {
    return roadConfigurations.filter(
      (val, idx) =>
        (selectedCategory == undefined || selectedCategory == val.Category) &&
        (usedFilter === undefined || usedFilter == val.Used) &&
        (!val.IsNotInPlayset || showAllPlaysets) &&
        (!val.Locked || !hideLocked)
    );
  }

  function deleteAllRoads() {
    deleteRoad(GetRoadConfigurations().map((x) => x.ID));
  }

  function setAndBindSearch(query: string) {
    setSearchQuery(query);

    if (discoverView) {
      setDiscoverSearchBinder(query);
      setDiscoverPage(1);
    } else {
      setManagementSearchBinder(query);
    }
  }

  function setAndBindCategory(cat: RoadCategory | undefined) {
    setSelectedCategory(cat);

    if (discoverView) {
      setManagementSetCategory(cat ?? -1);
      setDiscoverPage(1);
    }
  }

  function setAndBindSorting(value: number) {
    setSorting(value);
    if (discoverView) {
      setDiscoverSorting(value);
      setDiscoverPage(1);
    }
  }

  function setPage(page: number) {
    setPageChanging(true);
    setDiscoverPage(page);
  }

  // Runs as an effect, triggering during render would fire on every render until the binding updates
  useEffect(() => {
    if (!discoverView && !managedRoad && roadConfigurations.length > 0) setManagementRoad(roadConfigurations[0].ID);
  }, [discoverView, managedRoad, roadConfigurations]);

  // The selected category's button disappears once no road matches it, so fall back to all roads
  useEffect(() => {
    if (!discoverView && selectedCategory !== undefined && !roadConfigurations.some((r) => r.Category === selectedCategory))
      setSelectedCategory(undefined);
  }, [discoverView, selectedCategory, roadConfigurations]);

  useEffect(() => {
    setAndBindSearch("");
    setAndBindCategory(undefined);
    setAndBindSorting(0);
    if (discoverView) setDiscoverPage(1);
    setUsedFilter(undefined);
  }, [discoverView]);

  useEffect(() => {
    if (pageChanging && !DiscoverLoading) setPageChanging(false);
  }, [DiscoverLoading]);

  if (discoverView) {
    {
      items = (
        <div className={styles.browseContainer}>
          {DiscoverLoading && (
            <>
              <div className={styles.loader}>
                <img src="coui://streetstudioicons/RB_Loader.svg" />
              </div>
            </>
          )}

          {!DiscoverLoading && (DiscoverErrorLoading || DiscoverItems.length === 0) && (
            <div className={styles.loader}>
              <span className={styles.noResults}>
                <img src={DiscoverErrorLoading ? "Media/Misc/Warning.svg" : "coui://ui-mods/images/RB_Magnifier.svg"} />
                {translate(DiscoverErrorLoading ? "StreetStudio.ErrorLoading" : "StreetStudio.NoResults")}
              </span>
            </div>
          )}

          {!DiscoverLoading && !DiscoverErrorLoading && (
            <>
              <Scrollable className={styles.list} vertical smooth trackVisibility="scrollable">
                {DiscoverItems.map((val, idx) => (
                  <DiscoverRoadConfigListItem key={val.ID ?? idx} road={val} />
                ))}
              </Scrollable>
            </>
          )}
          {!DiscoverErrorLoading && DiscoverItems.length > 0 && (!DiscoverLoading || pageChanging) && <Pagination setPage={setPage} />}
        </div>
      );
    }
  } else {
    items = (
      <div className={styles.localContainer}>
        <Scrollable className={styles.list} vertical smooth trackVisibility="scrollable">
          {GetRoadConfigurations().map((val, idx) => (
            <ManageRoadConfigListItem key={val.ID ?? idx} road={val} selectRoad={(r) => setManagementRoad(r.ID)} selected={managedRoad?.ID === val.ID} />
          ))}
        </Scrollable>
        <div className={styles.managePanel}>{managedRoad && <ManageRoadPanel road={managedRoad} />}</div>
      </div>
    );
  }

  return (
    <div className={classNames(styles.panel, props.editor ? styles.editor : styles.game)}>
      <div className={styles.header}>
        <div className={styles.mode}>
          <div className={classNames(!discoverView && styles.selected)} onClick={() => setDiscoverView(false)}>
            <img style={{ maskImage: "url(coui://streetstudioicons/RB_User.svg)" }} />
            <span>{translate("StreetStudio.MyRoads")}</span>
          </div>
          <div style={{padding: "8rem", opacity: 0.65}}>Local template library</div>
        </div>
        <div className={styles.topBar}>
          <div className={styles.categories}>
            <Button className={classNames(selectedCategory == undefined && styles.selected)} variant="flat" onSelect={() => setAndBindCategory(undefined)}>
              <img src="Media/Tools/Snap Options/All.svg" />
              <span>{translate("StreetStudio.AllRoads")}</span>
            </Button>
            {Object.values(RoadCategory)
              .filter((x) => GetCategoryIcon(x as RoadCategory) != undefined && (discoverView || roadConfigurations.some((r) => r.Category === x)))
              .map((x) => (
                <Button key={x} className={classNames(selectedCategory == x && styles.selected)} variant="flat" onSelect={() => setAndBindCategory(x as RoadCategory)}>
                  <img src={GetCategoryIcon(x as RoadCategory)} />
                  <span>{translate(GetCategoryName(x as RoadCategory))}</span>
                </Button>
              ))}
          </div>

          <div className={styles.filters}>
            {!discoverView && (
              <Tooltip tooltip={translate("StreetStudio.DeleteAllRoads")}>
                <Button variant="flat" onSelect={() => deleteAllRoads()}>
                  <img style={{ maskImage: "url(coui://streetstudioicons/RB_Trash.svg)" }} />
                </Button>
              </Tooltip>
            )}
            
            {!discoverView && RestrictPlayset && (
              <Tooltip tooltip={translate("StreetStudio.ShowAllPlaysets")}>
                <Button variant="flat" selected={showAllPlaysets} onSelect={() => setShowAllPlaysets(!showAllPlaysets)}>
                  <img style={{ maskImage: "url(coui://streetstudioicons/RB_Playset.svg)" }} />
                </Button>
              </Tooltip>
            )}

            {!discoverView && roadConfigurations.some((x) => x.Locked) && (
              <Tooltip tooltip={translate("StreetStudio.HideLockedRoads")}>
                <Button variant="flat" selected={hideLocked} onSelect={() => setHideLocked(!hideLocked)}>
                  <img style={{ maskImage: "url(coui://streetstudioicons/RB_NoLock.svg)" }} />
                </Button>
              </Tooltip>
            )}

            {!discoverView && (
              <Tooltip tooltip={translate("StreetStudio.ShowHidePlaced")}>
                <Button
                  variant="flat"
                  selected={usedFilter != undefined}
                  style={{
                    backgroundColor:
                      usedFilter === false
                        ? "var(--animation-curve-active-n1-stroke)"
                        : usedFilter
                        ? "var(--animation-curve-active-n2-stroke)"
                        : undefined,
                  }}
                  onSelect={() => setUsedFilter(usedFilter == undefined ? true : usedFilter ? false : undefined)}
                >
                  <img
                    style={{
                      maskImage:
                        usedFilter === false ? "url(coui://streetstudioicons/RB_NoLocation.svg)" : "url(coui://streetstudioicons/RB_Location.svg)",
                    }}
                  />
                </Button>
              </Tooltip>
            )}

            {discoverView && (
              <div className={styles.sortingDropdown}>
                <CustomDropdown<number>
                  SelectedItem={sorting}
                  Items={[0, 1, 2, 3, 4, 5]}
                  ToString={(x) => translate(`StreetStudio.DiscoverSorting[${x}]`)}
                  Icon="coui://streetstudioicons/RB_Sort.svg"
                  OnItemSelected={setAndBindSorting}
                ></CustomDropdown>
              </div>
            )}

            <div className={styles.searchBar}>
              <SearchTextBox value={searchQuery} onChange={setAndBindSearch} />
            </div>
          </div>
        </div>

        <Button
          className={styles.closeButton}
          variant="flat"
          onSelect={() => {
            toggleTool();
            toggleTool();
          }}
        >
          <img style={{ maskImage: "url(Media/Glyphs/Close.svg)" }} />
        </Button>
      </div>
      {items}
    </div>
  );
};
