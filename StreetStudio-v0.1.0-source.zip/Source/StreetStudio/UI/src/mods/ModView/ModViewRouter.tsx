import { StudioWorkspace } from "mods/Studio/StudioWorkspace";
import classNames from "classnames";
import { useValue } from "cs2/api";
import { useLocalization } from "cs2/l10n";
import { StreetStudioToolModeEnum } from "domain/StreetStudioToolMode";
import { roadBuilderToolMode$ } from "mods/bindings";
import { BottomView } from "mods/BottomView/BottomView";
import ActionPopup from "mods/Components/ActionPopup/ActionPopup";
import { RoadPropertiesPanel } from "mods/RoadPropertiesPanel/RoadPropertiesPanel";
import { SidePanel } from "mods/SidePanel/SidePanel";
import styles from "./ModView.module.scss";

import RB_ClickOnRoad from "images/RB_ClickOnRoad.svg";
import { ManageRoadsView } from "mods/ManageRoadsView/ManageRoadsView";

export const Router = (props: { editor: boolean }) => {
  const roadBuilderToolMode = useValue(roadBuilderToolMode$);
  let { translate } = useLocalization();

  let content: JSX.Element | null = null;
  switch (roadBuilderToolMode) {
    case StreetStudioToolModeEnum.Picker:
      content = (
        <>
          <div className={styles.pickerHint}>
            <span>
              <img src={RB_ClickOnRoad} />
              {translate("StreetStudio.PickerHint", "Click On A Road")}
            </span>
          </div>
          <SidePanel editor={props.editor} />
        </>
      );
      break;
    case StreetStudioToolModeEnum.ManageRoads:
      content = (
        <>
          <ManageRoadsView editor={props.editor} />
        </>
      );
      break;
    case StreetStudioToolModeEnum.ActionSelection:
      content = (
        <>
          <ActionPopup />
        </>
      );
      break;
    case StreetStudioToolModeEnum.Editing:
    case StreetStudioToolModeEnum.EditingSingle:
    case StreetStudioToolModeEnum.EditingNonExistent:
      content = (
        <>
          <StudioWorkspace editor={props.editor} />
        </>
      );
      break;
    default:
      return <></>;
  }

  return <div className={classNames(styles.view, props.editor && styles.editor)}>{content}</div>;
};
