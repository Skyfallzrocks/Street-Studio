$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'StreetStudio\StreetStudio.csproj'
$ui = Join-Path $PSScriptRoot 'StreetStudio\UI'
if (-not [Environment]::GetEnvironmentVariable('CSII_TOOLPATH', 'User')) {
    throw 'Install the official Cities: Skylines II Modding Toolchain first.'
}
Push-Location $ui
try {
    & npm.cmd ci --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw 'UI dependency installation failed.' }
} finally { Pop-Location }
$previousRollForward = $env:DOTNET_ROLL_FORWARD
try {
    $env:DOTNET_ROLL_FORWARD = 'Major'
    & dotnet build $project -c Release
    if ($LASTEXITCODE -ne 0) { throw 'Street Studio build failed.' }
} finally { $env:DOTNET_ROLL_FORWARD = $previousRollForward }
Write-Host 'Build complete. See Package\StreetStudio beside the Source folder.'
